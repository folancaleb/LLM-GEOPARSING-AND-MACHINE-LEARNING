#!/usr/bin/env bash
# run_all.sh — Reproduce the full analysis of FRSC road traffic crashes on the Lagos–Ibadan Expressway, 2013–2022.
# Usage:  bash run_all.sh            (run from this folder)
# Inputs: data/with_coordinates/     ten annual FRSC returns WITH latitude/longitude + 2017_RTC.csv (field GPS file)
#         data/without_coordinates/  the same ten returns WITHOUT coordinates (the files to be geoparsed)
set -euo pipefail
cd "$(dirname "$0")"
S=scripts; RAW=data/with_coordinates; RAW_NC=data/without_coordinates; O=outputs; G=$O/geoparsing
mkdir -p "$O" "$G/in" "$G/out"
py() { echo ">> $*"; python3 -I "$@"; }

# ---- A. Cleaning, corridor referencing, exploratory analysis, hot spots (recorded coordinates) ----
py $S/01_clean.py "$RAW" "$O"                  # harmonised records: rtc_lagos_ibadan_clean_2013_2022.csv (+ all rows with attributes)
py $S/02_corridor.py "$O"                      # data-derived centreline (Ojota → Iwo Road), chainage, on-corridor flag
py $S/03_eda.py "$O"                           # temporal and causal summaries (Seaborn figures)
py $S/04_hotspots.py "$O"                      # Getis–Ord Gi* (2-km, 5-km, inter-urban), emerging hot spots, DBSCAN, KDE
py $S/sankey_cause_vehicle.py "$O"             # cause → vehicle → outcome Sankey
py $S/fig01_annual_panel.py "$O"               # annual trends (4 panels)
py $S/report_maps_basemap.py "$O" "$O/figures" # KDE and Gi*/DBSCAN maps on the Natural Earth basemap

# ---- B. Machine learning and forecasts ----
py $S/05_ml.py "$O"                            # monthly forecasting back-test, 2023 segment forecast, severity classifier
py $S/fig12_severity_panel.py "$O"             # what makes a crash fatal (4 panels; uses the 05_ml importance)
py $S/ml_2027.py "$O"                          # monthly/annual forecast to December 2027 (ensemble + scenarios)
py $S/fig_2027.py "$O"                         # 2027 forecast figure
py $S/ml_seg_2027.py "$O"                      # 2-km sections likely to be hot spots in 2027 (5-year-ahead model)
py $S/fig_seg_2027.py "$O"                     # map + profile of 2027 hot-spot sections
py $S/fig_seg_2027_profile.py "$O"             # expected crashes per section in 2027 (standalone chart)

# ---- C. LLM-assisted geoparsing of the returns without coordinates (leave-one-year-out) ----
py $S/geo10_prepare.py "$RAW_NC" "$G/in"
for y in $(seq 2013 2022); do                  # gazetteer built from the OTHER nine years only
  py $S/geo_01_geocode.py "$O/rtc_lagos_ibadan_clean_2013_2022.csv" "$O/centreline_derived.csv" "$G/in/in_$y.csv" "$y" "$G/out/geo_$y.csv"
done
py $S/geo10_combine.py "$G/out" "$O/rtc_all_rows_with_attributes.csv" "$G/combined_raw.csv"
py $S/geo10_pass2.py "$G/combined_raw.csv" "$O/rtc_all_rows_with_attributes.csv" "$O/centreline_derived.csv" "$G/combined_final.csv"
py $S/geo10_export.py "$G/combined_final.csv" "$O/centreline_derived.csv" "$G/GIS"   # CSV, shapefiles, GeoJSON, KML, segment hot spots
py $S/geo10_maps.py "$G/GIS" "$O/centreline_derived.csv"                              # static maps on the Natural Earth basemap

# ---- D. Validation against the 2026 FRSC field GPS survey ----
py $S/geo_validate_2017.py "$RAW/2017_RTC.csv" "$G/combined_final.csv" "$O/centreline_derived.csv" "$O/rtc_all_rows_with_attributes.csv" "$O/validation"
py $S/gazetteer_verify.py "$RAW/2017_RTC.csv" "$O/validation/validation_2017_records.csv" "$O/gazetteer_verification"
echo "Done. Results are in $O/"

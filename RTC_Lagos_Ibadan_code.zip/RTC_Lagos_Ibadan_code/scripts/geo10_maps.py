"""geo10_maps.py — Static maps of geoparsed 2013–2022 crashes. Usage: python3 -I geo10_maps.py <deliver_dir> <centreline.csv>"""
import sys, os, json, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(__file__))
import style; style.setup()
import basemap_ne
import matplotlib.pyplot as plt, seaborn as sns
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from matplotlib.collections import LineCollection
DL, CLF = sys.argv[1], sys.argv[2]; FIG = os.path.join(DL, "maps"); os.makedirs(FIG, exist_ok=True)
d = pd.read_csv(os.path.join(DL, "RTC_Lagos_Ibadan_2013_2022_geoparsed.csv"), low_memory=False)
sg = pd.read_csv(os.path.join(DL, "RTC_segments_2km_hotspots.csv")); cl = pd.read_csv(CLF)
p = d[d.LAT.notna() & (d.DUPLICATE != "yes")].copy()
ASP = 1 / np.cos(np.deg2rad(6.9)); INK2 = "#52514e"; ROAD = "#d6d5cf"
CONF = {"High": "#1b8a2a", "Medium": "#eda100", "Low": "#d03b3b"}
XL, YL = (3.20, 4.05), (6.40, 7.50)

def frame(ax, title, legend_loc="lower right"):
    basemap_ne.draw(ax, extent=XL + YL)
    ax.plot(cl.lon, cl.lat, color="#fcfcfb", lw=7.5, solid_capstyle="round", zorder=1, alpha=.9)
    ax.plot(cl.lon, cl.lat, color="#8a8983", lw=3.2, solid_capstyle="round", zorder=1.1)
    ax.set_xlim(*XL); ax.set_ylim(*YL); ax.set_aspect(ASP); ax.set_title(title)
    ax.set_xlabel("Longitude (°E)"); ax.set_ylabel("Latitude (°N)")
    for nm, la, lo, dx in [("Ojota, Lagos", 6.5994, 3.3783, -30), ("Iwo Road, Ibadan", 7.4014, 3.9422, -10)]:
        ax.annotate(nm, (lo, la), xytext=(dx, -26 if nm.startswith("Ojota") else 8), textcoords="offset points", fontsize=8, color=INK2, ha="right",
                    arrowprops=dict(arrowstyle="-", color="#8a8983", lw=.5) if nm.startswith("Ojota") else None)
    # scale bar (20 km) and north arrow
    dlon = 20 / (111.32 * np.cos(np.deg2rad(6.9))); x0, y0 = XL[1] - 0.04 - dlon, YL[0] + 0.06
    ax.plot([x0, x0 + dlon], [y0, y0], color="#0b0b0b", lw=2.5, solid_capstyle="butt"); ax.plot([x0, x0 + dlon / 2], [y0, y0], color="#fcfcfb", lw=1.2, solid_capstyle="butt")
    ax.text(x0, y0 + 0.012, "0", fontsize=7, ha="center"); ax.text(x0 + dlon, y0 + 0.012, "20 km", fontsize=7, ha="center")
    ax.annotate("N", xy=(XL[0] + 0.05, YL[1] - 0.04), xytext=(XL[0] + 0.05, YL[1] - 0.12), ha="center", fontsize=10, weight="bold",
                arrowprops=dict(arrowstyle="-|>", color="#0b0b0b", lw=1.5))
    ax.text(XL[1] - 0.01, YL[0] + 0.01, "WGS 84 · crashes geoparsed from FRSC location names · " + basemap_ne.CREDIT, fontsize=6.5, color="#3a3936", ha="right", va="bottom",
            bbox=dict(boxstyle="round,pad=0.2", fc="#fcfcfb", ec="none", alpha=.8), zorder=6)

def label_sites(ax, sites, n=10, fs=7.5):
    s = sites.sort_values("n", ascending=False).head(n).sort_values("lat")
    for i, (_, r) in enumerate(s.iterrows()):
        side = 1 if (i % 2 == 0) else -1
        ax.annotate(f"{r.key.title()} ({r.n})", (r.lon, r.lat), xytext=(16 * side, 0), textcoords="offset points", ha="left" if side > 0 else "right",
                    va="center", fontsize=fs, color="#0b0b0b", arrowprops=dict(arrowstyle="-", color="#8a8983", lw=0.6),
                    bbox=dict(boxstyle="round,pad=0.15", fc="#fcfcfb", ec="none", alpha=0.85))

site = p.groupby(["LAT", "LON"]).agg(n=("YEAR", "size"), killed=("KILLED", "sum"), key=("MATCH_KEY", lambda s: s.value_counts().index[0]),
                                     conf=("CONFIDENCE", lambda s: s.value_counts().index[0])).reset_index().rename(columns={"LAT": "lat", "LON": "lon"})

# ---------- Map 1: overview by confidence ----------
fig, ax = plt.subplots(figsize=(10.4, 10))
frame(ax, f"Geoparsed road traffic crashes, Lagos–Ibadan Expressway, 2013–2022 (n = {len(p):,})")
for k in ["Low", "Medium", "High"]:
    s = site[site.conf == k]
    ax.scatter(s.lon, s.lat, s=8 + s.n * 2.2, color=CONF[k], alpha=.72, edgecolor="#fcfcfb", linewidth=.7, zorder=3)
label_sites(ax, site[site.lon.between(3.3, 4.0)], n=12)
h = [Line2D([], [], marker="o", ls="", color=CONF[k], markersize=8, label=f"{k} confidence ({(p.CONFIDENCE == k).sum():,} crashes)") for k in ["High", "Medium", "Low"]]
h += [Line2D([], [], marker="o", ls="", color="#a8a79f", markersize=np.sqrt(8 + n * 2.2), label=f"{n} crashes at site") for n in [10, 50, 150]]
ax.legend(handles=h, loc="center left", bbox_to_anchor=(1.01, 0.5), fontsize=8.5, labelspacing=1.3, borderpad=0.9, frameon=True, facecolor="#fcfcfb", edgecolor="#c9c8c1",
          title=f"Excludes {int((d.DUPLICATE == 'yes').sum())} duplicate\nrecords", title_fontsize=8.5)
fig.tight_layout(); fig.savefig(os.path.join(FIG, "Map1_geoparsed_crashes_by_confidence.png"), dpi=220); plt.close()

# ---------- Map 2: small multiples by year ----------
fig, axs = plt.subplots(2, 5, figsize=(15, 9.6), sharex=True, sharey=True)
for ax, y in zip(axs.ravel(), range(2013, 2023)):
    basemap_ne.draw(ax, light=True, extent=XL + YL)
    ax.plot(cl.lon, cl.lat, color="#8a8983", lw=2.2, solid_capstyle="round", zorder=1)
    s = p[p.YEAR == y].groupby(["LAT", "LON"]).size().reset_index(name="n")
    ax.scatter(s.LON, s.LAT, s=4 + s.n * 4, color="#2a78d6", alpha=.6, edgecolor="#fcfcfb", linewidth=.5, zorder=3)
    tot = int((d.YEAR == y).sum()); ax.set_title(f"{y}   ({(p.YEAR == y).sum()} of {tot} located)", fontsize=10)
    ax.set_xlim(*XL); ax.set_ylim(*YL); ax.set_aspect(ASP); ax.tick_params(labelsize=7)
fig.suptitle("Geoparsed crashes by year (symbol area ∝ crashes at site)", x=0.01, ha="left", fontsize=13, weight="bold")
fig.text(0.99, 0.005, basemap_ne.CREDIT, ha="right", fontsize=8, color="#52514e")
fig.tight_layout(); fig.savefig(os.path.join(FIG, "Map2_crashes_by_year.png"), dpi=200); plt.close()

# ---------- Map 3: kernel density (High + Medium) ----------
hm = p[p.CONFIDENCE.isin(["High", "Medium"]) & (p.ON_EXPWY == "yes")]
from matplotlib.colors import LinearSegmentedColormap
KDECM = LinearSegmentedColormap.from_list("kde", [(1.0, 0.85, 0.30, 0.0), (0.99, 0.80, 0.30, 0.55), (0.93, 0.41, 0.20, 0.8), (0.82, 0.23, 0.23, 0.92), (0.45, 0.05, 0.10, 0.97)])
fig, axs = plt.subplots(1, 2, figsize=(14, 9.5), sharey=True)
for ax, (lab, sub) in zip(axs, [("2013–2017", hm[hm.YEAR <= 2017]), ("2018–2022", hm[hm.YEAR >= 2018])]):
    frame(ax, f"Crash density (KDE), {lab}  (n = {len(sub):,}, High + Medium)")
    sns.kdeplot(x=sub.LON, y=sub.LAT, fill=True, cmap=KDECM, levels=14, thresh=0.04, bw_adjust=0.3, ax=ax, zorder=2)
    ax.scatter(sub.LON, sub.LAT, s=3, color="#0b0b0b", alpha=.35, zorder=3, linewidths=0)
fig.tight_layout(); fig.savefig(os.path.join(FIG, "Map3_crash_density_KDE.png"), dpi=200); plt.close()

# ---------- Map 4: fatalities ----------
fs = site[site.killed > 0].copy(); fs["dpc"] = fs.killed / fs.n
fig, ax = plt.subplots(figsize=(8.2, 10))
frame(ax, f"Persons killed at geoparsed crash sites, 2013–2022 (total {int(p.KILLED.sum()):,})")
sc = ax.scatter(fs.lon, fs.lat, s=6 + fs.killed * 3, c=fs.dpc.clip(0, 1.5), cmap=style.SEQ, vmin=0, vmax=1.5, alpha=.85, edgecolor="#52514e", linewidth=.4, zorder=3)
cb = fig.colorbar(sc, ax=ax, shrink=.45, pad=.02); cb.set_label("Deaths per crash at site")
lab = fs.rename(columns={"killed": "_k"}).assign(n=lambda x: x._k.astype(int))
label_sites(ax, lab[lab.lon.between(3.3, 4.0)], n=10)
h = [Line2D([], [], marker="o", ls="", color="#a8a79f", markeredgecolor="#52514e", markersize=np.sqrt(6 + k * 3), label=f"{k} killed") for k in [5, 25, 100]]
ax.legend(handles=h, loc="center right", bbox_to_anchor=(0.995, 0.56), fontsize=8, labelspacing=1.4, borderpad=0.9, title="Labels: persons killed", frameon=True, facecolor="#fcfcfb", edgecolor="#c9c8c1", framealpha=.95, title_fontsize=8.5)
fig.tight_layout(); fig.savefig(os.path.join(FIG, "Map4_fatalities.png"), dpi=220); plt.close()

# ---------- Map 5: Gi* hotspot segments ----------
pal = {"Hot 99%": "#d03b3b", "Hot 95%": "#ec835a", "Hot 90%": "#f4b393", "Not significant": "#c9c8c1"}
fig, axs = plt.subplots(1, 2, figsize=(14, 9.5), sharey=True)
for ax, col, title in [(axs[0], "GI_CLASS", "Gi* hotspots — whole corridor (2-km segments)"), (axs[1], "GI_CLS_INT", "Gi* hotspots — inter-urban section (≥ 20 km) + trends")]:
    basemap_ne.draw(ax, extent=XL + YL)
    ax.set_xlim(*XL); ax.set_ylim(*YL); ax.set_aspect(ASP); ax.set_title(title); ax.set_xlabel("Longitude (°E)"); ax.set_ylabel("Latitude (°N)")
    for _, r in sg.iterrows():
        ts = np.r_[r.FROM_KM, cl.chainage_km[(cl.chainage_km > r.FROM_KM) & (cl.chainage_km < r.TO_KM)].values, r.TO_KM]
        c = pal.get(r[col], "#e4e3df"); lw = 9 if str(r[col]).startswith("Hot") else 5
        ax.plot(np.interp(ts, cl.chainage_km, cl.lon), np.interp(ts, cl.chainage_km, cl.lat), color=c, lw=lw, solid_capstyle="butt", zorder=2)
    hot = sg[sg[col].astype(str).str.startswith("Hot") & (sg.CRASHES >= 20)].copy()
    hot["mid"] = (hot.FROM_KM + hot.TO_KM) / 2
    hot["la"] = np.interp(hot.mid, cl.chainage_km, cl.lat); hot["lo"] = np.interp(hot.mid, cl.chainage_km, cl.lon)
    hot = hot.sort_values("la")
    for grp in [hot[hot.la < 7.0], hot[hot.la >= 7.0]]:
        if not len(grp): continue
        y0 = max(grp.la.min() - 0.02, YL[0] + 0.12); ys = y0 + np.arange(len(grp)) * 0.045
        for (_, r), yy in zip(grp.iterrows(), ys):
            tx = r.lo + 0.13 if r.la < 7.0 else r.lo - 0.10
            ax.annotate(f"{r.TOP_NAMES.split(',')[0].title()} · {r.FROM_KM:.0f}–{r.TO_KM:.0f} km · {r.CRASHES} crashes", (r.lo, r.la), xytext=(tx, yy), textcoords="data",
                        ha="left" if r.la < 7.0 else "right", va="center", fontsize=7.8, arrowprops=dict(arrowstyle="-", color="#8a8983", lw=.6, shrinkA=0, shrinkB=2),
                        bbox=dict(boxstyle="round,pad=0.2", fc="#fcfcfb", ec="#e4e3df", lw=.5))
    ax.text(XL[1] - 0.01, YL[0] + 0.01, "WGS 84 · segments on data-derived centreline · " + basemap_ne.CREDIT, fontsize=6.5, color="#3a3936", ha="right",
            bbox=dict(boxstyle="round,pad=0.2", fc="#fcfcfb", ec="none", alpha=.8), zorder=6)
    ax.plot([cl.lon.iloc[0]], [cl.lat.iloc[0]], "o", color="#52514e", ms=4); ax.annotate("Ojota", (cl.lon.iloc[0], cl.lat.iloc[0]), xytext=(-8, -4), textcoords="offset points", ha="right", fontsize=8, color=INK2)
    ax.annotate("Iwo Road", (cl.lon.iloc[-1], cl.lat.iloc[-1]), xytext=(-8, 4), textcoords="offset points", ha="right", fontsize=8, color=INK2)
for _, r in sg[sg.TREND == "intensifying"].iterrows():
    mid = (r.FROM_KM + r.TO_KM) / 2
    axs[1].scatter(np.interp(mid, cl.chainage_km, cl.lon) - 0.03, np.interp(mid, cl.chainage_km, cl.lat), marker=">", s=55, color="#6250d6", zorder=4)
h = [Patch(color=pal[k], label=k) for k in pal] + [Line2D([], [], marker=">", ls="", color="#6250d6", markersize=8, label="Intensifying trend (Mann–Kendall p < 0.05)")]
for a_ in axs: a_.legend(handles=h if a_ is axs[1] else h[:-1], loc="center right", bbox_to_anchor=(0.995, 0.6), fontsize=8.5, frameon=True, facecolor="#fcfcfb", edgecolor="#c9c8c1", framealpha=.95)
fig.tight_layout(); fig.savefig(os.path.join(FIG, "Map5_hotspot_segments_GiStar.png"), dpi=200); plt.close()

# ---------- Figure: positional agreement ----------
KX, KY = 111.32 * np.cos(np.deg2rad(6.9)), 110.57
v = d[d.LAT.notna() & d.ORIG_LAT.notna()].copy(); v["err"] = v.ORIG_DIFF
fig, axs = plt.subplots(1, 2, figsize=(13, 4.3), gridspec_kw={"width_ratios": [1.2, 1]})
ax = axs[0]
for k in ["High", "Medium", "Low"]:
    e = np.sort(v[v.CONFIDENCE == k].err.values); ax.step(np.r_[0, e], np.r_[0, np.arange(1, len(e) + 1) / len(e)] * 100, where="post", color=CONF[k], lw=2, label=f"{k} (n = {len(e):,})")
ax.set_xscale("symlog", linthresh=1); ax.set_xlim(0, 120); ax.set_xticks([0, 0.5, 1, 2, 5, 10, 20, 50, 100]); ax.set_xticklabels(["0", "0.5", "1", "2", "5", "10", "20", "50", "100"])
ax.axvline(1, color="#a8a79f", ls="--", lw=1); ax.set_ylim(0, 100); ax.legend(title="Confidence", loc="lower right")
ax.set_xlabel("Distance from withheld original coordinate (km)"); ax.set_ylabel("Cumulative % of records"); ax.set_title("Agreement with withheld coordinates (leave-one-year-out)")
ax = axs[1]; w1 = v.groupby("YEAR").err.apply(lambda s: 100 * (s <= 1).mean())
sns.barplot(x=w1.index.astype(str), y=w1.values, color="#2a78d6", ax=ax, width=.6)
for i, val in enumerate(w1.values): ax.text(i, val + 1.5, f"{val:.0f}%", ha="center", fontsize=8, color=INK2)
ax.set_ylim(0, 100); ax.set_ylabel("% within 1 km"); ax.set_xlabel(""); ax.set_title("Share within 1 km, by year")
fig.tight_layout(); fig.savefig(os.path.join(FIG, "Fig_validation_agreement.png"), dpi=200); plt.close()
print("maps written:", sorted(os.listdir(FIG)))

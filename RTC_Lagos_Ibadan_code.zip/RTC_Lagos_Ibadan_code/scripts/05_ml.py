"""05_ml.py — Machine-learning prediction of future crash occurrence.
A) Monthly corridor-wide forecasting (2023–2024)
B) Segment-level (2-km) hotspot forecasting for 2023
C) Fatal-crash severity classification + permutation importance
Usage: python3 -I 05_ml.py <out_dir>"""
import sys, os, json, warnings, numpy as np, pandas as pd
from scipy import stats
from sklearn.linear_model import PoissonRegressor, LogisticRegression
from sklearn.ensemble import RandomForestRegressor, HistGradientBoostingRegressor, HistGradientBoostingClassifier
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.metrics import mean_absolute_error, mean_squared_error, roc_auc_score, average_precision_score, brier_score_loss
from sklearn.inspection import permutation_importance
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import make_pipeline
warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(__file__))
import style; style.setup()
import matplotlib.pyplot as plt, seaborn as sns
from style import CAT, INK2, SEQ

OUT = sys.argv[1]; FIG = os.path.join(OUT, "figures"); SEED = 42
d = pd.read_csv(os.path.join(OUT, "rtc_lagos_ibadan_clean_2013_2022.csv"), parse_dates=["date"])
R = {}

# ===================== A) MONTHLY FORECAST =====================
m = d.dropna(subset=["date"]).set_index("date").resample("MS").size().rename("n").to_frame()
m = m.reindex(pd.date_range("2013-01-01", "2022-12-01", freq="MS"), fill_value=0)
m["t"] = np.arange(len(m)); m["month"] = m.index.month

def design(df):
    X = pd.get_dummies(df["month"].astype(str), prefix="m").reindex(columns=[f"m_{i}" for i in range(1, 13)], fill_value=0).astype(float)
    X["t"] = df["t"] / 120.0
    return X

def lag_feats(hist, idx_t, month):
    h = np.asarray(hist, float)
    return [h[-1], h[-2], h[-3], h[-12], h[-3:].mean(), h[-12:].mean(), idx_t / 120.0, np.sin(2 * np.pi * month / 12), np.cos(2 * np.pi * month / 12)]

def fit_predict(train, horizon_index, model):
    """Return predictions for the months in horizon_index given training frame (recursive for ML)."""
    if model == "Ensemble (GLM + RF + GBM)":
        return np.mean([fit_predict(train, horizon_index, k) for k in ["Poisson GLM (trend + month)", "Random Forest (lags)", "Gradient Boosting (Poisson, lags)"]], axis=0)
    if model == "Seasonal naïve":
        last = train.n.values[-12:]; return np.array([last[i % 12] for i in range(len(horizon_index))])
    if model == "Poisson GLM (trend + month)":
        g = PoissonRegressor(alpha=1e-4, max_iter=3000).fit(design(train), train.n)
        fut = pd.DataFrame({"t": np.arange(len(train), len(train) + len(horizon_index)), "month": horizon_index.month}, index=horizon_index)
        return g.predict(design(fut))
    # ML recursive models
    h = list(train.n.values); X, y = [], []
    for i in range(12, len(h)):
        X.append(lag_feats(h[:i], i, train.month.iloc[i])); y.append(h[i])
    if model == "Random Forest (lags)":
        mdl = RandomForestRegressor(n_estimators=500, min_samples_leaf=3, random_state=SEED).fit(X, y)
    else:
        mdl = HistGradientBoostingRegressor(loss="poisson", max_iter=300, learning_rate=0.05, max_depth=3, min_samples_leaf=8, random_state=SEED).fit(X, y)
    out = []
    for k, ts in enumerate(horizon_index):
        f = lag_feats(h, len(h), ts.month); p = float(mdl.predict([f])[0]); out.append(p); h.append(p)
    return np.array(out)

MODELS = ["Seasonal naïve", "Poisson GLM (trend + month)", "Random Forest (lags)", "Gradient Boosting (Poisson, lags)", "Ensemble (GLM + RF + GBM)"]
bt = []
for test_year in [2020, 2021, 2022]:            # rolling-origin backtest, 12-month horizon
    tr = m[m.index.year < test_year]; te = m[m.index.year == test_year]
    for mod in MODELS:
        pr = fit_predict(tr, te.index, mod)
        bt.append({"test_year": test_year, "model": mod, "MAE": mean_absolute_error(te.n, pr),
                   "RMSE": mean_squared_error(te.n, pr) ** .5, "annual_error_pct": 100 * (pr.sum() - te.n.sum()) / te.n.sum(),
                   "actual_total": int(te.n.sum()), "pred_total": round(pr.sum(), 1)})
bt = pd.DataFrame(bt); bt.round(2).to_csv(os.path.join(OUT, "ml_monthly_backtest.csv"), index=False)
summ = bt.groupby("model")[["MAE", "RMSE"]].mean().sort_values("MAE")
R["monthly_backtest"] = bt.round(2).to_dict("records"); R["monthly_backtest_mean"] = summ.round(2).reset_index().to_dict("records")
# Selection rule: among models within 5% of the lowest mean MAE, pick the one with the smallest worst-case annual error
worst = bt.assign(ae=bt.annual_error_pct.abs()).groupby("model").ae.max()
cands = summ[summ.MAE <= summ.MAE.min() * 1.05].index
best = worst.loc[cands].idxmin(); R["monthly_best"] = best; R["monthly_worst_case_annual_error"] = worst.round(1).to_dict()

# Final forecast 2023–2024 with best model + GLM-based overdispersed interval width scaled by backtest RMSE
fut_idx = pd.date_range("2023-01-01", "2024-12-01", freq="MS")
fc = {mod: fit_predict(m, fut_idx, mod) for mod in MODELS}
bt_rmse = bt[bt.model == best].RMSE.mean()
lo = np.maximum(fc[best] - 1.645 * bt_rmse * np.sqrt(1 + np.arange(24) / 24), 0)
hi = fc[best] + 1.645 * bt_rmse * np.sqrt(1 + np.arange(24) / 24)
F = pd.DataFrame({"month": fut_idx.strftime("%Y-%m"), "forecast_best": fc[best].round(1), "pi90_low": lo.round(1), "pi90_high": hi.round(1),
                  **{f"fc_{k.split(' (')[0].replace(' ', '_').lower()}": v.round(1) for k, v in fc.items()}})
F.to_csv(os.path.join(OUT, "forecast_monthly_2023_2024.csv"), index=False)
R["forecast_annual"] = {"2023": round(fc[best][:12].sum()), "2024": round(fc[best][12:].sum()),
                        "2023_pi90": [round(lo[:12].sum()), round(hi[:12].sum())], "2024_pi90": [round(lo[12:].sum()), round(hi[12:].sum())],
                        "all_models_2023": {k: round(v[:12].sum()) for k, v in fc.items()}}

fig, ax = plt.subplots(figsize=(13, 4.4))
ax.plot(m.index, m.n, color=CAT[0], lw=1.6, label="Observed (2013–2022)")
ax.plot(m.index, m.n.rolling(12, center=True).mean(), color="#0d366b", lw=2.2, label="12-month moving average")
ax.fill_between(fut_idx, lo, hi, color=CAT[1], alpha=.18, linewidth=0, label="90% prediction band")
ax.plot(fut_idx, fc[best], color=CAT[1], lw=2.2, label=f"Forecast: {best}")
ax.axvline(pd.Timestamp("2023-01-01"), color="#a8a79f", lw=1, ls="--")
ax.set_title("Monthly recorded crashes and machine-learning forecast to December 2024"); ax.set_ylabel("Crashes per month"); ax.set_xlabel("")
ax.legend(loc="upper left", fontsize=9, ncol=2); ax.set_ylim(0, None)
fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig10_monthly_forecast.png")); plt.close()

# ===================== B) SEGMENT-LEVEL HOTSPOT FORECAST =====================
p = d[d.on_corridor].copy(); SEG = 2
L = pd.read_csv(os.path.join(OUT, "centreline_derived.csv")).chainage_km.max()
nseg = int(np.ceil(L / SEG)); p["seg"] = (p.chainage_km // SEG).astype(int).clip(0, nseg - 1)
years = list(range(2013, 2023))
C = p.pivot_table(index="seg", columns="year", values="fatal", aggfunc="size", fill_value=0).reindex(index=range(nseg), columns=years, fill_value=0)
K = p.pivot_table(index="seg", columns="year", values="killed", aggfunc="sum", fill_value=0).reindex(index=range(nseg), columns=years, fill_value=0)

def feats(yr):
    """Features known at the end of year yr-1 for predicting counts in year yr."""
    rows = []
    for s in range(nseg):
        prev = [C.loc[s, y] if y in C.columns else 0 for y in (yr - 1, yr - 2, yr - 3)]
        nb = [C.loc[j, yr - 1] for j in (s - 1, s + 1) if 0 <= j < nseg]
        hist = C.loc[s, [y for y in years if y < yr]]
        rows.append({"seg": s, "year": yr, "lag1": prev[0], "lag2": prev[1], "lag3": prev[2], "hist_mean": hist.mean(),
                     "hist_max": hist.max(), "nb_lag1": np.mean(nb), "killed_lag1": K.loc[s, yr - 1],
                     "share_lag1": C.loc[s, yr - 1] / max(C[yr - 1].sum(), 1), "chainage": s * SEG + SEG / 2,
                     "trend3": (prev[0] - prev[2]) / 2, "y": C.loc[s, yr] if yr in C.columns else np.nan})
    return pd.DataFrame(rows)
FEATS = ["lag1", "lag2", "lag3", "hist_mean", "hist_max", "nb_lag1", "killed_lag1", "share_lag1", "chainage", "trend3"]
panel = pd.concat([feats(y) for y in range(2016, 2024)], ignore_index=True)

def seg_models():
    return {"Persistence (last year)": None, "Historical mean": None,
            "Poisson GLM": make_pipeline(StandardScaler(), PoissonRegressor(alpha=1.0, max_iter=3000)),
            "Random Forest": RandomForestRegressor(n_estimators=600, min_samples_leaf=3, random_state=SEED),
            "Gradient Boosting (Poisson)": HistGradientBoostingRegressor(loss="poisson", max_iter=250, learning_rate=0.05, max_depth=3, min_samples_leaf=10, random_state=SEED)}

def hit_rate(y, pred, top=0.10):
    k = max(1, int(round(top * len(y)))); idx = np.argsort(-pred)[:k]
    hr = y[idx].sum() / max(y.sum(), 1); return hr, hr / (k / len(y))

ev = []; preds_store = {}
for ty in [2020, 2021, 2022]:
    tr = panel[(panel.year < ty) & panel.y.notna()]; te = panel[panel.year == ty]
    for name, mdl in seg_models().items():
        if name.startswith("Persistence"): pr = te.lag1.values
        elif name.startswith("Historical"): pr = te.hist_mean.values
        else: pr = mdl.fit(tr[FEATS], tr.y).predict(te[FEATS])
        y = te.y.values; hr, pai = hit_rate(y, pr)
        ev.append({"test_year": ty, "model": name, "MAE": mean_absolute_error(y, pr), "Spearman": stats.spearmanr(y, pr)[0],
                   "hit_rate_top10pct": hr * 100, "PAI": pai})
        if ty == 2022: preds_store[name] = pr
ev = pd.DataFrame(ev); ev.round(3).to_csv(os.path.join(OUT, "ml_segment_backtest.csv"), index=False)
evm = ev.groupby("model")[["MAE", "Spearman", "hit_rate_top10pct", "PAI"]].mean().sort_values("MAE")
R["segment_backtest"] = ev.round(3).to_dict("records"); R["segment_backtest_mean"] = evm.round(3).reset_index().to_dict("records")
ml_only = evm.loc[["Poisson GLM", "Random Forest", "Gradient Boosting (Poisson)"]]
best_seg = ml_only.sort_values("MAE").index[0]; R["segment_best"] = best_seg

# Final: train on all target years 2016–2022, predict 2023
tr = panel[panel.y.notna()]; f23 = panel[panel.year == 2023].copy()
mdl = seg_models()[best_seg].fit(tr[FEATS], tr.y)
f23["pred_2023"] = mdl.predict(f23[FEATS])
# Split-conformal 90% intervals from backtest residuals of the chosen model (normalised by sqrt(pred+1))
res = []
for ty in [2020, 2021, 2022]:
    trb = panel[(panel.year < ty) & panel.y.notna()]; teb = panel[panel.year == ty]
    pb = seg_models()[best_seg].fit(trb[FEATS], trb.y).predict(teb[FEATS])
    res.extend(np.abs(teb.y.values - pb) / np.sqrt(pb + 1))
qc = np.quantile(res, 0.90); R["seg_conformal_q90"] = round(float(qc), 3)
# Monte-Carlo (Poisson around a model-error-perturbed mean) for probability of being a top-10% segment
rng = np.random.default_rng(SEED)
mu = np.clip(f23.pred_2023.values, 0, None)
mu_s = np.clip(mu[None] + rng.choice(np.r_[res, -np.array(res)], size=(5000, nseg)) * np.sqrt(mu + 1)[None], 0, None)
sims = rng.poisson(mu_s)
k10 = max(1, int(round(.1 * nseg)))
thr = np.sort(sims, axis=1)[:, -k10][:, None]
f23["p_top10"] = ((sims >= thr) & (sims > 0)).mean(0)
f23["pi90_low"] = np.clip(mu - qc * np.sqrt(mu + 1), 0, None); f23["pi90_high"] = mu + qc * np.sqrt(mu + 1)
f23["from_km"] = f23.seg * SEG; f23["to_km"] = f23.from_km + SEG
hs = pd.read_csv(os.path.join(OUT, "hotspots_gistar_2km.csv"))[["seg", "class", "emerging", "top_location_names"]]
f23 = f23.merge(hs, on="seg", how="left")
f23["risk_tier"] = pd.cut(f23.pred_2023.rank(pct=True), [0, .5, .8, .9, 1.0], labels=["Low", "Moderate", "High", "Very high"])
out23 = f23[["seg", "from_km", "to_km", "lag1", "hist_mean", "pred_2023", "pi90_low", "pi90_high", "p_top10", "risk_tier", "class", "emerging", "top_location_names"]]
out23 = out23.rename(columns={"lag1": "crashes_2022", "hist_mean": "mean_2013_2022", "class": "gistar_class_2013_2022"})
out23.round(3).sort_values("pred_2023", ascending=False).to_csv(os.path.join(OUT, "forecast_segments_2023.csv"), index=False)
R["seg_2023_top"] = out23.sort_values("pred_2023", ascending=False).head(10).round(2).to_dict("records")
R["seg_2023_total"] = round(float(out23.pred_2023.sum()), 1)
if hasattr(mdl, "feature_importances_"):
    R["seg_feature_importance"] = dict(sorted(zip(FEATS, mdl.feature_importances_.round(3)), key=lambda x: -x[1]))
else:
    te = panel[panel.year == 2022]; pi = permutation_importance(seg_models()[best_seg].fit(panel[(panel.year < 2022) & panel.y.notna()][FEATS], panel[(panel.year < 2022) & panel.y.notna()].y), te[FEATS], te.y, n_repeats=30, random_state=SEED, scoring="neg_mean_absolute_error")
    R["seg_feature_importance"] = dict(sorted(zip(FEATS, pi.importances_mean.round(3)), key=lambda x: -x[1]))

# Figures: 2022 test predicted vs observed; 2023 risk profile
te22 = panel[panel.year == 2022]
fig, axs = plt.subplots(1, 2, figsize=(13, 4.6), gridspec_kw={"width_ratios": [1, 1.9]})
ax = axs[0]; pr = preds_store[best_seg]
ax.scatter(te22.y, pr, s=26, color=CAT[0], edgecolor="#fcfcfb", linewidth=.8)
mx = max(te22.y.max(), pr.max()) * 1.05; ax.plot([0, mx], [0, mx], color="#a8a79f", ls="--", lw=1)
rho = stats.spearmanr(te22.y, pr)[0]
ax.set_title(f"Held-out 2022 test: {best_seg}"); ax.set_xlabel("Observed crashes per 2-km segment, 2022"); ax.set_ylabel("Predicted")
ax.text(.04, .92, f"Spearman ρ = {rho:.2f}", transform=ax.transAxes, color=INK2, fontsize=9)
ax = axs[1]
tiercol = {"Low": "#d6d5cf", "Moderate": "#9ec5f4", "High": "#3987e5", "Very high": "#0d366b"}
ax.bar(out23.from_km + 1, out23.pred_2023, width=1.7, color=out23.risk_tier.astype(str).map(tiercol))
ax.errorbar(out23.from_km + 1, out23.pred_2023, yerr=[(out23.pred_2023 - out23.pi90_low).clip(lower=0), (out23.pi90_high - out23.pred_2023).clip(lower=0)], fmt="none", ecolor="#a8a79f", elinewidth=.7)
for _, r in out23.sort_values("pred_2023", ascending=False).head(5).iterrows():
    ax.annotate(str(r.top_location_names).split(",")[0][:18], (r.from_km + 1, r.pi90_high), xytext=(0, 3), textcoords="offset points", ha="center", rotation=90, fontsize=7.5, color=INK2, va="bottom")
from matplotlib.patches import Patch
ax.legend(handles=[Patch(color=v, label=k) for k, v in tiercol.items()], title="2023 risk tier", fontsize=8, title_fontsize=8.5, ncol=4, loc="upper right")
ax.set_ylim(0, out23.pi90_high.max() * 1.55); ax.set_xlim(0, L)
ax.set_title("Predicted crashes per 2-km segment, 2023 (whiskers = 90% conformal interval)"); ax.set_xlabel("Chainage (km from Ojota, Lagos)"); ax.set_ylabel("Predicted crashes")
fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig11_segment_forecast.png")); plt.close()

# ===================== C) SEVERITY CLASSIFIER =====================
s = d.copy(); s["month"] = s.date.dt.month; s["dow"] = s.date.dt.dayofweek
s["night"] = ((s.hour >= 19) | (s.hour <= 5)).astype(float).where(s.hour.notna())
num = ["hour", "month", "dow", "year", "involved", "multi_vehicle", "chainage_km"]
cat = ["vehicle_type", "ownership", "cause"]
s = s.dropna(subset=["involved"])
X = s[num + cat].copy(); y = s.fatal.values
for c_ in cat: X[c_] = X[c_].astype("category")
cv = StratifiedKFold(5, shuffle=True, random_state=SEED)
hgb = HistGradientBoostingClassifier(max_iter=300, learning_rate=0.04, max_depth=4, min_samples_leaf=30, l2_regularization=1.0,
                                     categorical_features=[X.columns.get_loc(c_) for c_ in cat], random_state=SEED)
p_h = cross_val_predict(hgb, X, y, cv=cv, method="predict_proba")[:, 1]
Xl = s[num + cat].copy(); Xl[num] = Xl[num].fillna(Xl[num].median())
lr = make_pipeline(ColumnTransformer([("n", StandardScaler(), num), ("c", OneHotEncoder(handle_unknown="ignore"), cat)]), LogisticRegression(max_iter=2000, C=0.5))
p_l = cross_val_predict(lr, Xl, y, cv=cv, method="predict_proba")[:, 1]
R["severity"] = {"n": int(len(y)), "fatal_share": round(float(y.mean()), 3),
                 "HGB": {"ROC_AUC": round(roc_auc_score(y, p_h), 3), "PR_AUC": round(average_precision_score(y, p_h), 3), "Brier": round(brier_score_loss(y, p_h), 3)},
                 "Logistic": {"ROC_AUC": round(roc_auc_score(y, p_l), 3), "PR_AUC": round(average_precision_score(y, p_l), 3), "Brier": round(brier_score_loss(y, p_l), 3)}}
# permutation importance on a hold-out split
from sklearn.model_selection import train_test_split
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=.3, stratify=y, random_state=SEED)
hgb.fit(Xtr, ytr)
pi = permutation_importance(hgb, Xte, yte, n_repeats=30, random_state=SEED, scoring="roc_auc")
imp = pd.DataFrame({"feature": X.columns, "importance": pi.importances_mean, "sd": pi.importances_std}).sort_values("importance", ascending=False)
imp.round(4).to_csv(os.path.join(OUT, "ml_severity_importance.csv"), index=False)
R["severity_importance"] = imp.round(4).to_dict("records")
fig, ax = plt.subplots(figsize=(7.5, 4))
nice = {"involved": "Persons involved", "chainage_km": "Location (chainage)", "year": "Year", "hour": "Hour of day", "month": "Month",
        "dow": "Day of week", "vehicle_type": "Vehicle type", "cause": "Probable cause", "ownership": "Ownership", "multi_vehicle": "Multi-vehicle"}
sns.barplot(x=imp.importance, y=imp.feature.map(nice), color=CAT[0], ax=ax, width=.6)
ax.errorbar(imp.importance, np.arange(len(imp)), xerr=imp.sd, fmt="none", ecolor="#a8a79f", elinewidth=1)
ax.set_title("What predicts a fatal crash? (permutation importance)"); ax.set_xlabel("Drop in ROC-AUC when feature is shuffled"); ax.set_ylabel("")
fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig12_severity_importance.png")); plt.close()

json.dump(R, open(os.path.join(OUT, "ml_summary.json"), "w"), indent=1, default=str)
print(json.dumps({k: R[k] for k in ["monthly_backtest_mean", "monthly_best", "forecast_annual", "segment_backtest_mean", "segment_best", "seg_2023_total", "seg_feature_importance", "severity"]}, indent=1, default=str))
print(pd.DataFrame(R["seg_2023_top"])[["from_km", "crashes_2022", "pred_2023", "pi90_low", "pi90_high", "p_top10", "top_location_names"]].to_string())
print(imp.to_string())

"""fig_seg_2027_profile.py — Standalone chart: expected crashes per 2-km section in 2027.
Usage: python3 -I fig_seg_2027_profile.py <out_dir>"""
import sys, os, json, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(__file__))
import style; style.setup()
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.lines import Line2D
OUT = sys.argv[1]; INK2, GRID = "#52514e", "#e4e3df"
f = pd.read_csv(os.path.join(OUT, "hotspot_sections_2027.csv")).sort_values("from_km").reset_index(drop=True)
S = json.load(open(os.path.join(OUT, "seg2027_summary.json"))); T = S["totals_oncorridor"]
TIERS = [("Very likely hot spot (P ≥ 50%)", .5, "#b3261e"), ("Likely (30–50%)", .3, "#eb6834"), ("Possible (15–30%)", .15, "#f4b393"), ("Unlikely (< 15%)", 0, "#c9c8c1")]
f["col"] = f.p_top10.map(lambda p: next(c for _, t, c in TIERS if p >= t))
fig, ax = plt.subplots(figsize=(14, 6.4))
x = f.from_km + 1
ax.bar(x, f.exp_ensemble, width=1.7, color=f.col, zorder=2)
ax.vlines(x, f.lo90, f.hi90, color=INK2, lw=.9, zorder=3)
ax.scatter(x, f.crashes_2022, marker="_", s=90, color="#0b0b0b", lw=1.6, zorder=4)
for r in f[f.p_top10 >= .3].itertuples():
    ax.text(r.from_km + 1, r.hi90 + 3, f"{r.lab} ({r.exp_ensemble:.0f})", rotation=90, ha="center", va="bottom", fontsize=8, color=INK2)
ax.set_xlim(-1, f.to_km.max() + 1); ax.set_ylim(0, f.hi90.max() * 1.45); ax.set_xticks(range(0, 121, 10))
ax.set_xlabel("Chainage (km from Ojota, Lagos → Ibadan)"); ax.set_ylabel("Expected crashes per 2-km section, 2027"); ax.grid(axis="x", visible=False)
ax.legend(handles=[Patch(color=c, label=l) for l, _, c in TIERS] + [Line2D([], [], color=INK2, lw=1, label="90% interval"), Line2D([], [], marker="_", ls="", color="#0b0b0b", markersize=10, mew=1.6, label="Observed 2022")],
          loc="upper right", fontsize=8.5, ncol=3, frameon=True, facecolor="#fcfcfb", edgecolor=GRID)
ax.set_title("Expected road traffic crashes per 2-km section of the Lagos–Ibadan Expressway in 2027", loc="left", fontsize=13, weight="bold", pad=26)
ax.text(0, 1.015, f"Bars: random-forest share of crashes × 2027 ensemble total (about {T['ensemble']:,} located crashes). Colour: probability of being among the busiest 10% of sections. "
        f"Plateau or trend scenarios scale all bars by ×{T['plateau'] / T['ensemble']:.2f} or ×{T['trend'] / T['ensemble']:.2f}.", transform=ax.transAxes, fontsize=8.6, color=INK2)
fig.savefig(os.path.join(OUT, "figures", "fig_expected_crashes_2027.png"), dpi=200, bbox_inches="tight"); plt.close(); print("ok")

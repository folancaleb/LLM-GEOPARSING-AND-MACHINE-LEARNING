"""fig_seg_2027.py — Map and corridor profile of 2-km sections likely to be crash hot spots in 2027.
Usage: python3 -I fig_seg_2027.py <out_dir>"""
import sys, os, json, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(__file__))
import style; style.setup()
import basemap_ne
import matplotlib.pyplot as plt
from matplotlib.patches import Patch, Rectangle
from matplotlib.lines import Line2D
OUT = sys.argv[1]; INK2, GRID = "#52514e", "#e4e3df"
f = pd.read_csv(os.path.join(OUT, "forecast_segments_2027.csv")); cl = pd.read_csv(os.path.join(OUT, "centreline_derived.csv"))
S = json.load(open(os.path.join(OUT, "seg2027_summary.json"))); bt = {r["model"]: r for r in S["backtest_mean"]}
TIERS = [("Very likely (P ≥ 50%)", .5, "#b3261e"), ("Likely (30–50%)", .3, "#eb6834"), ("Possible (15–30%)", .15, "#f4b393"), ("Unlikely (< 15%)", 0, "#c9c8c1")]
def tier(pv):
    for lab, t, c in TIERS:
        if pv >= t: return lab, c
f["tier2"], f["col"] = zip(*f.p_top10.map(tier))
f = f.sort_values("from_km").reset_index(drop=True)
def label(r):
    n = str(r.top_location_names).split(",")[0].strip().title()
    return {"Paved": "Deeper Life / Lotto", "Km122-Guru Area": "km 10–12"}.get(n, n)
f["lab"] = f.apply(label, axis=1)
def seg_xy(a, b):
    ts = np.r_[a, cl.chainage_km[(cl.chainage_km > a) & (cl.chainage_km < b)].values, min(b, cl.chainage_km.max())]
    return np.interp(ts, cl.chainage_km, cl.lon), np.interp(ts, cl.chainage_km, cl.lat)
ASP = 1 / np.cos(np.deg2rad(6.9))
fig = plt.figure(figsize=(14, 12.2)); gs = fig.add_gridspec(2, 2, height_ratios=[1.45, 1], width_ratios=[1.05, 1], hspace=0.22, wspace=0.12)

def draw_map(ax, XL, YL, lw_hot, lw_low, nlab, credit=True, scale_km=20, exclude=None, sides=None):
    basemap_ne.draw(ax, extent=XL + YL)
    ax.plot(cl.lon, cl.lat, color="#fcfcfb", lw=lw_low + 4, solid_capstyle="round", zorder=1, alpha=.9)
    for r in f.itertuples():
        x, y = seg_xy(r.from_km, r.to_km); hot = r.p_top10 >= .15
        ax.plot(x, y, color=r.col, lw=lw_hot if hot else lw_low, solid_capstyle="butt", zorder=3 if hot else 2)
    top = f[(f.p_top10 >= .3)]
    vis = top[[XL[0] < np.interp(m, cl.chainage_km, cl.lon) < XL[1] and YL[0] < np.interp(m, cl.chainage_km, cl.lat) < YL[1] for m in (top.from_km + 1)]]
    if exclude is not None:
        ex = [(exclude[0][0] < np.interp(m, cl.chainage_km, cl.lon) < exclude[0][1]) and (exclude[1][0] < np.interp(m, cl.chainage_km, cl.lat) < exclude[1][1]) for m in (vis.from_km + 1)]
        vis = vis[~np.array(ex, bool)] if len(vis) else vis
    vis = vis.sort_values("p_top10", ascending=False).head(nlab).sort_values("from_km")
    for i, r in enumerate(vis.itertuples()):
        mx, my = np.interp(r.from_km + 1, cl.chainage_km, cl.lon), np.interp(r.from_km + 1, cl.chainage_km, cl.lat)
        side = (sides or {}).get(int(r.from_km), 1 if i % 2 == 0 else -1)
        ax.annotate(f"{r.lab}\nkm {r.from_km}–{r.to_km} · {100 * r.p_top10:.0f}%", (mx, my), xytext=(30 * side, 6 * (i % 3 - 1)), textcoords="offset points",
                    ha="left" if side > 0 else "right", va="center", fontsize=7.6, color="#0b0b0b", zorder=6,
                    bbox=dict(boxstyle="round,pad=0.2", fc="#fcfcfb", ec=r.col, lw=1, alpha=.95), arrowprops=dict(arrowstyle="-", color=INK2, lw=.6))
    ax.set_xlim(*XL); ax.set_ylim(*YL); ax.set_aspect(ASP); ax.set_xlabel("Longitude (°E)"); ax.set_ylabel("Latitude (°N)")
    dlon = scale_km / (111.32 * np.cos(np.deg2rad(6.9))); x0, y0 = XL[1] - (XL[1] - XL[0]) * .05 - dlon, YL[0] + (YL[1] - YL[0]) * .06
    ax.plot([x0, x0 + dlon], [y0, y0], color="#0b0b0b", lw=2.5, solid_capstyle="butt", zorder=7); ax.plot([x0, x0 + dlon / 2], [y0, y0], color="#fcfcfb", lw=1.2, solid_capstyle="butt", zorder=7)
    ax.text(x0 + dlon / 2, y0 + (YL[1] - YL[0]) * .015, f"{scale_km} km", fontsize=7, ha="center", zorder=7)
    if credit: ax.text(XL[1] - (XL[1] - XL[0]) * .01, YL[0] + (YL[1] - YL[0]) * .01, basemap_ne.CREDIT, fontsize=6.2, color="#3a3936", ha="right", va="bottom", bbox=dict(boxstyle="round,pad=0.2", fc="#fcfcfb", ec="none", alpha=.85), zorder=7)

ax = fig.add_subplot(gs[0, 0]); XL, YL = (3.20, 4.05), (6.45, 7.50)
zx, zy = (3.33, 3.47), (6.57, 6.76)
draw_map(ax, XL, YL, 8, 3.5, 4, exclude=(zx, zy), sides={26: 1, 54: 1}); ax.add_patch(Rectangle((zx[0], zy[0]), zx[1] - zx[0], zy[1] - zy[0], fill=False, ec="#0b0b0b", lw=1.2, ls="--", zorder=8))
ax.text(zx[1] + .01, zy[1], "(b)", fontsize=9, weight="bold", zorder=8)
ax.annotate("N", xy=(XL[0] + 0.05, YL[1] - 0.04), xytext=(XL[0] + 0.05, YL[1] - 0.12), ha="center", fontsize=10, weight="bold", arrowprops=dict(arrowstyle="-|>", color="#0b0b0b", lw=1.5), zorder=7)
ax.legend(handles=[Line2D([], [], color=c, lw=6, label=l) for l, _, c in TIERS], title="Probability of being among the\nbusiest 10% of sections in 2027", title_fontsize=8.5,
          loc="upper left", bbox_to_anchor=(0.09, 0.995), fontsize=8.3, frameon=True, facecolor="#fcfcfb", edgecolor=GRID, framealpha=.95)
ax.set_title("(a) Whole corridor, 2-km sections")
ax = fig.add_subplot(gs[0, 1]); draw_map(ax, zx, zy, 12, 5, 8, credit=False, scale_km=2, sides={2: 1, 4: 1, 8: 1, 12: -1, 14: 1, 18: -1}); ax.set_title("(b) Lagos end (km 0–30), enlarged"); ax.set_ylabel("")

ax = fig.add_subplot(gs[1, :])
x = f.from_km + 1
ax.bar(x, f.exp_ensemble, width=1.7, color=f.col, zorder=2)
ax.vlines(x, f.lo90, f.hi90, color=INK2, lw=.9, zorder=3)
ax.scatter(x, f.crashes_2022, marker="_", s=90, color="#0b0b0b", lw=1.6, zorder=4)
for r in f[f.p_top10 >= .3].itertuples():
    ax.text(r.from_km + 1, r.hi90 + 3, r.lab, rotation=90, ha="center", va="bottom", fontsize=7.6, color=INK2)
ax.set_xlim(-1, f.to_km.max() + 1); ax.set_ylim(0, f.hi90.max() * 1.42)
ax.set_xlabel("Chainage (km from Ojota, Lagos → Ibadan)"); ax.set_ylabel("Crashes per 2-km section"); ax.grid(axis="x", visible=False)
ax.legend(handles=[Patch(color=c, label=l) for l, _, c in TIERS] + [Line2D([], [], color=INK2, lw=1, label="90% interval"), Line2D([], [], marker="_", ls="", color="#0b0b0b", markersize=10, mew=1.6, label="Observed 2022")],
          loc="upper right", fontsize=8, ncol=3, frameon=True, facecolor="#fcfcfb", edgecolor=GRID)
ax.set_title(f"(c) Expected crashes per section in 2027 (ensemble total; plateau–trend range ×{S['totals_oncorridor']['plateau'] / S['totals_oncorridor']['ensemble']:.2f}–×{S['totals_oncorridor']['trend'] / S['totals_oncorridor']['ensemble']:.2f})")
rf_, hm = bt["Random forest (5-yr ahead)"], bt["Historical mean share"]
fig.suptitle("Sections of the Lagos–Ibadan Expressway likely to be crash hot spots in 2027", x=0.01, ha="left", fontsize=15, weight="bold", y=0.995)
fig.text(0.01, 0.962, f"Random-forest forecast made five years ahead from the 2013–2022 record. Back-test (2020–2022, five years ahead): rank correlation {rf_['Spearman']:.2f} (historical average {hm['Spearman']:.2f}); "
         f"on average {rf_['top10_overlap']:.0f} of the 6 busiest sections correctly identified.", fontsize=9.4, color=INK2)
fig.savefig(os.path.join(OUT, "figures", "fig_hotspots_2027.png"), dpi=200, bbox_inches="tight"); plt.close()
f[["from_km", "to_km", "lab", "top_location_names", "crashes_2022", "mean_2013_2022", "exp_ensemble", "lo90", "hi90", "exp_plateau", "exp_trend", "p_top10", "p_hot95", "tier2"]].sort_values("p_top10", ascending=False).round(3).to_csv(os.path.join(OUT, "hotspot_sections_2027.csv"), index=False)
print("ok")

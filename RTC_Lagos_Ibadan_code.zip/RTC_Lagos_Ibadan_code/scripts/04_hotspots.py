"""04_hotspots.py — Getis-Ord Gi* on road segments, emerging-hotspot trend, DBSCAN clusters, sensitivity.
Usage: python3 -I 04_hotspots.py <out_dir>"""
import sys, os, json, numpy as np, pandas as pd
from scipy import stats
from sklearn.cluster import DBSCAN
sys.path.insert(0, os.path.dirname(__file__))
import style; style.setup()
import matplotlib.pyplot as plt, seaborn as sns
from matplotlib.patches import Patch
from style import CAT, INK2

OUT = sys.argv[1]; FIG = os.path.join(OUT, "figures")
d = pd.read_csv(os.path.join(OUT, "rtc_lagos_ibadan_clean_2013_2022.csv"), parse_dates=["date"])
c = pd.read_csv(os.path.join(OUT, "centreline_derived.csv"))
L = c.chainage_km.max()
p = d[d.on_corridor].copy()
# placeholder-coordinate flag: same coordinate pair reused for >=5 distinct location names
p["ck"] = p.lat.round(4).astype(str) + "," + p.lon.round(4).astype(str)
nn = d.assign(ck=d.lat.round(4).astype(str) + "," + d.lon.round(4).astype(str)).groupby("ck").loc_norm.nunique()
p["placeholder"] = p.ck.map(nn).fillna(0) >= 5

def gistar(x, band):
    """Getis-Ord Gi* for a 1-D chain of segments; binary weights within `band` segments (self included)."""
    x = np.asarray(x, float); n = len(x); xb = x.mean(); s = np.sqrt((x ** 2).mean() - xb ** 2)
    z = np.zeros(n)
    for i in range(n):
        j = np.arange(max(0, i - band), min(n, i + band + 1)); w = len(j)
        num = x[j].sum() - xb * w
        den = s * np.sqrt((n * w - w ** 2) / (n - 1))
        z[i] = num / den if den > 0 else 0
    return z

def bh(pv, q=0.05):
    pv = np.asarray(pv); o = np.argsort(pv); m = len(pv)
    thr = (np.arange(1, m + 1) / m) * q; ok = pv[o] <= thr
    k = np.where(ok)[0].max() + 1 if ok.any() else 0
    r = np.zeros(m, bool); r[o[:k]] = True; return r

def classify(z):
    return np.select([z >= 2.576, z >= 1.960, z >= 1.645, z <= -1.960], ["Hot 99%", "Hot 95%", "Hot 90%", "Cold 95%"], "Not significant")

def segment_table(df, size, weight=None):
    seg = (df.chainage_km // size).astype(int)
    nseg = int(np.ceil(L / size))
    cnt = (df.assign(seg=seg).groupby("seg")[weight].sum() if weight else seg.value_counts()).reindex(range(nseg), fill_value=0)
    t = pd.DataFrame({"seg": range(nseg), "from_km": np.arange(nseg) * size, "to_km": np.arange(1, nseg + 1) * size, "n": cnt.values})
    t["z"] = gistar(t.n, band=1); t["p"] = 2 * stats.norm.sf(np.abs(t.z)); t["class"] = classify(t.z)
    t["hot_fdr"] = bh(t.p) & (t.z > 0)
    return t

R = {}
# ---------- primary: 2-km, all crashes
t2 = segment_table(p, 2)
# Dominant place names per segment (for interpretation)
p["seg2"] = (p.chainage_km // 2).astype(int)
names = p.groupby("seg2").location_raw.agg(lambda s: ", ".join(s.astype(str).str.upper().str.strip().value_counts().head(3).index))
t2["top_location_names"] = t2.seg.map(names).fillna("")
fat = p.groupby("seg2").agg(killed=("killed", "sum"), fatal=("fatal", "sum"))
t2 = t2.join(fat, on="seg").fillna({"killed": 0, "fatal": 0})
t2["placeholder_share"] = t2.seg.map(p.groupby("seg2").placeholder.mean()).fillna(0).round(2)
t2.to_csv(os.path.join(OUT, "hotspots_gistar_2km.csv"), index=False)
R["gi_2km_hot"] = t2[t2.z >= 1.96].sort_values("z", ascending=False)[["from_km", "to_km", "n", "killed", "z", "class", "hot_fdr", "placeholder_share", "top_location_names"]].round(2).to_dict("records")

# ---------- inter-urban section (>= 20 km) Gi*, so the dense Lagos urban stretch does not mask rural hotspots
pr = p[p.chainage_km >= 20]
tr = segment_table(pr.assign(chainage_km=pr.chainage_km), 2)
tr = tr[tr.from_km >= 20].copy()
tr["z"] = gistar(tr.n.values, 1); tr["p"] = 2 * stats.norm.sf(np.abs(tr.z)); tr["class"] = classify(tr.z); tr["hot_fdr"] = bh(tr.p) & (tr.z > 0)
tr["top_location_names"] = tr.seg.map(names).fillna("")
tr["killed"] = tr.seg.map(fat.killed).fillna(0)
tr.to_csv(os.path.join(OUT, "hotspots_gistar_2km_interurban.csv"), index=False)
R["gi_interurban_hot"] = tr[tr.z >= 1.96].sort_values("z", ascending=False)[["from_km", "to_km", "n", "killed", "z", "class", "hot_fdr", "top_location_names"]].round(2).to_dict("records")

# ---------- sensitivity
t5 = segment_table(p, 5); t5.to_csv(os.path.join(OUT, "hotspots_gistar_5km.csv"), index=False)
R["gi_5km_hot"] = t5[t5.z >= 1.96][["from_km", "to_km", "n", "z", "class"]].round(2).to_dict("records")
tnp = segment_table(p[~p.placeholder], 2)
tk = segment_table(p, 2, weight="killed")
R["sens"] = {
    "placeholder_records_on_corridor": int(p.placeholder.sum()), "on_corridor": int(len(p)),
    "hot95_2km_all": t2.loc[t2.z >= 1.96, "from_km"].tolist(),
    "hot95_2km_no_placeholder": tnp.loc[tnp.z >= 1.96, "from_km"].tolist(),
    "hot95_2km_killed_weighted": tk.loc[tk.z >= 1.96, "from_km"].tolist(),
    "spearman_z_all_vs_noplaceholder": round(stats.spearmanr(t2.z, tnp.z)[0], 2),
    "spearman_z_count_vs_killed": round(stats.spearmanr(t2.z, tk.z)[0], 2)}

# ---------- emerging hotspot (simplified): yearly Gi* z + Mann–Kendall (Kendall tau vs year)
years = sorted(p.year.unique())
Z = pd.DataFrame({yr: segment_table(p[p.year == yr], 2).z.values for yr in years})
def emerge(row, hot_all):
    tau, pv = stats.kendalltau(years, row.values)
    nhot = int((row.values >= 1.96).sum()); last = row.values[-1] >= 1.96
    if not hot_all and nhot == 0: return "No pattern", tau, pv
    if nhot >= 8: lab = "Persistent hotspot"
    elif last and nhot <= 2 and not (row.values[:-2] >= 1.96).any(): lab = "New hotspot"
    elif nhot >= 5: lab = "Consecutive/frequent hotspot"
    elif nhot >= 1: lab = "Sporadic hotspot"
    else: lab = "No pattern"
    if lab != "No pattern" and pv < 0.05: lab = ("Intensifying " if tau > 0 else "Diminishing ") + lab.split(" ")[0].lower() + " hotspot"
    return lab, tau, pv
em = [emerge(Z.iloc[i], t2.z.iloc[i] >= 1.96) for i in range(len(Z))]
t2["emerging"] = [e[0] for e in em]; t2["mk_tau"] = [round(e[1], 2) if not np.isnan(e[1]) else 0 for e in em]; t2["mk_p"] = [round(e[2], 3) if not np.isnan(e[2]) else 1 for e in em]
t2["years_hot"] = (Z.values >= 1.96).sum(1)
t2.to_csv(os.path.join(OUT, "hotspots_gistar_2km.csv"), index=False)
R["emerging_counts"] = t2.emerging.value_counts().to_dict()

# ---------- DBSCAN point clusters (haversine, eps=400 m, min 25 crashes)
X = np.deg2rad(p[["lat", "lon"]].values)
lab = DBSCAN(eps=0.4 / 6371.0, min_samples=25, metric="haversine").fit_predict(X)
p["cluster"] = lab
cl = p[p.cluster >= 0].groupby("cluster").agg(n=("lat", "size"), killed=("killed", "sum"), lat=("lat", "median"), lon=("lon", "median"),
     km=("chainage_km", "median"), placeholder_share=("placeholder", "mean"),
     names=("location_raw", lambda s: ", ".join(s.astype(str).str.upper().str.strip().value_counts().head(3).index))).sort_values("n", ascending=False)
cl.round(3).to_csv(os.path.join(OUT, "hotspots_dbscan_clusters.csv"))
R["dbscan"] = {"n_clusters": int(cl.shape[0]), "share_in_clusters": round(float((p.cluster >= 0).mean() * 100), 1),
               "top": cl.head(10).round(3).reset_index().to_dict("records")}

# ---------- FIGURES
order = ["Hot 99%", "Hot 95%", "Hot 90%", "Not significant", "Cold 95%"]
pal = {"Hot 99%": "#d03b3b", "Hot 95%": "#ec835a", "Hot 90%": "#f4b393", "Not significant": "#d6d5cf", "Cold 95%": "#6da7ec"}
fig, axs = plt.subplots(2, 1, figsize=(13, 7.6))
for ax, tt, ttl in [(axs[0], t2, "a) Whole corridor, 2-km segments"), (axs[1], tr, "b) Inter-urban section only (≥ 20 km), Gi* recomputed")]:
    ax.bar(tt.from_km + 1, tt.n, width=1.7, color=tt["class"].map(pal), edgecolor="none")
    for _, r in tt[(tt.z >= 1.96) & (tt.n >= 50)].iterrows():
        nm = r.top_location_names.split(",")[0][:20]
        ax.annotate(nm, (r.from_km + 1, r.n), xytext=(0, 4), textcoords="offset points", ha="center", fontsize=7.5, color=INK2, rotation=90, va="bottom")
    ax.set_xlim(0, L); ax.set_ylim(0, tt.n.max() * 1.6); ax.set_ylabel("Crashes 2013–2022"); ax.set_title(ttl)
axs[1].set_xlabel("Chainage (km from Ojota, Lagos → Iwo Road, Ibadan)")
axs[0].legend(handles=[Patch(color=pal[k], label=k) for k in order], ncol=5, loc="upper right", fontsize=8.5)
fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig07_gistar_profile.png")); plt.close()

# map of segments coloured by class + DBSCAN clusters
mid = (t2.from_km + 1).values
seg_lat = np.interp(mid, c.chainage_km, c.lat); seg_lon = np.interp(mid, c.chainage_km, c.lon)
fig, axs = plt.subplots(1, 2, figsize=(11, 8), sharey=True)
ax = axs[0]; ax.plot(c.lon, c.lat, color="#d6d5cf", lw=6, zorder=1, solid_capstyle="round")
for k in order[::-1]:
    m = t2["class"].values == k
    ax.scatter(seg_lon[m], seg_lat[m], s=np.where(k.startswith("Hot"), 90, 25), color=pal[k], label=k, zorder=3, edgecolor="#fcfcfb", linewidth=1)
ri = tr[tr.z >= 1.96]
ax.scatter(np.interp(ri.from_km + 1, c.chainage_km, c.lon), np.interp(ri.from_km + 1, c.chainage_km, c.lat), s=160, facecolor="none", edgecolor="#d03b3b", linewidth=1.8, zorder=4, label="Inter-urban hot (≥95%)")
ax.set_aspect("equal"); ax.set_title("Gi* class per 2-km segment"); ax.legend(loc="lower right", fontsize=8.5); ax.set_xlabel("Longitude"); ax.set_ylabel("Latitude")
ax = axs[1]; ax.plot(c.lon, c.lat, color="#d6d5cf", lw=6, zorder=1, solid_capstyle="round")
ax.scatter(p.lon, p.lat, s=3, color="#a8a79f", zorder=2, linewidths=0)
top = cl.head(12)
ax.scatter(top.lon, top.lat, s=top.n * 1.2, color=CAT[0], alpha=.55, edgecolor=CAT[0], zorder=3)
for i, (_, r) in enumerate(top.head(8).iterrows()):
    ax.annotate(f"{r.names.split(',')[0][:20]} ({r.n})", (r.lon, r.lat), xytext=(14, [-10, 4, -2, 8, 0, 6, -6, 2][i] * (1 if r.lat > 6.7 else 1.6)), textcoords="offset points", fontsize=7.5, color=INK2)
ax.set_aspect("equal"); ax.set_title("DBSCAN crash clusters (ε = 400 m, ≥25 crashes)"); ax.set_xlabel("Longitude")
fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig08_hotspot_maps.png")); plt.close()

# emerging hotspot heat: yearly Gi* z
fig, ax = plt.subplots(figsize=(8, 10))
Zs = Z.copy(); Zs.index = t2.from_km
sns.heatmap(Zs, cmap=style.DIV, center=0, vmin=-3, vmax=6, linewidths=.3, linecolor="#fcfcfb", cbar_kws={"label": "Gi* z-score"}, ax=ax)
ax.set_yticks(np.arange(0, len(Zs), 5) + .5); ax.set_yticklabels(Zs.index[::5]); ax.set_ylabel("Chainage (km)")
ax.set_title("Year-by-year Gi* z-scores (emerging-hotspot view)")
fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig09_emerging_gistar.png")); plt.close()

json.dump(R, open(os.path.join(OUT, "hotspot_summary.json"), "w"), indent=1, default=str)
print(json.dumps(R, indent=1, default=str)[:6000])
print(t2[t2.z >= 1.96][["from_km", "n", "z", "class", "emerging", "years_hot", "mk_tau", "mk_p"]].to_string())

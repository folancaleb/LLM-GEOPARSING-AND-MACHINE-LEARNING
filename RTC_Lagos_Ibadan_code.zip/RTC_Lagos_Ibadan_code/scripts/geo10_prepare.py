"""geo10_prepare.py — Build the geoparser input for each year (file_year, row_order, SN, COMMAND, LOCATION) from the
FRSC returns WITHOUT coordinates (RTC_LAG_IBA). Rows are filtered exactly as in 01_clean.py (non-empty DATE), so
row_order matches the cleaned attribute table.
Usage: python3 -I geo10_prepare.py <raw_no_coords_dir> <out_dir>"""
import sys, os, pandas as pd
RAW, OUT = sys.argv[1], sys.argv[2]; os.makedirs(OUT, exist_ok=True)
FILES = {2013: "2013 MERGED ROUTES.csv", 2014: "2014 MERGED ROUTES.csv", 2015: "2015 MERGED ROUTES.csv", 2016: "2016 MERGED ROUTES.csv",
         2017: "2017 MERGED ROUTES CSV.csv", 2018: "2018 MERGED ROUTES CSV.csv", 2019: "2019 MERGED ROUTES.csv", 2020: "2020 MERGED ROUTES CSV.csv",
         2021: "2021 MERGED ROUTES CSV.csv", 2022: "2022 MERGED ROUTES CSV.csv"}
for yr, fn in FILES.items():
    d = pd.read_csv(os.path.join(RAW, fn), encoding="latin1", dtype=str, low_memory=False)
    d.columns = [c.strip() for c in d.columns]
    d = d[d["DATE"].notna() & (d["DATE"].str.strip() != "")].copy()
    if yr == 2019 and "UNKNOWN" in d.columns:            # 2019 header shift: place name sits in the extra column
        d["LOCATION"] = d["UNKNOWN"].where(d["UNKNOWN"].notna(), d["LOCATION"])
    o = pd.DataFrame({"file_year": yr, "row_order": range(len(d)), "SN": d["S/N"].values, "COMMAND": d["COMMAND"].values, "LOCATION": d["LOCATION"].fillna("(blank)").values})
    o.to_csv(os.path.join(OUT, f"in_{yr}.csv"), index=False); print(yr, len(o))

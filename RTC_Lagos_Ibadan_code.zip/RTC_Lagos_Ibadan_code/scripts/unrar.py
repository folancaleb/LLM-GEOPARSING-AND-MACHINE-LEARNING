import ctypes, sys, os
la = ctypes.CDLL('libarchive.so.13')
la.archive_read_new.restype = ctypes.c_void_p
la.archive_entry_pathname.restype = ctypes.c_char_p
la.archive_entry_pathname.argtypes=[ctypes.c_void_p]
la.archive_error_string.restype = ctypes.c_char_p
for f in ['archive_read_support_filter_all','archive_read_support_format_all']:
    getattr(la,f).argtypes=[ctypes.c_void_p]
la.archive_read_open_filename.argtypes=[ctypes.c_void_p, ctypes.c_char_p, ctypes.c_size_t]
la.archive_read_next_header.argtypes=[ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)]
la.archive_read_data.argtypes=[ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t]
la.archive_read_data.restype=ctypes.c_ssize_t
la.archive_error_string.argtypes=[ctypes.c_void_p]
src, out = sys.argv[1], sys.argv[2]
a = la.archive_read_new(); la.archive_read_support_filter_all(a); la.archive_read_support_format_all(a)
assert la.archive_read_open_filename(a, src.encode(), 10240)==0, la.archive_error_string(a)
e = ctypes.c_void_p()
while True:
    r = la.archive_read_next_header(a, ctypes.byref(e))
    if r==1: break
    if r<0: print('ERR', la.archive_error_string(a)); break
    name = la.archive_entry_pathname(e).decode(errors='replace')
    buf = ctypes.create_string_buffer(65536); chunks=[]
    while True:
        n = la.archive_read_data(a, buf, 65536)
        if n<0: print('DATA ERR', la.archive_error_string(a)); break
        if n==0: break
        chunks.append(buf.raw[:n])
    safe = os.path.basename(name)
    if safe:
        open(os.path.join(out, safe),'wb').write(b''.join(chunks)); print(name, sum(map(len,chunks)))

"""geo10_export.py — Export geoparsed 2013–2022 crashes and segment hotspots.
Outputs: CSV (all records), point shapefile, 2-km segment polyline shapefile with Gi*, GeoJSON, KML, Leaflet HTML.
Usage: python3 -I geo10_export.py <combined_final.csv> <centreline.csv> <out_dir>"""
import sys, os, json, struct, numpy as np, pandas as pd
from scipy import stats
SRC, CL, OUT = sys.argv[1:4]; os.makedirs(os.path.join(OUT, "shapefiles"), exist_ok=True)
m = pd.read_csv(SRC, low_memory=False); cl = pd.read_csv(CL)
KX, KY = 111.32 * np.cos(np.deg2rad(6.9)), 110.57
num = lambda c: pd.to_numeric(m[c], errors="coerce")

d = pd.DataFrame({
    "YEAR": m.file_year.astype(int), "ROW": m.row_order.astype(int), "SN": m.SN.fillna("").astype(str).str.strip(),
    "COMMAND": m.COMMAND.fillna("").astype(str).str.strip(),
    "DATE": pd.to_datetime(m.date, errors="coerce").dt.strftime("%Y-%m-%d").fillna(""),
    "DATE_FLAG": np.where(m.date_method.astype(str).str.contains("ambiguous"), "day/month inferred", ""),
    "HOUR": num("hour"), "LOCATION": m.LOCATION.fillna("").astype(str).str.strip(),
    "MATCH_KEY": m.geo_matched_key.fillna(""), "METHOD": m.geo_method.fillna(""), "CONFIDENCE": m.geo_confidence.replace("None", "").fillna(""),
    "N_SUPPORT": num("geo_n_support").fillna(0).astype(int), "N_YEARS": num("geo_n_years").fillna(0).astype(int),
    "AGREE_SHR": num("geo_cluster_share").round(2), "ALT_SITE": m.geo_competing_site.fillna(""),
    "IN_TERR": m.geo_within_command_territory.fillna(""),
    "LAT": num("geo_lat").round(6), "LON": num("geo_lon").round(6),
    "CHAIN_KM": num("geo_chainage_km").round(2), "DIST_EXPWY": num("geo_dist_to_expressway_km").round(2),
    "VEH_TYPE": m.vehicle_type.fillna(""), "OWNERSHIP": m.ownership.fillna(""), "CAUSE": m.cause.fillna(""),
    "INJURED": num("injured").fillna(0).astype(int), "KILLED": num("killed").fillna(0).astype(int), "INVOLVED": num("involved").fillna(0).astype(int),
    "SEVERITY": m.severity.fillna(""), "DUPLICATE": np.where(m.is_duplicate == True, "yes", ""),
    "ORIG_LAT": num("lat").where(m.coord_source.astype(str).str.startswith("recorded")).round(6),
    "ORIG_LON": num("lon").where(m.coord_source.astype(str).str.startswith("recorded")).round(6),
})
d["ON_EXPWY"] = np.where(d.LAT.isna(), "", np.where(d.DIST_EXPWY <= 1.0, "yes", "no"))
d["ORIG_DIFF"] = np.hypot((d.LON - d.ORIG_LON) * KX, (d.LAT - d.ORIG_LAT) * KY).round(2)
d.to_csv(os.path.join(OUT, "RTC_Lagos_Ibadan_2013_2022_geoparsed.csv"), index=False)
pts = d[d.LAT.notna()].reset_index(drop=True)

# ---------------- generic shapefile writer (points = type 1, polylines = type 3) ----------------
def dbf_write(path, df):
    fields = []
    for c in df.columns:
        s = df[c]
        if pd.api.types.is_float_dtype(s): fields.append((c, "N", 14, 6 if c in ("LAT", "LON", "ORIG_LAT", "ORIG_LON") else 3))
        elif pd.api.types.is_integer_dtype(s): fields.append((c, "N", 10, 0))
        else: fields.append((c, "C", int(min(254, max(2, s.astype(str).map(lambda v: len(v.encode("latin1", "replace"))).max()))), 0))
    n = len(df); reclen = 1 + sum(f[2] for f in fields); hlen = 32 + 32 * len(fields) + 1
    b = bytearray(struct.pack("<BBBBIHH20x", 3, 126, 10, 16, n, hlen, reclen))
    for c, t, w, dec in fields: b += struct.pack("<11sc4xBB14x", c[:10].encode("ascii"), t.encode(), w, dec)
    b += b"\r"
    for i in range(n):
        b += b" "
        for c, t, w, dec in fields:
            v = df[c].iloc[i]
            if t == "N": s = "" if pd.isna(v) else (f"{float(v):.{dec}f}" if dec else str(int(v))); b += s.rjust(w)[:w].encode("ascii")
            else: b += str("" if pd.isna(v) else v).encode("latin1", "replace")[:w].ljust(w)
    b += b"\x1a"; open(path, "wb").write(b)
PRJ = 'GEOGCS["GCS_WGS_1984",DATUM["D_WGS_1984",SPHEROID["WGS_1984",6378137.0,298.257223563]],PRIMEM["Greenwich",0.0],UNIT["Degree",0.0174532925199433]]'
def shp_write(base, geoms, attrs, kind):
    allxy = np.vstack([np.atleast_2d(g) for g in geoms]); bbox = (allxy[:, 0].min(), allxy[:, 1].min(), allxy[:, 0].max(), allxy[:, 1].max())
    stype = 1 if kind == "point" else 3
    recs = []
    for g in geoms:
        if kind == "point": recs.append(struct.pack("<idd", 1, g[0], g[1]))
        else:
            g = np.asarray(g); bb = (g[:, 0].min(), g[:, 1].min(), g[:, 0].max(), g[:, 1].max())
            recs.append(struct.pack("<i4dii", 3, *bb, 1, len(g)) + struct.pack("<i", 0) + b"".join(struct.pack("<dd", x, y) for x, y in g))
    def hdr(words): return struct.pack(">i5ii", 9994, 0, 0, 0, 0, 0, words) + struct.pack("<ii4d4d", 1000, stype, *bbox, 0, 0, 0, 0)
    shp_len = 50 + sum(4 + len(r) // 2 for r in recs)
    shp = bytearray(hdr(shp_len)); shx = bytearray(hdr(50 + 4 * len(recs))); off = 50
    for i, r in enumerate(recs):
        shp += struct.pack(">ii", i + 1, len(r) // 2) + r; shx += struct.pack(">ii", off, len(r) // 2); off += 4 + len(r) // 2
    open(base + ".shp", "wb").write(shp); open(base + ".shx", "wb").write(shx)
    dbf_write(base + ".dbf", attrs); open(base + ".prj", "w").write(PRJ); open(base + ".cpg", "w").write("ISO-8859-1")
    # verify
    s = open(base + ".shp", "rb").read(); assert struct.unpack(">i", s[24:28])[0] * 2 == len(s)
    x = open(base + ".shx", "rb").read(); assert struct.unpack(">i", x[24:28])[0] * 2 == len(x)
    f = open(base + ".dbf", "rb").read(); nrec = struct.unpack("<I", f[4:8])[0]; hl, rl = struct.unpack("<HH", f[8:12]); assert nrec == len(geoms) and hl + rl * nrec + 1 == len(f)

pt_cols = ["YEAR", "SN", "COMMAND", "DATE", "HOUR", "LOCATION", "MATCH_KEY", "METHOD", "CONFIDENCE", "N_SUPPORT", "N_YEARS", "AGREE_SHR",
           "ALT_SITE", "IN_TERR", "LAT", "LON", "CHAIN_KM", "DIST_EXPWY", "ON_EXPWY", "VEH_TYPE", "OWNERSHIP", "CAUSE",
           "INJURED", "KILLED", "INVOLVED", "SEVERITY", "DUPLICATE"]
pt_attr = pts[pt_cols].copy(); pt_attr["METHOD"] = pt_attr.METHOD.str.slice(0, 60)
shp_write(os.path.join(OUT, "shapefiles", "RTC_crash_points_2013_2022"), list(zip(pts.LON, pts.LAT)), pt_attr, "point")

# ---------------- 2-km segments with Gi* from geoparsed points ----------------
L = cl.chainage_km.max(); nseg = int(np.ceil(L / 2))
def gistar(x, band=1):
    x = np.asarray(x, float); n = len(x); xb = x.mean(); s = np.sqrt((x ** 2).mean() - xb ** 2); z = np.zeros(n)
    for i in range(n):
        j = np.arange(max(0, i - band), min(n, i + band + 1)); w = len(j)
        den = s * np.sqrt((n * w - w ** 2) / (n - 1)); z[i] = (x[j].sum() - xb * w) / den if den > 0 else 0
    return z
cls = lambda z: np.select([z >= 2.576, z >= 1.960, z >= 1.645], ["Hot 99%", "Hot 95%", "Hot 90%"], "Not significant")
on = pts[(pts.ON_EXPWY == "yes") & (pts.DUPLICATE != "yes")].copy(); on["SEG"] = (on.CHAIN_KM // 2).astype(int).clip(0, nseg - 1)
hm = on[on.CONFIDENCE.isin(["High", "Medium"])]
cnt = np.bincount(on.SEG, minlength=nseg); cnt_hm = np.bincount(hm.SEG, minlength=nseg)
kil = on.groupby("SEG").KILLED.sum().reindex(range(nseg), fill_value=0).values
z_all, z_hm = gistar(cnt), gistar(cnt_hm)
inter = np.arange(nseg) * 2 >= 20; z_int = np.full(nseg, np.nan); z_int[inter] = gistar(cnt[inter])
top = on.groupby("SEG").MATCH_KEY.agg(lambda s: ", ".join(s.value_counts().index[:2])).reindex(range(nseg), fill_value="")
yrs = {y: np.bincount(on[on.YEAR == y].SEG, minlength=nseg) for y in range(2013, 2023)}
tau = []; pv = []
for i in range(nseg):
    zz = [gistar(yrs[y])[i] for y in range(2013, 2023)]; r = stats.kendalltau(range(10), zz); tau.append(0 if np.isnan(r[0]) else r[0]); pv.append(1 if np.isnan(r[1]) else r[1])
segs = pd.DataFrame({"SEG_ID": range(nseg), "FROM_KM": np.arange(nseg) * 2, "TO_KM": np.minimum(np.arange(1, nseg + 1) * 2, L).round(2),
                     "CRASHES": cnt, "CRASH_HM": cnt_hm, "KILLED": kil, "GI_Z": z_all.round(3), "GI_CLASS": cls(z_all),
                     "GI_Z_HM": z_hm.round(3), "GI_CLS_HM": cls(z_hm), "GI_Z_INTER": np.round(z_int, 3),
                     "GI_CLS_INT": np.where(inter, cls(np.nan_to_num(z_int)), "n/a (<20 km)"), "MK_TAU": np.round(tau, 3), "MK_P": np.round(pv, 4),
                     "TREND": np.where((np.array(pv) < 0.05) & (np.array(tau) > 0), "intensifying", np.where((np.array(pv) < 0.05) & (np.array(tau) < 0), "diminishing", "no trend")),
                     "TOP_NAMES": top.values})
geoms = []
for i in range(nseg):
    a, b = i * 2, min((i + 1) * 2, L); ts = np.r_[a, cl.chainage_km[(cl.chainage_km > a) & (cl.chainage_km < b)].values, b]
    geoms.append(np.c_[np.interp(ts, cl.chainage_km, cl.lon), np.interp(ts, cl.chainage_km, cl.lat)])
shp_write(os.path.join(OUT, "shapefiles", "RTC_segments_2km_hotspots"), geoms, segs, "line")
segs.to_csv(os.path.join(OUT, "RTC_segments_2km_hotspots.csv"), index=False)
shp_write(os.path.join(OUT, "shapefiles", "Expressway_centreline_derived"), [np.c_[cl.lon, cl.lat]], pd.DataFrame({"NAME": ["Lagos-Ibadan Expressway (data-derived)"], "LEN_KM": [round(L, 2)]}), "line")

# ---------------- GeoJSON / KML / Leaflet ----------------
def clean(v): return None if (isinstance(v, float) and np.isnan(v)) else (v.item() if hasattr(v, "item") else v)
gj = {"type": "FeatureCollection", "features": [{"type": "Feature", "geometry": {"type": "Point", "coordinates": [float(r.LON), float(r.LAT)]},
      "properties": {k: clean(r[k]) for k in pt_cols}} for _, r in pts.iterrows()]}
json.dump(gj, open(os.path.join(OUT, "RTC_crash_points_2013_2022.geojson"), "w"))
sj = {"type": "FeatureCollection", "features": [{"type": "Feature", "geometry": {"type": "LineString", "coordinates": g.round(6).tolist()},
      "properties": {k: clean(v) for k, v in segs.iloc[i].items()}} for i, g in enumerate(geoms)]}
json.dump(sj, open(os.path.join(OUT, "RTC_segments_2km_hotspots.geojson"), "w"))
esc = lambda s: str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
col = {"High": "ff2a8a1b", "Medium": "ff00a5eb", "Low": "ff3b3bd0"}
k = ['<?xml version="1.0" encoding="UTF-8"?><kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>Lagos–Ibadan RTC 2013–2022 (geoparsed)</name>']
for c, v in col.items(): k.append(f'<Style id="{c}"><IconStyle><color>{v}</color><scale>0.7</scale><Icon><href>http://maps.google.com/mapfiles/kml/shapes/placemark_circle.png</href></Icon></IconStyle></Style>')
for y in range(2013, 2023):
    k.append(f"<Folder><name>{y}</name>")
    for _, r in pts[pts.YEAR == y].iterrows():
        k.append(f"<Placemark><name>{esc(r.LOCATION)}</name><styleUrl>#{r.CONFIDENCE}</styleUrl><description>{esc(f'{r.DATE} | {r.COMMAND} | killed {r.KILLED}, injured {r.INJURED} | {r.CAUSE} | {r.CONFIDENCE} confidence ({r.MATCH_KEY})')}</description><Point><coordinates>{r.LON},{r.LAT},0</coordinates></Point></Placemark>")
    k.append("</Folder>")
k.append("</Document></kml>"); open(os.path.join(OUT, "RTC_crash_points_2013_2022.kml"), "w").write("".join(k))

S = {"records": int(len(d)), "geoparsed": int(len(pts)), "pct": round(100 * len(pts) / len(d), 1), "confidence": d.CONFIDENCE.replace("", "Unresolved").value_counts().to_dict(),
     "on_expressway": int((pts.ON_EXPWY == "yes").sum()), "segments_hot95": segs.loc[segs.GI_Z >= 1.96, "FROM_KM"].tolist(),
     "segments_hot95_hm": segs.loc[segs.GI_Z_HM >= 1.96, "FROM_KM"].tolist(), "segments_hot95_inter": segs.loc[segs.GI_Z_INTER >= 1.96, "FROM_KM"].tolist(),
     "intensifying": segs.loc[segs.TREND == "intensifying", "FROM_KM"].tolist(), "diminishing": segs.loc[segs.TREND == "diminishing", "FROM_KM"].tolist(),
     "per_year": pts.groupby("YEAR").size().to_dict(), "per_year_total": d.groupby("YEAR").size().to_dict()}
json.dump(S, open(os.path.join(OUT, "summary.json"), "w"), indent=1, default=int); print(json.dumps(S, indent=1, default=int))
print(segs[segs.GI_Z >= 1.96][["FROM_KM", "CRASHES", "KILLED", "GI_Z", "TOP_NAMES"]].to_string())
print(segs[(segs.GI_Z_INTER >= 1.96)][["FROM_KM", "CRASHES", "GI_Z_INTER", "TOP_NAMES"]].to_string())

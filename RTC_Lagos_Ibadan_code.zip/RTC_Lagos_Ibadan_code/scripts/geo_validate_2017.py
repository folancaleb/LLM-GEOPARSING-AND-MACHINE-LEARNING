"""geo_validate_2017.py — Validate the LLM-assisted geoparsing against the geotagged 2017 FRSC return.
The 2017 geoparse was produced with 2017 coordinates withheld (leave-one-year-out gazetteer); records located by the
same-year second pass are reported separately because that pass drew on other 2017 records.
Usage: python3 -I geo_validate_2017.py <raw_2017.csv> <combined_final.csv> <centreline.csv> <all_rows_attributes.csv> <out_dir>"""
import sys, os, re, json, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(__file__))
import style; style.setup()
import basemap_ne
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from scipy import stats
RAW, COMB, CL, ATTR, OUT = sys.argv[1:6]; os.makedirs(OUT, exist_ok=True)
INK2, GRID = "#52514e", "#e4e3df"
TC = {"High": "#1baf7a", "Medium": "#eda100", "Low": "#e34948"}

r = pd.read_csv(RAW, dtype=str); r.columns = [c.strip() for c in r.columns]
g = pd.read_csv(COMB, low_memory=False); g = g[g.file_year == 2017].sort_values("row_order").reset_index(drop=True)
assert len(r) == len(g) and (r.LOCATION.str.strip().values == g.LOCATION.str.strip().values).all()
la = pd.to_numeric(r.LATITUDE.str.strip(), errors="coerce"); lo = pd.to_numeric(r.LONGITUDE.str.strip(), errors="coerce")
sw = (la < 5) & (lo > 5); la, lo = la.where(~sw, lo), lo.where(~sw, la)
d = pd.DataFrame({"row": np.arange(len(r)), "SN": r["S/N"], "command": r.COMMAND.str.strip(), "location": r.LOCATION.str.strip(),
                  "ref_lat": la, "ref_lon": lo, "ref_swapped": sw, "geo_lat": g.geo_lat, "geo_lon": g.geo_lon,
                  "geo_conf": g.geo_confidence, "geo_method": g.geo_method, "geo_key": g.geo_matched_key, "geo_chainage": g.geo_chainage_km})

# centreline chainage for the reference points
KX, KY = 111.32 * np.cos(np.deg2rad(6.9)), 110.57
cl = pd.read_csv(CL); line = np.c_[cl.lon * KX, cl.lat * KY]; seg = np.diff(line, axis=0); cum = cl.chainage_km.values
def chain(lat, lon):
    P = np.c_[np.asarray(lon) * KX, np.asarray(lat) * KY]; A = line[:-1]; L2 = (seg ** 2).sum(1)
    t = np.clip(((P[:, None] - A[None]) * seg[None]).sum(2) / L2, 0, 1)
    D = np.linalg.norm(P[:, None] - (A[None] + t[..., None] * seg[None]), axis=2); k = D.argmin(1)
    return cum[k] + t[np.arange(len(P)), k] * np.linalg.norm(seg, axis=1)[k], D.min(1)
ok = d.ref_lat.notna() & d.ref_lon.notna()
c, dist = chain(d.ref_lat[ok], d.ref_lon[ok]); d.loc[ok, "ref_chainage"] = c; d.loc[ok, "ref_dist_axis_km"] = dist

# reference quality classes
key = d.ref_lat.round(5).astype(str) + "," + d.ref_lon.round(5).astype(str)
names_per = None
d["ref_names_sharing"] = 0
# all-years placeholder test and command-territory test, both built WITHOUT 2017 coordinates for territory
A = pd.read_csv(ATTR, low_memory=False); A = A[A.coord_source.astype(str).str.startswith("recorded") & A.lat.notna()].copy()
_src = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "geo_01_geocode.py")).read(); _lib = {}
exec(compile(_src[:_src.index("# ---------------- 2. GAZETTEER")].replace("CLEAN, CL, TARGET, TY, OUTCSV = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4]), sys.argv[5]", ""), "norm", "exec"), _lib)
A["nm"] = A.LOCATION.map(lambda x: _lib["core"](_lib["norm"](x))); A["ck"] = A.lat.round(4).astype(str) + "," + A.lon.round(4).astype(str)
ph_all = set(A.groupby("ck").nm.nunique().loc[lambda x: x >= 5].index)
d["ref_placeholder_allyears"] = ok & (d.ref_lat.round(4).astype(str) + "," + d.ref_lon.round(4).astype(str)).isin(ph_all)
O = A[(A.file_year != 2017) & ~A.ck.isin(ph_all)].copy(); oc, od = chain(O.lat, O.lon); O["ch"] = oc; O = O[od <= 5]
T = O.groupby("cmd_code").ch.agg(q1=lambda x: x.quantile(.25), q3=lambda x: x.quantile(.75), n="size"); T = T[T.n >= 20]
T["lo"], T["hi"] = T.q1 - 15, T.q3 + 15   # interquartile range of the command's other-year geotags, widened by 15 km
d["cmd_code"] = g.cmd_code.values
d = d.join(T[["lo", "hi"]], on="cmd_code")
d["ref_in_cmd_territory"] = np.where(d.lo.isna() | d.ref_chainage.isna(), np.nan, ((d.ref_chainage >= d.lo) & (d.ref_chainage <= d.hi)).astype(float))
T.round(1).to_csv(os.path.join(OUT, "command_territories_excl2017.csv"))
d["ref_class"] = np.select([~ok, (d.ref_names_sharing >= 5) | d.ref_placeholder_allyears, d.ref_dist_axis_km > 5, d.ref_in_cmd_territory == 0],
                           ["missing", "placeholder coordinate", "off corridor (>5 km)", "outside reporting command's territory"], "usable")
def hav(a1, o1, a2, o2):
    a1, o1, a2, o2 = map(np.deg2rad, (a1, o1, a2, o2))
    return 2 * 6371 * np.arcsin(np.sqrt(np.sin((a2 - a1) / 2) ** 2 + np.cos(a1) * np.cos(a2) * np.sin((o2 - o1) / 2) ** 2))
d["err_km"] = hav(d.ref_lat, d.ref_lon, d.geo_lat, d.geo_lon)
d["err_chain_km"] = d.geo_chainage - d.ref_chainage
d["group"] = np.where(d.geo_method.astype(str).str.startswith("same-year"), "same-year pass (not independent)",
              np.where(d.geo_lat.isna(), "unresolved", "independent (2017 withheld)"))
d.to_csv(os.path.join(OUT, "validation_2017_records.csv"), index=False)

# ---------- summaries
def summ(x):
    e = x.err_km.dropna(); ae = x.err_chain_km.abs().dropna()
    return pd.Series({"n": len(e), "median_km": e.median(), "mean_km": e.mean(), "p90_km": e.quantile(.9),
                      "within_0.5km_%": 100 * (e <= .5).mean(), "within_1km_%": 100 * (e <= 1).mean(), "within_2km_%": 100 * (e <= 2).mean(),
                      "within_5km_%": 100 * (e <= 5).mean(), "median_abs_chainage_err_km": ae.median()})
V = d[(d.ref_class == "usable") & (d.group == "independent (2017 withheld)")]
V2 = d[d.ref_class.isin(["usable", "outside reporting command's territory"]) & (d.group == "independent (2017 withheld)")]
by_all = pd.concat([V2.groupby("geo_conf").apply(summ, include_groups=False).reindex(["High", "Medium", "Low"]), summ(V2).to_frame("All").T])
by_all.round(2).to_csv(os.path.join(OUT, "validation_2017_by_confidence_incl_suspect_refs.csv"))
by = pd.concat([V.groupby("geo_conf").apply(summ, include_groups=False).reindex(["High", "Medium", "Low"]), summ(V).to_frame("All").T])
by.round(2).to_csv(os.path.join(OUT, "validation_2017_by_confidence.csv"))
cls = pd.crosstab(d.ref_class, d.group, margins=True); cls.to_csv(os.path.join(OUT, "validation_2017_reference_classes.csv"))
# by location name (usable, independent)
loc = V.assign(L=V.geo_key.fillna(V.location)).groupby("L").agg(n=("err_km", "size"), median_err_km=("err_km", "median"),
        conf=("geo_conf", lambda s: s.mode().iat[0])).sort_values("n", ascending=False)
loc.round(2).to_csv(os.path.join(OUT, "validation_2017_by_location.csv"))
worst = V.sort_values("err_km", ascending=False).head(15)[["location", "command", "geo_conf", "geo_method", "geo_key", "ref_chainage", "geo_chainage", "err_km"]]
worst.round(2).to_csv(os.path.join(OUT, "validation_2017_largest_errors.csv"), index=False)
# segment-level agreement (5 km), 2017
V5 = V.dropna(subset=["ref_chainage", "geo_chainage"])
bins = np.arange(-10, 140, 5)
hr = np.histogram(V5.ref_chainage, bins)[0]; hg = np.histogram(V5.geo_chainage, bins)[0]
keep = (hr + hg) > 0; rho, prho = stats.spearmanr(hr[keep], hg[keep])
top = lambda h: set(np.argsort(-h)[:5])
bias = V5.err_chain_km
S = {"records": len(d), "reference_classes": d.ref_class.value_counts().to_dict(), "groups": d.group.value_counts().to_dict(),
     "usable_independent_n": len(V), "by_conf_incl_suspect": by_all.round(2).to_dict("index"), "suspect_n": int((V2.ref_class != "usable").sum()), "by_conf": by.round(2).to_dict("index"),
     "segment5_spearman": round(float(rho), 3), "segment5_p": float(prho), "segment5_n": int(keep.sum()),
     "top5_overlap": len(top(hr) & top(hg)), "chain_bias_median_km": round(float(bias.median()), 2),
     "chain_bias_wilcoxon_p": float(stats.wilcoxon(bias[bias != 0]).pvalue) if (bias != 0).sum() > 10 else None,
     "pass2_n": int((d.group == "same-year pass (not independent)").sum()), "swapped_fixed": int(d.ref_swapped.sum()),
     "placeholder_coords": d.loc[d.ref_class.str.startswith("placeholder"), ["ref_lat", "ref_lon"]].round(5).drop_duplicates().values.tolist(),
     "loc_n": len(loc), "loc_within1_share": round(float((loc.median_err_km <= 1).mean() * 100), 1)}
json.dump(S, open(os.path.join(OUT, "validation_2017_summary.json"), "w"), indent=1, default=float)
print(json.dumps({k: v for k, v in S.items() if k != "placeholder_coords"}, indent=1, default=float)); print(by.round(2)); print(cls); print(worst.round(2).to_string())

# ---------- figure
fig = plt.figure(figsize=(14, 10.5)); gs = fig.add_gridspec(2, 2, hspace=0.36, wspace=0.26)
ax = fig.add_subplot(gs[0, 0])
for t in ["High", "Medium", "Low"]:
    e = np.sort(V[V.geo_conf == t].err_km.values); ax.step(e, np.arange(1, len(e) + 1) / len(e) * 100, where="post", color=TC[t], lw=2.4, label=f"{t} (n = {len(e)})")
e = np.sort(V.err_km.values); ax.step(e, np.arange(1, len(e) + 1) / len(e) * 100, where="post", color="#0b0b0b", lw=1.6, ls="--", label=f"All (n = {len(e)})")
for x in (0.5, 1, 2, 5): ax.axvline(x, color=GRID, lw=1, zorder=0)
ax.set_xscale("log"); ax.set_xlim(0.005, 100); ax.text(0.006, 96, "errors < 5 m plotted at the left edge", fontsize=8, color=INK2, va="top"); ax.set_ylim(0, 100); ax.set_xticks([0.01, 0.1, 0.5, 1, 2, 5, 10, 50]); ax.set_xticklabels(["0.01", "0.1", "0.5", "1", "2", "5", "10", "50"])
ax.set_xlabel("Distance between geoparsed and recorded position (km, log scale)"); ax.set_ylabel("Cumulative % of records")
ax.legend(loc="lower right", fontsize=9, frameon=True, facecolor="#fcfcfb", edgecolor=GRID); ax.set_title("(a) Positional error by confidence tier")

ax = fig.add_subplot(gs[0, 1])
for t in ["Low", "Medium", "High"]:
    s = V5[V5.geo_conf == t]; ax.scatter(s.ref_chainage, s.geo_chainage, s=26, color=TC[t], alpha=.7, edgecolor="#fcfcfb", lw=.4, label=t)
ax.plot([-10, 135], [-10, 135], color=INK2, lw=1, ls="--"); ax.fill_between([-10, 135], [-12, 133], [-8, 137], color="#c9c8c1", alpha=.35, lw=0)
ax.set_xlim(-10, 135); ax.set_ylim(-10, 135); ax.set_aspect("equal"); ax.set_xlabel("Recorded position (chainage, km from Ojota)"); ax.set_ylabel("Geoparsed position (chainage, km)")
ax.text(-6, 126, "grey band = ±2 km", fontsize=8.5, color=INK2); ax.legend(loc="lower right", fontsize=9, frameon=True, facecolor="#fcfcfb", edgecolor=GRID)
ax.set_title("(b) Geoparsed vs recorded chainage")

ax = fig.add_subplot(gs[1, 0])
XL, YL = (3.25, 4.02), (6.45, 7.48); basemap_ne.draw(ax, extent=XL + YL)
ax.plot(cl.lon, cl.lat, color="#fcfcfb", lw=6, zorder=1, alpha=.9); ax.plot(cl.lon, cl.lat, color="#8a8983", lw=2.6, zorder=1.1)
for t in ["Low", "Medium", "High"]:
    s = V[V.geo_conf == t]
    for a in s.itertuples(): ax.plot([a.ref_lon, a.geo_lon], [a.ref_lat, a.geo_lat], color=TC[t], lw=.9, alpha=.75, zorder=2)
ax.scatter(V.ref_lon, V.ref_lat, s=16, facecolor="none", edgecolor="#0b0b0b", lw=.7, zorder=3)
ax.scatter(V.geo_lon, V.geo_lat, s=14, c=V.geo_conf.map(TC), edgecolor="#fcfcfb", lw=.4, zorder=4)
ax.set_xlim(*XL); ax.set_ylim(*YL); ax.set_aspect(1 / np.cos(np.deg2rad(6.9))); ax.set_xlabel("Longitude (°E)"); ax.set_ylabel("Latitude (°N)")
ax.legend(handles=[Line2D([], [], marker="o", ls="", markerfacecolor="none", markeredgecolor="#0b0b0b", label="Recorded (2017 geotag)")] +
          [Line2D([], [], marker="o", ls="-", color=TC[t], label=f"Geoparsed, {t}") for t in TC], loc="upper left", fontsize=8.3, frameon=True, facecolor="#fcfcfb", edgecolor=GRID, framealpha=.95)
ax.text(XL[0] + 0.01, YL[0] + 0.01, basemap_ne.CREDIT, fontsize=6.3, color="#3a3936", bbox=dict(boxstyle="round,pad=0.2", fc="#fcfcfb", ec="none", alpha=.85))
ax.set_title("(c) Recorded → geoparsed positions (lines = error)")

ax = fig.add_subplot(gs[1, 1])
mid = bins[:-1] + 2.5
ax.bar(mid - 1.1, hr, width=2.2, color="#52514e", label="Recorded geotags"); ax.bar(mid + 1.1, hg, width=2.2, color="#2a78d6", label="Geoparsed")
ax.set_xlim(-10, 135); ax.set_xlabel("5-km segment (chainage, km from Ojota)"); ax.set_ylabel("2017 crashes")
ax.legend(loc="upper right", fontsize=9, frameon=False); ax.grid(axis="x", visible=False)
ax.text(0.02, 0.95, f"Spearman ρ = {rho:.2f} ({int(keep.sum())} segments)\nTop-5 segments shared: {S['top5_overlap']} of 5", transform=ax.transAxes, va="top", fontsize=9, color=INK2)
ax.set_title("(d) Crashes per 5-km segment, 2017")
fig.suptitle("Validation of LLM-assisted geoparsing against geotagged 2017 FRSC records", x=0.01, ha="left", fontsize=15, weight="bold", y=0.995)
fig.text(0.01, 0.958, f"2017 coordinates were withheld when geoparsing. Evaluated: {len(V)} records with usable reference geotags (missing, placeholder, off-corridor and command-inconsistent geotags excluded).", fontsize=10, color=INK2)
fig.savefig(os.path.join(OUT, "fig_validation_2017.png"), dpi=200, bbox_inches="tight"); plt.close()

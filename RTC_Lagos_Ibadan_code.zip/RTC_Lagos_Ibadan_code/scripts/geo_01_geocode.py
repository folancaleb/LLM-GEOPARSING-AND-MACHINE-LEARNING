"""
geo_01_geocode.py — Geocode FRSC crash records from free-text LOCATION names.

Method (hierarchical, every coordinate traceable to a source record):
  1. Name normalisation (alias table curated by the LLM: misspellings, abbreviations, qualifiers).
  2. Gazetteer = 2013–2022 records with recorded coordinates (target year excluded), weighted so that
     'placeholder' coordinates (one coordinate reused for >=5 different names) are used only as a fallback.
  3. Matching order: exact name + same command  ->  exact name (any command)  ->  landmark sub-token
     ->  fuzzy name (difflib >= 0.86)  ->  'KMnn'-only labels via command-specific KM→chainage calibration.
  4. Each output row carries method, matched key, number of supporting records, spread (km) and a confidence class.

Usage: python3 -I geo_01_geocode.py <clean_all_years.csv> <centreline.csv> <target.csv> <target_year> <out_csv>
"""
import sys, re, difflib, numpy as np, pandas as pd
from scipy import stats

CLEAN, CL, TARGET, TY, OUTCSV = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4]), sys.argv[5]

# ---------------- 1. NORMALISATION (alias table) ----------------
PHRASE = [  # (regex, replacement) applied to upper-cased text, in order
    (r"\bF\s*/\s*S\b", " FILLING STATION "), (r"\bB\s*/\s*S(TOP)?\b", " BUS STOP "), (r"\bB4\b", " BEFORE "),
    (r"\bLAG\s*/\s*IBA?D?(AN)?\b", " "), (r"\bIBD\s*/\s*LAG\b", " "),
    (r"\bBRD\b|\bBRDG\b|\bBRIDGR\b|\bBIDGE\b|\bBRIGDE\b", " BRIDGE "),
    (r"LONG\s*-?\s*BRIDGE|LONGBRIDGE", " LONG BRIDGE "), (r"\bCON\s+OIL\b", " CONOIL "),
    (r"\bIHSARA\b|\bISHARA\b", " ISARA "), (r"\bKWAKY(I)?AMA?\b", " KWAKYAMA "),
    (r"\bSA?NDCRETE?\b|\bSADCRETE\b", " SANDCRETE "), (r"\bQUARY\b", " QUARRY "),
    (r"STRAIGHT\s*GATE", " STRAIGHT GATE "), (r"\bTOLLGATE\b", " TOLL GATE "),
    (r"\b4\s*SQUARE\b|\bFOUR\s*SQUARE\b", " FOURSQUARE "), (r"\bALAPERA\b", " ALAPERE "),
    (r"\bASEESE\b|\bASHESHE\b", " ASESE "), (r"\bRAMONA\b", " ROMONA "), (r"\bSEIKO\b", " SEKO "),
    (r"\bSONYO\b", " SANYO "), (r"GURU\s*-?\s*MARA[JG]I|GURUMARA[JG]I|GURU\s*MAHAJI|GURUMAHAJI", " GURU MARAJI "),
    (r"\bGURU\s+ARA\b", " GURU "), (r"\bQUARRY EXPRESS\b", " EXPRESS QUARRY "), (r"\bWHICHTEC\b|\bWICHTEC\b", " WICHTECH "),
    (r"\bMARKT\b", " MARKET "), (r"\bDEPER\b", " DEEPER "), (r"\bMOTO?R?WAYS?\b", " MOTORWAYS "),
    (r"\bMOBILE?\b", " MOBIL "), (r"\bFUEL STATION\b|\bPETROL STATION\b", " FILLING STATION "),
    (r"\bAGIRAH\b|\bALHAJIRA\b", " ALHAJIRAH "), (r"\bTABIEORA\b", " TABIEORA "), (r"\bOFF\b", " OFFICE "),
    (r"\bNIPOST\s+KARA\b", " KARA "), (r"\bMOGBORO\b", " MAGBORO "), (r"\bRAMODA\b", " ROMONA "), (r"\bTABIEORAR\b", " TABIEORA "), (r"\bJN\b|\bJUNC\b", " JUNCTION "), (r"\bOPP\.", " OPP "),
]
QUAL = r"\b(OPP|OPPOSITE|AFTER|BEFORE|NEAR|CLOSE|BY|AREA|INWARD|OUTWARD|LAGOS|IBADAN|ABOUT|TO|THE|AT)\b"
def norm(s):
    s = " " + str(s).upper() + " "
    for a, b in PHRASE: s = re.sub(a, b, s)
    s = re.sub(r"[^A-Z0-9\.\s,/()]", " ", s)
    return re.sub(r"\s+", " ", s).strip()
def km_value(s):
    m = re.search(r"\bKM\s*\.?\s*(\d{1,3}(?:\.\d+)?)|(\d{1,3}(?:\.\d+)?)\s*KM\b", s)
    return float(m.group(1) or m.group(2)) if m else np.nan
def core(s):
    s = re.sub(r"\bKM\s*\.?\s*\d{1,3}(\.\d+)?\s*-?|\b\d{1,3}(\.\d+)?\s*KM\b", " ", s)
    s = re.sub(r"[()/,\-\.]", " ", s); s = re.sub(QUAL, " ", s)
    s = re.sub(r"\b(BUS STOP|JUNCTION|TURNING)\b", " ", s)
    return re.sub(r"\s+", " ", s).strip()
GENERIC = {"BRIDGE", "FILLING STATION", "FILLING", "STATION", "QUARRY", "MARKET", "CHURCH", "COLLEGE", "PARK", "OFFICE", "HOSPITAL",
           "UNIVERSITY", "BUS STOP", "JUNCTION", "TURNING", "AREA", "GATE", "HOME", "BASE", "CAR PARK", "COMPANY", "OIL", "LIFE"}
def parts(s):
    """Landmark sub-tokens for compound names, e.g. 'AREPO (PUNCH)', 'OPIC/MFM', 'PAKURO B/S OPP DEEPER LIFE',
    'KM115 EXPRESS QUARRY OPP. MOTHERLESS BABY HOME'. Longest n-grams first; generic words never match alone."""
    s2 = re.sub(r"\bKM\s*\.?\s*\d{1,3}(\.\d+)?\s*-?|\b\d{1,3}(\.\d+)?\s*KM\b", " ", s)
    chunks = [core(x) for x in re.split(r"[()/,]| - |\bOPP\b|\bAFTER\b|\bBEFORE\b|\bTO\b|\bNEAR\b", s2)]
    out = []
    for ch in [c for c in chunks if c]:
        w = ch.split()
        for n in range(len(w), 0, -1):
            for i in range(len(w) - n + 1):
                gram = " ".join(w[i:i + n])
                if len(gram) >= 3 and gram not in GENERIC and gram not in out: out.append(gram)
    return out
def family(cmd):
    m = re.search(r"RS\s*(\d+)[\.,](\d+)", str(cmd).upper()); return f"RS{m.group(1)}.{m.group(2)}" if m else ""

# ---------------- 2. GAZETTEER ----------------
cl = pd.read_csv(CL)
KX, KY = 111.32 * np.cos(np.deg2rad(6.9)), 110.57
def km_dist(la1, lo1, la2, lo2): return np.hypot((np.asarray(lo1) - lo2) * KX, (np.asarray(la1) - la2) * KY)
def chain_to_ll(c): return np.interp(c, cl.chainage_km, cl.lat), np.interp(c, cl.chainage_km, cl.lon)

g = pd.read_csv(CLEAN, low_memory=False)
g = g[(g.file_year != TY) & g.coord_source.astype(str).str.startswith("recorded") & g.lat.notna()].copy()
g["n_norm"] = g.location_raw.map(norm); g["k"] = g.n_norm.map(core); g["fam"] = g.command.map(family)
ck = g.lat.round(4).astype(str) + "," + g.lon.round(4).astype(str)
g["placeholder"] = ck.map(g.assign(ck=ck).groupby("ck").k.nunique()) >= 5
g = g[g.k.str.len() >= 3]

def summarise(sub):
    """Dominant spatial cluster (points within 1 km of the densest point); non-placeholder coordinates preferred."""
    good = sub[~sub.placeholder]; use = good if len(good) else sub
    la, lo = use.lat.values, use.lon.values
    D = km_dist(la[:, None], lo[:, None], la[None], lo[None])
    centre = (D <= 1.0).sum(1).argmax(); inc = D[centre] <= 1.0
    cla, clo = np.median(la[inc]), np.median(lo[inc])
    spread = float(np.median(km_dist(la[inc], lo[inc], cla, clo))) if inc.sum() > 1 else np.nan
    return pd.Series({"lat": cla, "lon": clo, "n": int(inc.sum()), "n_total": len(use), "cluster_share": inc.mean(),
                      "n_years": len(set(use.file_year.values[inc].astype(int))),
                      "n_placeholder_only": int(len(good) == 0), "spread_km": spread,
                      "years": ",".join(map(str, sorted(set(use.file_year.values[inc].astype(int)))))})
gz_cmd = g.groupby(["k", "fam"]).apply(summarise, include_groups=False)
gz = g.groupby("k").apply(summarise, include_groups=False)
keys = list(gz.index)

# KM-only calibration per command: chainage ~ KM label using records whose label is a bare 'KMnn'
cl_line = np.c_[cl.lon * KX, cl.lat * KY]; seg = np.diff(cl_line, axis=0); cum = cl.chainage_km.values
def chainage(la, lo):
    P = np.c_[np.asarray(lo) * KX, np.asarray(la) * KY]; A = cl_line[:-1]
    L2 = (seg ** 2).sum(1); t = np.clip(((P[:, None] - A[None]) * seg[None]).sum(2) / L2, 0, 1)
    D = np.linalg.norm(P[:, None] - (A[None] + t[..., None] * seg[None]), axis=2); k = D.argmin(1)
    return cum[k] + t[np.arange(len(P)), k] * np.linalg.norm(seg, axis=1)[k], D.min(1)
# ---- command territories (chainage inter-quartile range ±10 km of each command's own recorded, non-placeholder points)
g["ch"], g["dax"] = chainage(g.lat, g.lon)
terr = g[(~g.placeholder) & (g.dax <= 1.0)].groupby("fam").ch.agg(lambda x: (np.percentile(x, 25), np.percentile(x, 75), len(x)))
def in_territory(fam, ch):
    if fam not in terr.index or terr[fam][2] < 15 or np.isnan(ch): return None
    lo, hi, _ = terr[fam]; return (lo - 10) <= ch <= (hi + 10)
PTS = {k: v for k, v in g.groupby("k")}
def clusters(sub):
    """Greedy 1-km clustering; returns list of dicts sorted by size."""
    good = sub[~sub.placeholder]; use = good if len(good) else sub
    la, lo, yr, fm = use.lat.values, use.lon.values, use.file_year.values.astype(int), use.fam.values
    D = km_dist(la[:, None], lo[:, None], la[None], lo[None]); left = np.ones(len(la), bool); out = []
    while left.any():
        cnt = ((D <= 1.0) & left[None] & left[:, None]).sum(1); cnt[~left] = -1; c = cnt.argmax()
        inc = (D[c] <= 1.0) & left; left &= ~inc
        cla, clo = np.median(la[inc]), np.median(lo[inc])
        out.append(dict(lat=cla, lon=clo, n=int(inc.sum()), n_years=len(set(yr[inc])), share=inc.sum() / len(la),
                        years=",".join(map(str, sorted(set(yr[inc])))), fams=set(fm[inc]), placeholder_only=len(good) == 0,
                        spread=float(np.median(km_dist(la[inc], lo[inc], cla, clo))) if inc.sum() > 1 else np.nan))
    return out
def pick(key, fam):
    """Choose among the spatial clusters for a gazetteer key: size × same-command bonus × territory plausibility."""
    cl_ = clusters(PTS[key]); best, bs = None, -1
    for c in cl_:
        chn, dax = chainage([c["lat"]], [c["lon"]]); dax = float(dax[0]); chn = chn[0] if dax <= 5.0 else np.nan
        terr_ok = in_territory(fam, chn)
        road = 1.0 if dax <= 5.0 else 0.2          # all records are on the Lagos–Ibadan route: far-off sites are implausible
        sc = c["n"] * (2.0 if fam in c["fams"] else 1.0) * (0.25 if terr_ok is False else 1.0) * road * (1 + 0.2 * c["n_years"])
        if sc > bs: best, bs = dict(c, territory_ok=terr_ok, n_clusters=len(cl_), dax=dax), sc
    rivals = [c for c in cl_ if (c["lat"], c["lon"]) != (best["lat"], best["lon"])]
    best["rival_n"] = max([c["n"] for c in rivals], default=0)
    best["rival_site"] = (f"{rivals[0]['lat']:.5f},{rivals[0]['lon']:.5f} (n={rivals[0]['n']})" if rivals and rivals[0]["n"] >= 2 else "")
    return best
g["kmv"] = g.n_norm.map(km_value)
bare = g[g.k.eq("") | g.n_norm.str.fullmatch(r"KM\s*\d{1,3}(\.\d+)?")] if False else g[g.n_norm.str.fullmatch(r"KM\s*\d{1,3}(\.\d+)?") & ~g.placeholder]
CAL = {}
if len(bare):
    ch, dd = chainage(bare.lat, bare.lon); bare = bare.assign(ch=ch, dd=dd)[dd < 1.5]
    for fam, s in bare.groupby("fam"):
        if len(s) >= 8 and s.kmv.nunique() >= 4:
            res = stats.theilslopes(s.ch, s.kmv); rho = stats.spearmanr(s.kmv, s.ch)[0]
            resid = s.ch - (res.intercept + res.slope * s.kmv)
            CAL[fam] = {"slope": res.slope, "intercept": res.intercept, "rho": rho, "mad_km": float(np.median(np.abs(resid))), "n": len(s)}
# also an exact-label lookup for bare KM labels per command
gz_km = bare.groupby(["fam", "kmv"]).apply(summarise, include_groups=False) if len(bare) else pd.DataFrame()

# ---------------- 3. MATCH ----------------
def conf(n, spread, placeholder_only, method, share=1.0, n_years=1):
    """High: same coordinate cluster confirmed in >=3 separate years, >=70% of the name's records agree, not placeholder-only.
    Medium: >=2 years or >=3 records agreeing (>=60%). Low: anything weaker, all fuzzy/landmark single-record matches."""
    fuzzy = method.startswith("fuzzy") or method.startswith("landmark")
    if share >= 0.7 and n_years >= 3 and not placeholder_only and not method.startswith("fuzzy"):
        return "High" if not fuzzy else "Medium"
    if share >= 0.6 and (n_years >= 2 or n >= 3): return "Medium"
    return "Low"

def _unused(): pass
def distinct(x):
    for gw in sorted(GENERIC, key=len, reverse=True): x = re.sub(rf"\b{gw}\b", " ", x)
    return re.sub(r"\s+", " ", x).strip()
def distinct_sim(a, b2):
    da, db = distinct(a), distinct(b2)
    return difflib.SequenceMatcher(None, da, db).ratio() if da and db else 0.0

def conf2(c, method):
    fuzzy = method.startswith("fuzzy") or method.startswith("landmark")
    if c["share"] >= 0.7 and c["n_years"] >= 3 and not c["placeholder_only"] and not method.startswith("fuzzy"): lvl = 1 if fuzzy else 0
    elif c["share"] >= 0.5 and (c["n_years"] >= 2 or c["n"] >= 3): lvl = 1
    else: lvl = 2
    if c["territory_ok"] is False: lvl += 1
    if c.get("rival_n", 0) >= 3: lvl = max(lvl, 1)          # competing site with >=3 records: cap at Medium
    if c.get("dax", 0) > 5.0: lvl = max(lvl, 2)              # > 5 km from the expressway: Low
    return ["High", "Medium", "Low", "Low"][min(lvl, 3)]

def geocode(loc, cmd):
    nm = norm(loc); k = core(nm); fam = family(cmd)
    def out(key, method):
        c = pick(key, fam)
        return dict(lat=c["lat"], lon=c["lon"], method=method, matched_key=key, n_support=c["n"], n_years=c["n_years"],
                    cluster_share=round(c["share"], 2), n_alt_sites=c["n_clusters"] - 1, spread_km=c["spread"], support_years=c["years"],
                    within_command_territory={True: "yes", False: "NO", None: "unknown"}[c["territory_ok"]], competing_site=c["rival_site"], confidence=conf2(c, method))
    if k:
        if k in PTS: return out(k, "exact name")
        for pk in parts(nm):
            if pk in PTS: return out(pk, "landmark token")
        best = [b2 for b2 in difflib.get_close_matches(k, keys, n=3, cutoff=0.86) if distinct_sim(k, b2) >= 0.8][:1]
        if best: return out(best[0], f"fuzzy name (similarity {difflib.SequenceMatcher(None, k, best[0]).ratio():.2f})")
        for pk in parts(nm):
            best = [b2 for b2 in difflib.get_close_matches(pk, keys, n=3, cutoff=0.86) if distinct_sim(pk, b2) >= 0.8][:1]
            if best: return out(best[0], f"fuzzy landmark token (similarity {difflib.SequenceMatcher(None, pk, best[0]).ratio():.2f})")
    kv = km_value(nm)
    base = dict(lat=np.nan, lon=np.nan, n_support=0, n_years=0, cluster_share=np.nan, n_alt_sites=0, spread_km=np.nan,
                support_years="", within_command_territory="unknown", competing_site="", confidence="None")
    if not np.isnan(kv):
        return dict(base, method="unresolved: KM label only (KM-post origin inconsistent in source data)", matched_key=f"KM{kv:g}")
    return dict(base, method="unresolved: name not in gazetteer", matched_key="")

t = pd.read_csv(TARGET, encoding="latin1", dtype=str, low_memory=False)
t.columns = [c.strip() for c in t.columns]
if "LONGITUDE CATEGORY" in t.columns: t = t.rename(columns={"LONGITUDE CATEGORY": "LONGITUDE"})
t = t[t["LOCATION"].notna()].copy()
res = pd.DataFrame([geocode(l, c) for l, c in zip(t["LOCATION"], t["COMMAND"])], index=t.index)
t = pd.concat([t, res.add_prefix("geo_")], axis=1)
t["geo_location_normalised"] = t["LOCATION"].map(lambda s: core(norm(s)))
ch, dd = chainage(t.geo_lat.fillna(0), t.geo_lon.fillna(0))
t["geo_chainage_km"] = np.where(t.geo_lat.notna(), ch, np.nan).round(2)
t["geo_dist_to_expressway_km"] = np.where(t.geo_lat.notna(), dd, np.nan).round(2)
t["geo_on_expressway"] = t.geo_dist_to_expressway_km <= 1.0
t.to_csv(OUTCSV, index=False)
print("calibrations:", {k: {kk: round(vv, 3) for kk, vv in v.items()} for k, v in CAL.items()})
print(t.geo_method.str.split(" \\(").str[0].value_counts().to_string()); print(t.geo_confidence.value_counts().to_string())

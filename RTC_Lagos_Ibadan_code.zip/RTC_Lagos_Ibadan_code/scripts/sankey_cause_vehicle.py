"""sankey_cause_vehicle.py — Three-stage Sankey (alluvial) diagram: probable cause → vehicle type → crash outcome.
Built from the cleaned FRSC records (duplicates removed). Usage: python3 -I sankey_cause_vehicle.py <out_dir>"""
import sys, os, json, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(__file__))
import style; style.setup()
import matplotlib.pyplot as plt
from matplotlib.path import Path
from matplotlib.patches import PathPatch, Rectangle
OUT = sys.argv[1]
d = pd.read_csv(os.path.join(OUT, "rtc_lagos_ibadan_clean_2013_2022.csv"), low_memory=False)

cause_map = {"Speeding": "Speeding", "Other": "Other / unspecified", "Brake failure": "Brake failure", "Tyre burst": "Tyre burst",
             "Mechanical deficiency": "Mechanical deficiency", "Dangerous driving/overtaking": "Dangerous driving / overtaking",
             "Fatigue": "Fatigue, loss of control, DUI", "Loss of control": "Fatigue, loss of control, DUI", "DUI": "Fatigue, loss of control, DUI"}
veh_map = {"Tricycle": "Other / tricycle", "Other/unknown": "Other / tricycle"}
d["C"] = d.cause.map(cause_map).fillna("Other / unspecified")
d["V"] = d.vehicle_type.replace(veh_map).fillna("Other / tricycle")
d["S"] = np.select([d.killed > 0, d.injured > 0], ["Fatal", "Injury (no deaths)"], "No injury")
N = len(d)
C_order = d.C.value_counts().index.tolist()
V_order = d.V.value_counts().index.tolist()
S_order = ["Fatal", "Injury (no deaths)", "No injury"]
CAUSE_COL = dict(zip(C_order, ["#2a78d6", "#a8a79f", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#6250d6"]))
SEV_COL = {"Fatal": "#b3261e", "Injury (no deaths)": "#ec835a", "No injury": "#c9c8c1"}

GAP = 0.012 * N; W = 0.035
def stack(order, counts):
    y, pos = 0.0, {}
    for k in order:
        pos[k] = [y, y + counts[k]]; y += counts[k] + GAP
    return pos, y - GAP
cC, cV, cS = d.C.value_counts(), d.V.value_counts(), d.S.value_counts()
pC, HC = stack(C_order, cC); pV, HV = stack(V_order, cV); pS, HS = stack(S_order, cS)
Hmax = max(HC, HV, HS)
for pos, H in [(pC, HC), (pV, HV), (pS, HS)]:          # centre each column vertically
    off = (Hmax - H) / 2
    for k in pos: pos[k] = [pos[k][0] + off, pos[k][1] + off]
X = {"C": 0.0, "V": 1.0, "S": 2.0}

def band(ax, x0, y0a, y0b, x1, y1a, y1b, col, alpha=.55):
    xm = (x0 + x1) / 2
    verts = [(x0, y0a), (xm, y0a), (xm, y1a), (x1, y1a), (x1, y1b), (xm, y1b), (xm, y0b), (x0, y0b), (x0, y0a)]
    codes = [Path.MOVETO, Path.CURVE4, Path.CURVE4, Path.CURVE4, Path.LINETO, Path.CURVE4, Path.CURVE4, Path.CURVE4, Path.CLOSEPOLY]
    ax.add_patch(PathPatch(Path(verts, codes), fc=col, ec="none", alpha=alpha, zorder=1))

fig, ax = plt.subplots(figsize=(13.5, 9.2))
# flows cause → vehicle (coloured by cause)
f1 = d.groupby(["C", "V"]).size()
outC = {k: pC[k][0] for k in C_order}; inV = {k: pV[k][0] for k in V_order}
for v in V_order:                                      # fill vehicle nodes in cause order for tidy bands
    for c in C_order:
        n = f1.get((c, v), 0)
        if n == 0: continue
        band(ax, X["C"] + W, outC[c], outC[c] + n, X["V"] - W / 2, inV[v], inV[v] + n, CAUSE_COL[c]); outC[c] += n; inV[v] += n
# flows vehicle → outcome (coloured by outcome)
f2 = d.groupby(["V", "S"]).size()
outV = {k: pV[k][0] for k in V_order}; inS = {k: pS[k][0] for k in S_order}
for s in S_order:
    for v in V_order:
        n = f2.get((v, s), 0)
        if n == 0: continue
        band(ax, X["V"] + W / 2, outV[v], outV[v] + n, X["S"] - W, inS[s], inS[s] + n, SEV_COL[s], alpha=.5); outV[v] += n; inS[s] += n
# nodes + labels
def node(x, pos, k, col, side, text):
    y0, y1 = pos[k]; ax.add_patch(Rectangle((x - (W if side == "L" else 0 if side == "R" else W / 2), y0), W, y1 - y0, fc=col, ec="#fcfcfb", lw=.8, zorder=3))
    xt = x - W - 0.015 if side == "L" else (x + W + 0.015 if side == "R" else x + W / 2 + 0.012)
    ax.text(xt, (y0 + y1) / 2, text, ha="right" if side == "L" else "left", va="center", fontsize=9, zorder=4,
            bbox=dict(boxstyle="round,pad=0.15", fc="#fcfcfb", ec="none", alpha=.85) if side == "M" else None)
for c in C_order:
    node(X["C"] + W, pC, c, CAUSE_COL[c], "L", f"{c}  {cC[c]:,} ({100 * cC[c] / N:.1f}%)")
fatal_by_v = d.groupby("V").apply(lambda s: (s.S == "Fatal").mean(), include_groups=False)
for v in V_order:
    node(X["V"], pV, v, "#52514e", "M", f"{v}  {cV[v]:,} · {100 * fatal_by_v[v]:.0f}% fatal")
for s in S_order:
    node(X["S"] - W, pS, s, SEV_COL[s], "R", f"{s}  {cS[s]:,} ({100 * cS[s] / N:.1f}%)")
for x, t in [(X["C"], "Probable cause"), (X["V"], "Vehicle type (first-listed)"), (X["S"], "Crash outcome")]:
    ax.text(x, -0.025 * N, t, ha="center", va="bottom", fontsize=11, weight="bold", color="#0b0b0b")
ax.set_xlim(-0.75, 2.6); ax.set_ylim(Hmax + 0.05 * N, -0.05 * N); ax.axis("off")
ax.set_title(f"Probable cause → vehicle type → outcome, Lagos–Ibadan Expressway crashes 2013–2022 (n = {N:,})", loc="left", fontsize=12.5, weight="bold")
ax.text(-0.75, Hmax + 0.035 * N, "Band width ∝ number of crashes. Left bands coloured by cause; right bands by outcome. Source: FRSC crash returns (duplicates removed).",
        fontsize=8.5, color="#52514e")
fig.tight_layout(); fig.savefig(os.path.join(OUT, "figures", "fig04_sankey_cause_vehicle_outcome.png"), dpi=200); plt.close()

# summary numbers for the text
ct = pd.crosstab(d.C, d.V)
fat_c = d.groupby("C").apply(lambda s: (s.S == "Fatal").mean() * 100, include_groups=False).round(1)
share_bus_speed = 100 * ct.loc["Speeding", "Bus"] / cV["Bus"]
top_pairs = d.groupby(["C", "V"]).size().sort_values(ascending=False).head(6)
mech = d[d.C.isin(["Brake failure", "Tyre burst", "Mechanical deficiency"])].V.value_counts(normalize=True).mul(100).round(1)
S = {"N": N, "cause": cC.to_dict(), "veh": cV.to_dict(), "sev": cS.to_dict(), "fatal_by_cause": fat_c.to_dict(),
     "fatal_by_veh": (fatal_by_v * 100).round(1).to_dict(), "top_pairs": {f"{a} | {b}": int(n) for (a, b), n in top_pairs.items()},
     "speed_share_of_bus": round(share_bus_speed, 1), "mech_vehicle_mix": mech.head(4).to_dict(),
     "speed_share_by_veh": (100 * ct.loc["Speeding"] / cV).round(1).to_dict()}
json.dump(S, open(os.path.join(OUT, "sankey_summary.json"), "w"), indent=1, default=float); print(json.dumps(S, indent=1, default=float))

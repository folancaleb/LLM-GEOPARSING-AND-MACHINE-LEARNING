"""basemap_ne.py — Public-domain Natural Earth basemap (1:10m raster NE1_HR_LC_SR_W + vectors) for matplotlib maps.
Natural Earth data are in the public domain (naturalearthdata.com/about/terms-of-use): no permission or attribution required."""
import json, os, numpy as np
from PIL import Image
from matplotlib.path import Path
from matplotlib.patches import PathPatch
from matplotlib import patheffects as pe
_D = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "basemap")
_V = json.load(open(os.path.join(_D, "ne_vectors_clip.json")))
_R = np.asarray(Image.open(os.path.join(_D, "ne1_crop.png"))).astype(float) / 255
_E = json.load(open(os.path.join(_D, "ne1_crop.json")))["extent"]
_R = _R * 0.78 + 0.22          # lighten so data stay legible

def _polys(geom):
    t, c = geom["type"], geom["coordinates"]
    return [c] if t == "Polygon" else (c if t == "MultiPolygon" else [])
def _lines(geom):
    t, c = geom["type"], geom["coordinates"]
    return [c] if t == "LineString" else (c if t == "MultiLineString" else [])
def _patch(poly, **kw):
    verts, codes = [], []
    for ring in poly:
        ring = np.asarray(ring)[:, :2]
        if len(ring) < 3: continue
        verts += ring.tolist() + [ring[0].tolist()]; codes += [Path.MOVETO] + [Path.LINETO] * (len(ring) - 1) + [Path.CLOSEPOLY]
    return PathPatch(Path(verts, codes), **kw)

def draw(ax, light=False, labels=True, extent=None):
    ax.imshow(_R, extent=_E, origin="upper", interpolation="bicubic", zorder=0)
    for f in _V["urban_areas"]:
        for p in _polys(f["geometry"]): ax.add_patch(_patch(p, fc="#e9d8c4", ec="#d9c2a6", lw=.4, alpha=.75, zorder=0.2))
    for f in _V["ocean"]:
        for p in _polys(f["geometry"]): ax.add_patch(_patch(p, fc="#c7dceb", ec="#9ab8cf", lw=.6, zorder=0.3))
    for f in _V["rivers_lake_centerlines"]:
        for l in _lines(f["geometry"]): l = np.asarray(l); ax.plot(l[:, 0], l[:, 1], color="#7fa8c9", lw=1.0, zorder=0.4)
    for f in _V["admin_1_states_provinces"]:
        for p in _polys(f["geometry"]):
            for ring in p[:1]:
                r = np.asarray(ring); ax.plot(r[:, 0], r[:, 1], color="#9b8fae", lw=1.0, alpha=.9, zorder=0.5)
    if not light:
        for f in _V["railroads"]:
            for l in _lines(f["geometry"]): l = np.asarray(l); ax.plot(l[:, 0], l[:, 1], color="#6b6a64", lw=.8, ls=(0, (1, 1.5)), zorder=0.6)
    for f in _V["roads"]:
        major = f["properties"].get("type") == "Major Highway"
        for l in _lines(f["geometry"]):
            l = np.asarray(l); ax.plot(l[:, 0], l[:, 1], color="#fcfcfb", lw=(2.6 if major else 1.6), zorder=0.65, solid_capstyle="round")
            ax.plot(l[:, 0], l[:, 1], color=("#b9a27e" if major else "#c9c2b4"), lw=(1.4 if major else .8), zorder=0.7, solid_capstyle="round")
    if labels:
        ext = extent or (ax.get_xlim() + ax.get_ylim())
        halo = [pe.withStroke(linewidth=2.5, foreground="#fcfcfb")]
        for f in _V["admin_1_states_provinces"]:
            n = f["properties"]["name"]; pos = {"Lagos": (3.62, 6.52), "Ogun": (3.16, 7.05), "Oyo": (3.60, 7.42)}.get(n)
            if pos and ext[0] < pos[0] < ext[1] and ext[2] < pos[1] < ext[3]:
                ax.text(*pos, f"{n.upper()} STATE", fontsize=7 if light else 8.5, color="#8a8983", style="italic", ha="center", zorder=0.8, path_effects=halo)
        for f in _V["populated_places_simple"]:
            x, y = f["geometry"]["coordinates"][:2]; n = f["properties"]["name"]
            if ext[0] < x < ext[1] and ext[2] < y < ext[3]:
                ax.plot(x, y, "s", ms=4 if light else 5, color="#3a3936", zorder=5)
                ax.text(x + 0.012, y + 0.008, n, fontsize=7.5 if light else 9.5, weight="bold", color="#3a3936", zorder=5, path_effects=halo)
CREDIT = "Basemap: Natural Earth 1:10m (public domain)"

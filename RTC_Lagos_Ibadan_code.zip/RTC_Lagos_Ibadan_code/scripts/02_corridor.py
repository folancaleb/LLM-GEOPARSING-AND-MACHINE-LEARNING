"""
02_corridor.py — Derive a data-driven expressway centreline, compute chainage (km from Lagos end),
flag on-corridor records, and validate chainage against 'KMxx' markers in location names.
Usage: python3 -I 02_corridor.py <out_dir>
"""
import sys, os, re, numpy as np, pandas as pd
OUT = sys.argv[1]
d = pd.read_csv(os.path.join(OUT, "rtc_lagos_ibadan_clean_2013_2022.csv"), parse_dates=["date"])

KX, KY = 111.32 * np.cos(np.deg2rad(6.9)), 110.57          # km per degree (local equirectangular)
def xy(lat, lon): return np.c_[np.asarray(lon) * KX, np.asarray(lat) * KY]

p = d.dropna(subset=["lat"])
# 1) robust centreline: 0.01° latitude bins, median longitude, keep dense bins
# Corridor end points are taken from the data: median coords of records labelled OJOTA (Lagos end, 6.599N)
# and IWO ROAD (Ibadan end, 7.401N).
LAT0, LAT1 = 6.595, 7.405
A0, A1 = xy([6.5994], [3.3783])[0], xy([7.4014], [3.9422])[0]     # Ojota, Iwo Road (data medians)
U = (A1 - A0) / np.linalg.norm(A1 - A0); N = np.array([-U[1], U[0]])
TOT = np.linalg.norm(A1 - A0)
def along(P): return (P - A0) @ U, (P - A0) @ N
P_all = xy(p.lat, p.lon); t_all, o_all = along(P_all)
keep = (t_all >= -1) & (t_all <= TOT + 1)
t_all, o_all = t_all[keep], o_all[keep]
edges = np.arange(0, TOT + 1.0, 1.0)            # 1-km bins along the Ojota→Iwo Road axis
def fit(t, o):
    idx = np.digitize(t, edges)
    g = pd.DataFrame({"i": idx, "t": t, "o": o}).groupby("i").agg(t=("t", "median"), o=("o", "median"), n=("o", "size"))
    g = g[g.n >= 2].sort_values("t").reset_index(drop=True)
    rm = g.o.rolling(5, center=True, min_periods=1).median()
    g = g[(g.o - rm).abs() <= 1.2].reset_index(drop=True)            # kink removal (km)
    g["o"] = g.o.rolling(3, center=True, min_periods=1).mean()
    return g
g = fit(t_all, o_all)
for _ in range(3):
    ref = np.interp(t_all, g.t, g.o)
    m = np.abs(o_all - ref) <= 1.0
    g = fit(t_all[m], o_all[m])
g = pd.concat([pd.DataFrame({"t": [0.0], "o": [0.0]}), g[["t", "o"]], pd.DataFrame({"t": [TOT], "o": [0.0]})]).sort_values("t").drop_duplicates("t").reset_index(drop=True)
line = A0 + np.outer(g.t, U) + np.outer(g.o, N)
g["lon"], g["b"] = line[:, 0] / KX, line[:, 1] / KY
seg_len = np.linalg.norm(np.diff(line, axis=0), axis=1)
cum = np.r_[0, np.cumsum(seg_len)]

def project(P):
    A, B = line[:-1], line[1:]
    AB = B - A; L2 = (AB ** 2).sum(1)
    t = np.clip(((P[:, None, :] - A[None]) * AB[None]).sum(2) / L2[None], 0, 1)
    proj = A[None] + t[..., None] * AB[None]
    dist = np.linalg.norm(P[:, None, :] - proj, axis=2)
    k = dist.argmin(1)
    return dist[np.arange(len(P)), k], cum[k] + t[np.arange(len(P)), k] * seg_len[k]

has = d.lat.notna()
dist, ch = project(xy(d.loc[has, "lat"], d.loc[has, "lon"]))
d.loc[has, "dist_to_axis_km"] = dist
d.loc[has, "chainage_km"] = ch
d["on_corridor"] = (d.dist_to_axis_km <= 1.0) & (d.chainage_km > 0.05) & (d.chainage_km < cum[-1] - 0.05) | ((d.dist_to_axis_km <= 1.0) & d.lat.between(LAT0, LAT1))

# 2) validation against KM markers in location text (e.g., 'KM19-RCC QUARRY AREA', 'KM47')
km = d.location_raw.astype(str).str.upper().str.extract(r"\bKM\s*(\d{1,3})")[0].astype(float)
v = d.assign(km=km).dropna(subset=["km", "chainage_km"])
v = v[v.on_corridor & (v.coord_source.str.startswith("recorded"))]
r_all = v[["km", "chainage_km"]].corr(method="spearman").iloc[0, 1]
by_cmd = v.groupby("cmd_code").apply(lambda s: pd.Series({"n": len(s), "spearman": s[["km", "chainage_km"]].corr(method="spearman").iloc[0, 1]}), include_groups=False)

pd.DataFrame({"lat": g.b, "lon": g.lon, "chainage_km": cum}).to_csv(os.path.join(OUT, "centreline_derived.csv"), index=False)
d.to_csv(os.path.join(OUT, "rtc_lagos_ibadan_clean_2013_2022.csv"), index=False)
msg = [f"Centreline length (data-derived): {cum[-1]:.1f} km from lat {g.b.min():.3f} to {g.b.max():.3f}",
       f"Records with coords: {has.sum()}; on corridor (<=1.0 km from axis): {int(d.on_corridor.sum())}",
       f"KM-marker validation: n={len(v)}, Spearman(KM label, chainage) overall={r_all:.2f}",
       by_cmd[by_cmd.n >= 5].round(2).to_string()]
open(os.path.join(OUT, "corridor_log.txt"), "w").write("\n".join(msg)); print("\n".join(msg))

"""fig01_annual_panel.py — Redesigned Figure 1: annual crashes, casualties and severity, 2013–2022 (4 panels).
Usage: python3 -I fig01_annual_panel.py <out_dir>"""
import sys, os, json, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(__file__))
import style; style.setup()
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.lines import Line2D
OUT = sys.argv[1]
d = pd.read_csv(os.path.join(OUT, "rtc_lagos_ibadan_clean_2013_2022.csv"), low_memory=False)
INK, INK2, GRID = "#0b0b0b", "#52514e", "#e4e3df"
FAT, INJ, NON = "#b3261e", "#ec835a", "#c9c8c1"
BLUE, RED = "#2a78d6", "#c0392b"
ct = pd.crosstab(d.year, d.severity).reindex(columns=["Fatal", "Serious/Minor injury", "No injury"])
yr = ct.index.values; n = ct.sum(1).values
g = d.groupby("year").agg(killed=("killed", "sum"), injured=("injured", "sum"))
dp100 = 100 * g.killed.values / n; fpct = 100 * ct["Fatal"].values / n; npct = 100 * ct["No injury"].values / n

fig = plt.figure(figsize=(14, 9.4))
gs = fig.add_gridspec(2, 2, hspace=0.42, wspace=0.22)

# (a) stacked crashes by outcome
ax = fig.add_subplot(gs[0, 0]); bot = np.zeros(len(yr))
for col, c, lab in [("Fatal", FAT, "Fatal"), ("Serious/Minor injury", INJ, "Injury only"), ("No injury", NON, "No injury")]:
    ax.bar(yr, ct[col].values, bottom=bot, color=c, width=.72, edgecolor="#fcfcfb", lw=.8, label=lab); bot += ct[col].values
for x, t in zip(yr, n): ax.text(x, t + 12, f"{t:,}", ha="center", va="bottom", fontsize=8.5, color=INK, weight="bold" if x in (2013, 2021, 2022) else "normal")
ax.set_ylim(0, n.max() * 1.15); ax.set_xticks(yr); ax.set_xticklabels([f"'{str(v)[2:]}" for v in yr]); ax.set_ylabel("Recorded crashes")
ax.legend(loc="upper left", fontsize=8.5, frameon=False); ax.grid(axis="x", visible=False)
ax.set_title("(a) Recorded crashes tripled to a 2021 peak")

# (b) persons killed and injured (two series, one axis)
ax = fig.add_subplot(gs[0, 1])
ax.fill_between(yr, g.injured.values, color=INJ, alpha=.18, lw=0); ax.plot(yr, g.injured.values, color=INJ, lw=2.4, marker="o", ms=6, label="Injured")
ax.fill_between(yr, g.killed.values, color=FAT, alpha=.25, lw=0); ax.plot(yr, g.killed.values, color=FAT, lw=2.4, marker="o", ms=6, label="Killed")
for s, c in [(g.injured, INJ), (g.killed, FAT)]:
    for x in (2013, 2021, 2022): ax.annotate(f"{int(s[x]):,}", (x, s[x]), xytext=(0, 8), textcoords="offset points", ha="center", fontsize=8.5, color=c, weight="bold")
ax.set_xticks(yr); ax.set_xticklabels([f"'{str(v)[2:]}" for v in yr]); ax.set_ylim(0, g.injured.max() * 1.15); ax.set_ylabel("Persons")
ax.legend(loc="upper left", fontsize=8.5, frameon=False); ax.set_title("(b) Casualties rose far more slowly than crashes")

# (c) index 2013 = 100
ax = fig.add_subplot(gs[1, 0])
ic, ik = 100 * n / n[0], 100 * g.killed.values / g.killed.values[0]
ax.fill_between(yr, ik, ic, where=ic >= ik, color=BLUE, alpha=.10, lw=0, interpolate=True)
ax.plot(yr, ic, color=BLUE, lw=2.6, marker="o", ms=6); ax.plot(yr, ik, color=FAT, lw=2.6, marker="o", ms=6)
ax.axhline(100, color=INK2, lw=.8, ls="--")
ax.text(2022.15, ic[-1], f"Crashes\n{ic[-1]:.0f}", color=BLUE, va="center", fontsize=9, weight="bold")
ax.text(2022.15, ik[-1], f"Deaths\n{ik[-1]:.0f}", color=FAT, va="center", fontsize=9, weight="bold")
ax.text(2020.35, (ic[7] + ik[7]) / 2 - 12, "gap = crashes\nwithout deaths", ha="center", fontsize=8.5, color=BLUE, style="italic")
ax.set_xlim(2012.6, 2023.3); ax.set_xticks(yr); ax.set_xticklabels([f"'{str(v)[2:]}" for v in yr]); ax.set_ylim(0, ic.max() * 1.12)
ax.set_ylabel("Index (2013 = 100)"); ax.set_title("(c) Crashes and deaths diverge after 2017")

# (d) severity ratios
ax = fig.add_subplot(gs[1, 1])
ax.plot(yr, dp100, color=FAT, lw=2.6, marker="o", ms=6); ax.plot(yr, fpct, color=INJ, lw=2.6, marker="s", ms=6); ax.plot(yr, npct, color="#8a8983", lw=2.2, marker="^", ms=6, ls="--")
for arr, c, dy in [(dp100, FAT, 0), (fpct, INJ, -7), (npct, "#6b6a66", 7)]:
    ax.annotate(f"{arr[0]:.1f}", (yr[0], arr[0]), xytext=(-6, 0), textcoords="offset points", ha="right", va="center", fontsize=8.5, color=c, weight="bold")
    ax.annotate(f"{arr[-1]:.1f}", (yr[-1], arr[-1]), xytext=(6, dy), textcoords="offset points", ha="left", va="center", fontsize=8.5, color=c, weight="bold")
ax.set_xlim(2012.2, 2022.9); ax.set_xticks(yr); ax.set_xticklabels([f"'{str(v)[2:]}" for v in yr]); ax.set_ylim(0, 85)
ax.legend(handles=[Line2D([], [], color=FAT, marker="o", lw=2.4, label="Deaths per 100 crashes"), Line2D([], [], color=INJ, marker="s", lw=2.4, label="% of crashes that were fatal"),
                   Line2D([], [], color="#8a8983", marker="^", lw=2.2, ls="--", label="% of crashes with no injury")], loc="upper right", fontsize=8.5, frameon=True, facecolor="#fcfcfb", edgecolor=GRID)
ax.set_ylabel("Rate"); ax.set_title("(d) Each crash became less deadly")

fig.suptitle("Annual crash trends, Lagos–Ibadan Expressway, 2013–2022", x=0.01, ha="left", fontsize=15, weight="bold", y=0.995)
fig.text(0.01, 0.955, f"{n.sum():,} recorded crashes (duplicates removed), {int(g.killed.sum()):,} persons killed, {int(g.injured.sum()):,} injured. Source: FRSC crash returns.", fontsize=10, color=INK2)
fig.savefig(os.path.join(OUT, "figures", "fig01_annual_panel.png"), dpi=200, bbox_inches="tight"); plt.close()
S = {"n": n.tolist(), "killed": g.killed.astype(int).tolist(), "injured": g.injured.astype(int).tolist(), "dp100": np.round(dp100, 1).tolist(), "fatal_pct": np.round(fpct, 1).tolist(),
     "noinj_pct": np.round(npct, 1).tolist(), "idx_crash_2022": round(ic[-1]), "idx_killed_2022": round(ik[-1]), "idx_crash_2021": round(ic[-2]), "idx_killed_2021": round(ik[-2])}
print(json.dumps(S))

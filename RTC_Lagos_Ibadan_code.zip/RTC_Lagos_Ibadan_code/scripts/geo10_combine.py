"""geo10_combine.py — Stack the per-year geoparser outputs and attach the cleaned crash attributes.
Usage: python3 -I geo10_combine.py <geo_out_dir> <rtc_all_rows_with_attributes.csv> <combined_raw.csv>"""
import sys, glob, os, pandas as pd
GO, ATTR, OUTF = sys.argv[1:4]
g = pd.concat([pd.read_csv(f, low_memory=False) for f in sorted(glob.glob(os.path.join(GO, "geo_*.csv")))], ignore_index=True)
a = pd.read_csv(ATTR, low_memory=False)
m = g.merge(a, on=["file_year", "row_order"], how="left", suffixes=("", "_attr"))
m.to_csv(OUTF, index=False); print(m.shape)

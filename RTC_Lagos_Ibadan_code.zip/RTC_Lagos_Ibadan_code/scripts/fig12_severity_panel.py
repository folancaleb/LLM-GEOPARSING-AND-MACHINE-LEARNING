"""fig12_severity_panel.py — Redesigned 'What makes a crash fatal?' figure (4 panels).
Usage: python3 -I fig12_severity_panel.py <out_dir>"""
import sys, os, json, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(__file__))
import style; style.setup()
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
OUT = sys.argv[1]
d = pd.read_csv(os.path.join(OUT, "rtc_lagos_ibadan_clean_2013_2022.csv"), low_memory=False)
imp = pd.read_csv(os.path.join(OUT, "ml_severity_importance.csv"))
base = d.fatal.mean() * 100
INK2, GRID = "#52514e", "#e4e3df"
RED, BLUE, GREY = "#c0392b", "#2a78d6", "#a8a79f"

def wilson(k, n, z=1.96):
    p = k / n; den = 1 + z ** 2 / n; c = (p + z ** 2 / (2 * n)) / den; h = z * np.sqrt(p * (1 - p) / n + z ** 2 / (4 * n ** 2)) / den
    return 100 * p, 100 * (c - h), 100 * (c + h)

fig = plt.figure(figsize=(14, 10.2))
gs = fig.add_gridspec(2, 2, hspace=0.40, wspace=0.42)

# (a) importance lollipop, coloured by feature group
ax = fig.add_subplot(gs[0, 0])
nice = {"involved": "Persons involved", "chainage_km": "Location along corridor", "year": "Year", "hour": "Hour of day", "month": "Month",
        "dow": "Day of week", "vehicle_type": "Vehicle type", "cause": "Probable cause", "ownership": "Ownership", "multi_vehicle": "Multi-vehicle"}
grp = {"chainage_km": ("Where", "#1baf7a"), "year": ("When", BLUE), "hour": ("When", BLUE), "month": ("When", BLUE), "dow": ("When", BLUE),
       "cause": ("Why", "#eb6834"), "involved": ("Crash", "#6250d6"), "multi_vehicle": ("Crash", "#6250d6"),
       "vehicle_type": ("Vehicle", "#e87ba4"), "ownership": ("Vehicle", "#e87ba4")}
imp = imp.sort_values("importance")
y = np.arange(len(imp))
for i, r in enumerate(imp.itertuples()):
    col = grp[r.feature][1]
    ax.plot([0, r.importance], [i, i], color=col, lw=2.2, alpha=.85)
    ax.errorbar(r.importance, i, xerr=r.sd, fmt="o", color=col, ms=8, ecolor=GREY, elinewidth=1, capsize=0, markeredgecolor="#fcfcfb")
ax.axvline(0, color=INK2, lw=.8)
ax.set_yticks(y); ax.set_yticklabels([nice[f] for f in imp.feature]); ax.set_xlabel("Drop in ROC-AUC when the feature is shuffled")
ax.set_title("(a) Which factors carry predictive signal?")
ax.legend(handles=[Line2D([], [], marker="o", ls="-", color=c, label=g) for g, c in [("Where", "#1baf7a"), ("When", BLUE), ("Why (cause)", "#eb6834"), ("Crash", "#6250d6"), ("Vehicle", "#e87ba4")]],
          loc="lower right", fontsize=8.5, frameon=True, facecolor="#fcfcfb", edgecolor=GRID)

# (b) fatality rate by hour of day
ax = fig.add_subplot(gs[0, 1])
h = d.dropna(subset=["hour"]).groupby("hour").fatal.agg(["sum", "count"])
W = np.array([wilson(k, n) for k, n in zip(h["sum"], h["count"])])
hrs = h.index.values.astype(int)
ax.axvspan(-0.5, 5.5, color="#0d366b", alpha=.07, lw=0); ax.axvspan(18.5, 23.5, color="#0d366b", alpha=.07, lw=0)
ax.fill_between(hrs, W[:, 1], W[:, 2], color=RED, alpha=.15, lw=0)
ax.plot(hrs, W[:, 0], color=RED, lw=2.2, marker="o", ms=5)
ax.axhline(base, color=INK2, ls="--", lw=1); ax.text(23.4, base + 1, f"overall {base:.1f}%", ha="right", fontsize=8.5, color=INK2)
ax.text(2.5, ax.get_ylim()[1] * 0.97 if ax.get_ylim()[1] > 0 else 50, "night", ha="center", va="top", fontsize=9, color="#0d366b", style="italic")
ax.set_xlim(-0.5, 23.5); ax.set_xticks(range(0, 24, 3)); ax.set_xlabel("Hour of day"); ax.set_ylabel("% of crashes that were fatal")
ax.set_title("(b) Night-time crashes are more often fatal"); ax.set_ylim(0, None)
ax.text(21, ax.get_ylim()[1] * 0.97, "night", ha="center", va="top", fontsize=9, color="#0d366b", style="italic")

# (c) fatality rate along the corridor (5-km bins)
ax = fig.add_subplot(gs[1, 0])
p = d[d.on_corridor == True].copy(); p["b"] = (p.chainage_km // 5 * 5).astype(int)
g = p.groupby("b").fatal.agg(["sum", "count"]); g = g[g["count"] >= 25]
W = np.array([wilson(k, n) for k, n in zip(g["sum"], g["count"])])
x = g.index.values + 2.5
cols = [RED if lo > base else (BLUE if hi < base else GREY) for _, lo, hi in W]
ax.vlines(x, W[:, 1], W[:, 2], color=cols, lw=2, alpha=.6)
ax.scatter(x, W[:, 0], s=np.clip(g["count"].values / 4, 15, 160), c=cols, edgecolor="#fcfcfb", zorder=3)
ax.axhline(base, color=INK2, ls="--", lw=1)
for xi, (r, lo, hi), n in zip(x, W, g["count"].values):
    pass
LAB = {42.5: ("Danco filling stn", -9), 87.5: ("Dominion Univ.", -9), 92.5: ("", 0), 102.5: ("", 0)}
for xi, (r, lo, hi) in zip(x, W):
    if lo > base:
        t, dx = LAB.get(xi, ("", 0))
        ax.annotate(f"{r:.0f}%" + (f"\n{t}" if t else ""), (xi, r), xytext=(dx if t else 14, 0), textcoords="offset points", ha="right" if t else "left",
                    va="center", ma="right" if t else "left", fontsize=8, color=RED, weight="bold", bbox=dict(boxstyle="round,pad=0.12", fc="#fcfcfb", ec="none", alpha=.85))
ax.set_xlim(0, 120); ax.set_ylim(0, 66); ax.set_xlabel("Chainage (km from Ojota, Lagos → Ibadan; 5-km bins, n ≥ 25)"); ax.set_ylabel("% of crashes that were fatal")
ax.set_title("(c) Severity varies along the corridor")
ax.legend(handles=[Line2D([], [], marker="o", ls="", color=RED, label="Significantly above average"), Line2D([], [], marker="o", ls="", color=BLUE, label="Significantly below average"),
                   Line2D([], [], marker="o", ls="", color=GREY, label="Not different (95% CI)")], loc="upper left", fontsize=8, frameon=True, facecolor="#fcfcfb", edgecolor=GRID)

# (d) fatality rate by cause and by year (two dot strips)
ax = fig.add_subplot(gs[1, 1])
cm = {"Speeding": "Speeding", "Other": "Other / unspecified", "Brake failure": "Brake failure", "Tyre burst": "Tyre burst", "Mechanical deficiency": "Mechanical deficiency",
      "Dangerous driving/overtaking": "Dangerous driving", "Fatigue": "Fatigue / LOC / DUI", "Loss of control": "Fatigue / LOC / DUI", "DUI": "Fatigue / LOC / DUI"}
c = d.assign(C=d.cause.map(cm).fillna("Other / unspecified")).groupby("C").fatal.agg(["sum", "count"])
W = pd.DataFrame([wilson(k, n) for k, n in zip(c["sum"], c["count"])], index=c.index, columns=["r", "lo", "hi"]).join(c["count"]).sort_values("r")
yy = np.arange(len(W))
cols = [RED if lo > base else (BLUE if hi < base else GREY) for lo, hi in zip(W.lo, W.hi)]
ax.hlines(yy, W.lo, W.hi, color=cols, lw=2.2, alpha=.7); ax.scatter(W.r, yy, s=70, c=cols, edgecolor="#fcfcfb", zorder=3)
for yi, r in zip(yy, W.itertuples()): ax.text(r.hi + 1, yi, f"{r.r:.1f}%  (n = {r.count:,})", va="center", fontsize=8.5, color=INK2)
ax.axvline(base, color=INK2, ls="--", lw=1)
ax.set_yticks(yy); ax.set_yticklabels(W.index); ax.set_xlim(0, max(W.hi) + 18); ax.set_xlabel("% of crashes that were fatal (95% CI)")
ax.set_title("(d) Fatality rate by probable cause")

fig.suptitle("What makes a crash fatal? Lagos–Ibadan Expressway, 2013–2022", x=0.01, ha="left", fontsize=15, weight="bold", y=0.995)
fig.text(0.01, 0.955, f"Overall {base:.1f}% of {len(d):,} crashes were fatal (dashed lines). Intervals are 95% Wilson confidence intervals. Classifier ROC-AUC = 0.60, i.e. recorded attributes give only weak predictive signal.", fontsize=10, color=INK2)
fig.savefig(os.path.join(OUT, "figures", "fig12_what_makes_fatal_panel.png"), dpi=200, bbox_inches="tight"); plt.close()

# numbers for text
night = d[(d.hour >= 19) | (d.hour <= 5)].fatal.mean() * 100; day = d[d.hour.between(6, 18)].fatal.mean() * 100
peak = h.assign(r=h["sum"] / h["count"] * 100)["r"]
hi_bins = [(int(b), round(r, 1), int(n)) for b, (r, lo, hi_), n in zip(g.index, np.array([wilson(k, n) for k, n in zip(g["sum"], g["count"])]), g["count"]) if lo > base]
lo_bins = [(int(b), round(r, 1), int(n)) for b, (r, lo, hi_), n in zip(g.index, np.array([wilson(k, n) for k, n in zip(g["sum"], g["count"])]), g["count"]) if hi_ < base]
S = {"base": round(base, 1), "night": round(night, 1), "day": round(day, 1), "peak_hour": int(peak.idxmax()), "peak_rate": round(peak.max(), 1),
     "min_hour": int(peak.idxmin()), "min_rate": round(peak.min(), 1), "hi_bins": hi_bins, "lo_bins": lo_bins,
     "cause": W[["r", "lo", "hi", "count"]].round(1).to_dict("index")}
json.dump(S, open(os.path.join(OUT, "fig12_panel_summary.json"), "w"), indent=1, default=float); print(json.dumps(S, indent=1, default=float))

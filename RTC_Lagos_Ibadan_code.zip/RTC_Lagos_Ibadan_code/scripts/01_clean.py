"""
01_clean.py — Harmonise FRSC road traffic crash (RTC) records, Lagos–Ibadan Expressway, 2013–2022.
Usage: python3 -I 01_clean.py <raw_dir> <out_dir>
"""
import sys, re, glob, os
import numpy as np, pandas as pd

RAW, OUT = sys.argv[1], sys.argv[2]
os.makedirs(OUT, exist_ok=True)

FILES = {2013: "2013 MERGED ROUTES.csv", 2014: "2014 MERGED ROUTES.csv", 2015: "2015 MERGED ROUTES.csv",
         2016: "2016 MERGED ROUTES.csv", 2017: "2017 MERGED ROUTES CSV.csv", 2018: "2018 MERGED ROUTES CSV.csv",
         2019: "2019 MERGED ROUTES.csv", 2020: "2020 MERGED ROUTES CSV.csv", 2021: "2021 MERGED ROUTES CSV.csv",
         2022: "2022 MERGED ROUTES CSV.csv"}

log = []
frames = []
for yr, fn in FILES.items():
    d = pd.read_csv(os.path.join(RAW, fn), encoding="latin1", dtype=str, low_memory=False)
    d.columns = [c.strip() for c in d.columns]
    d = d[d["DATE"].notna() & (d["DATE"].str.strip() != "")].copy()
    if yr == 2019:
        # header shift in 2019: extra 'UNKNOWN' column after LOCATION pushes later fields one column right
        d["LOCATION"] = d["UNKNOWN"].where(d["UNKNOWN"].notna(), d["LOCATION"])
        d["LONGITUDE"] = d["LONGITUDE CATEGORY"]
        d["VEHICLE CATEGORY"] = d["VEHICLE"]
        d["VEHICLE"] = d["NAME OF DRIVER"]
    if yr == 2017:
        alt = pd.read_csv(os.path.join(RAW, "2017_RTC.csv"), encoding="latin1", dtype=str)
        alt.columns = [c.strip() for c in alt.columns]
        d = d.reset_index(drop=True)
        assert (d["LOCATION"].str.strip().values == alt["LOCATION"].str.strip().values).all()
        d["DATE"] = alt["DATE"].values  # Excel serial dates (unambiguous)
    d["file_year"] = yr
    d["row_order"] = np.arange(len(d))
    frames.append(d)
    log.append(f"{yr}: {len(d)} dated records from '{fn}'")

df = pd.concat(frames, ignore_index=True)
df["COMMAND"] = df["COMMAND"].fillna("").str.strip().str.upper()
df["cmd_code"] = df["COMMAND"].str.extract(r"(RS\s*\d+\.\d+)")[0].str.replace(" ", "")

# ---------------- DATE PARSING ----------------
def parse_parts(s, fy=None):
    s = re.sub(r"^[^\d]+|[^\d]+$", "", str(s).strip())
    if re.fullmatch(r"\d{5}(\.0+)?", s):
        return ("serial", pd.Timestamp("1899-12-30") + pd.Timedelta(days=int(float(s))))
    m = re.fullmatch(r"(\d{1,2})[/\-\.](\d{1,2})[/\-\.](\d{2,4})", s)
    if not m:
        return ("bad", None)
    a, b, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
    if y < 100: y += 2000
    if fy is not None and y != fy and y % 100 == fy % 100:  # typo years e.g. 1920/3019/2922
        y = fy
    return ("dm", (a, b, y))

def mk(y, mth, day):
    try: return pd.Timestamp(year=y, month=mth, day=day)
    except Exception: return None

dates, dflag = [], []
parsed = [parse_parts(s, fy) for s, fy in zip(df["DATE"], df["file_year"])]
# first pass: unambiguous
cand = []
for (kind, v), fy in zip(parsed, df["file_year"]):
    if kind == "serial":
        cand.append(("ok", v, "serial"))
    elif kind == "bad":
        cand.append(("bad", None, "unparseable"))
    else:
        a, b, y = v
        dm, md = mk(y, b, a), mk(y, a, b)   # dd/mm vs mm/dd
        if dm is not None and md is not None and a != b:
            cand.append(("amb", (dm, md), "ambiguous"))
        else:
            r = dm or md
            cand.append(("ok", r, "dd/mm" if dm is not None else "mm/dd") if r is not None else ("bad", None, "invalid"))
df["_kind"] = [c[0] for c in cand]
# second pass: resolve ambiguous using nearest unambiguous neighbours (same file & command, file order)
res = [c[1] if c[0] == "ok" else None for c in cand]
method = [c[2] for c in cand]
for (fy, cmd), g in df.groupby(["file_year", "cmd_code"], dropna=False):
    idx = g.index.tolist()
    for k, i in enumerate(idx):
        if cand[i][0] != "amb": continue
        neigh = []
        for j in idx[max(0, k-6):k] + idx[k+1:k+7]:
            if cand[j][0] == "ok" and res[j] is not None: neigh.append(res[j])
        dm, md = cand[i][1]
        if neigh:
            ref = pd.Series(neigh).median()
            pick = dm if abs((dm - ref).days) <= abs((md - ref).days) else md
            method[i] = "ambiguous→neighbour"
        else:
            pick = dm; method[i] = "ambiguous→dd/mm default"
        res[i] = pick
df["date"] = pd.to_datetime(pd.Series(res, index=df.index))
df["date_method"] = method
bad_year = df["date"].notna() & (df["date"].dt.year != df["file_year"])
log.append(f"Date parse: {df['date'].notna().sum()} parsed; methods: {pd.Series(method).value_counts().to_dict()}")
log.append(f"Records whose parsed year != file year (set to NaT): {int(bad_year.sum())}")
df.loc[bad_year, "date"] = pd.NaT

# ---------------- CRASH TIME ----------------
def parse_time(s):
    s = str(s).upper().replace("HRS", "").replace("HR", "").replace(":", "").replace(".", "").strip()
    if not re.fullmatch(r"\d{3,4}", s): return np.nan
    s = s.zfill(4); h, m = int(s[:2]), int(s[2:])
    return h + m/60 if h < 24 and m < 60 else np.nan
df["crash_hour_dec"] = df["CRASH TIME"].map(parse_time)
df["hour"] = np.floor(df["crash_hour_dec"])

# ---------------- COORDINATES ----------------
def num(col):
    return pd.to_numeric(df[col].astype(str).str.replace(r"[^\d\.\-]", "", regex=True), errors="coerce") if col in df else np.nan
lat, lon = num("LATITUDE"), num("LONGITUDE")
# Swap where clearly transposed (Nigeria SW: lat ~6.4–7.6, lon ~2.9–4.0)
sw = (lat.between(2.5, 4.5)) & (lon.between(6.0, 8.0))
lat2, lon2 = lat.where(~sw, lon), lon.where(~sw, lat)
inbox = lat2.between(6.40, 7.60) & lon2.between(2.90, 4.10)
df["lat"], df["lon"] = lat2.where(inbox), lon2.where(inbox)
df["coord_source"] = np.where(inbox, np.where(sw, "recorded (lat/lon swapped, corrected)", "recorded"), "missing/invalid")
log.append(f"Coordinates: swapped-corrected {int((sw & inbox).sum())}; valid {int(inbox.sum())}; missing/invalid {int((~inbox).sum())}")

# Impute missing coords from a gazetteer built from the data itself (median coord of same location name)
def norm_loc(s):
    s = str(s).upper()
    s = re.sub(r"[^A-Z0-9 ]", " ", s); s = re.sub(r"\b(AREA|BUS STOP|B/S|OPP|BY|AFTER|BEFORE|NEAR|INWARD|OUTWARD|LAGOS|IBADAN|LAG|IBD)\b", " ", s)
    return re.sub(r"\s+", " ", s).strip()
df["loc_norm"] = df["LOCATION"].map(norm_loc)
gaz = df[df["lat"].notna()].groupby("loc_norm").agg(glat=("lat", "median"), glon=("lon", "median"), gn=("lat", "size"))
gaz = gaz[(gaz.gn >= 2) & (gaz.index.str.len() >= 4)]
m = df["lat"].isna() & df["loc_norm"].isin(gaz.index)
df.loc[m, "lat"] = df.loc[m, "loc_norm"].map(gaz.glat); df.loc[m, "lon"] = df.loc[m, "loc_norm"].map(gaz.glon)
df.loc[m, "coord_source"] = "imputed from same-location records"
log.append(f"Coordinates imputed from in-data gazetteer: {int(m.sum())}; still missing: {int(df['lat'].isna().sum())}")

# ---------------- CASUALTIES ----------------
def tot(prefix, total_col):
    comps = [f"{prefix}/A/M", f"{prefix}/A/F", f"{prefix}/C/M", f"{prefix}/C/F"]
    c = df[comps].apply(lambda s: pd.to_numeric(s, errors="coerce")).fillna(0).sum(axis=1)
    t = pd.to_numeric(df[total_col], errors="coerce")
    return c, t
ni_c, ni_t = tot("NI", "TOTAL"); nk_c, nk_t = tot("NK", "TOTAL.1"); pi_c, pi_t = tot("PI", "TOTAL.2")
inv = pi_t.where(pi_t.notna() & (pi_t >= pi_c), pi_c)          # persons involved: larger of the two (comps often incomplete)
def reconcile(c, t, cap):
    # Prefer reported TOTAL when it is plausible (<= persons involved); else component sum if plausible; else the smaller
    t_ok = t.notna() & (t <= cap); c_ok = c <= cap
    return np.where(t_ok, t, np.where(c_ok, c, np.fmin(c, t.fillna(c))))
df["involved"] = inv
df["injured"] = reconcile(ni_c, ni_t, inv); df["killed"] = reconcile(nk_c, nk_t, inv)
for n, c, t in [("injured", ni_c, ni_t), ("killed", nk_c, nk_t), ("involved", pi_c, pi_t)]:
    log.append(f"{n}: component-sum vs reported TOTAL disagree in {int(((c - t.fillna(0)).abs() > 0.01).sum())} rows (reconciled against persons involved)")
df.loc[df["involved"] > 150, "involved"] = np.nan
df["fatal"] = (df["killed"] > 0).astype(int)
df["severity"] = np.select([df["killed"] > 0, df["injured"] > 0], ["Fatal", "Serious/Minor injury"], "No injury")

# ---------------- CAUSE ----------------
CODE = {"SPEED": "Speeding", "SPV": "Speeding", "SLV": "Speeding", "SOV": "Speeding", "LSV": "Speeding",
        "MECH DEFICIENT": "Mechanical deficiency", "BRAKE FAILURE": "Brake failure", "BREAK FAILURE": "Brake failure", "BFL": "Brake failure",
        "TYRE BURST": "Tyre burst", "TIRE BURST": "Tyre burst", "TBT": "Tyre burst",
        "LOSS OF CONTROL": "Loss of control", "LOC": "Loss of control",
        "WOV": "Dangerous driving/overtaking", "WOT": "Dangerous driving/overtaking", "DGD": "Dangerous driving/overtaking",
        "DAD": "Dangerous driving/overtaking", "DANGEROUS DRIV": "Dangerous driving/overtaking", "RTV": "Dangerous driving/overtaking",
        "ROUTE VIOLATION": "Dangerous driving/overtaking",
        "FATIQUE": "Fatigue", "FATIGUE": "Fatigue", "DUI": "DUI",
        "ROB": "Other", "ROBBERY": "Other", "HIT AND RUN": "Other", "OTHERS": "Other", "OTHES": "Other", "POOR WEATHER": "Other", "DOT": "Other"}
def cause(row):
    for col in ["PROBABLE CAUSE(S) OF RTC", "Unnamed: 16"]:
        v = row.get(col)
        if isinstance(v, str) and v.strip():
            first = re.split(r"[,/]", v.upper())[0].strip().strip(".")
            c = CODE.get(first, "Other")
            if c != "Other" or col == "Unnamed: 16":
                return c
    return "Other"
df["cause"] = df.apply(cause, axis=1)

# ---------------- VEHICLE ----------------
OWN = {"COMMERCIAL", "PRIVATE", "GOVERNMENT", "COMMECIAL", "COMMERCILA", "COMMERCILAL", "C0MMERCIAL", "PRIVATEV"}
def vehicle(row):
    a = str(row.get("VEHICLE CATEGORY", "")).upper().strip(" .")
    b = str(row.get("VEHICLE", "")).upper().strip(" .")
    own_src = a if any(o in a for o in OWN) else (b if any(o in b for o in OWN) else "")
    typ = b if own_src == a else a
    own = "Commercial" if "COMM" in own_src or "C0MM" in own_src else ("Private" if "PRIV" in own_src else ("Government" if "GOV" in own_src else "Unknown"))
    multi = int(bool(re.search(r"[/&]|AND", typ)))
    t0 = re.split(r"[/&,]", typ)[0].strip()
    T = "Other/unknown"
    for k, v in [("MOTORCYCLE", "Motorcycle"), ("TRICYCLE", "Tricycle"), ("TANKER", "Tanker"), ("TRAILER", "Trailer"),
                 ("TRUCK", "Truck"), ("BUS", "Bus"), ("SIENNA", "Bus"), ("JEEP", "Jeep/SUV"), ("PICK", "Pick-up"), ("P/UP", "Pick-up"), ("CAR", "Car")]:
        if k in t0: T = v; break
    return pd.Series({"ownership": own, "vehicle_type": T, "multi_vehicle": multi})
df = pd.concat([df, df.apply(vehicle, axis=1)], axis=1)
df["direction"] = np.where(df["ROUTES"].fillna("").str.upper().str.replace(" ", "").str.startswith("IBADAN"), "Ibadan→Lagos", "Lagos→Ibadan")

# ---------------- DE-DUPLICATION ----------------
key = ["date", "CRASH TIME", "loc_norm", "killed", "injured", "involved"]
dup = df.duplicated(subset=key, keep="first") & df["date"].notna()
log.append(f"Exact duplicates removed (same date, time, location, casualties): {int(dup.sum())}")
df.assign(is_duplicate=dup)[["file_year", "row_order", "COMMAND", "cmd_code", "DATE", "date", "date_method", "CRASH TIME", "hour", "ROUTES", "LOCATION",
    "lat", "lon", "coord_source", "ownership", "vehicle_type", "multi_vehicle", "cause", "injured", "killed", "involved", "fatal", "severity",
    "is_duplicate"]].rename(columns={"COMMAND": "command"}).to_csv(os.path.join(OUT, "rtc_all_rows_with_attributes.csv"), index=False)
df = df[~dup].copy()

keep = ["file_year", "COMMAND", "cmd_code", "DATE", "date", "date_method", "CRASH TIME", "crash_hour_dec", "hour",
        "ROUTES", "direction", "LOCATION", "loc_norm", "lat", "lon", "coord_source", "ownership", "vehicle_type",
        "multi_vehicle", "cause", "injured", "killed", "involved", "fatal", "severity"]
out = df[keep].rename(columns={"DATE": "date_raw", "CRASH TIME": "time_raw", "ROUTES": "route_raw", "LOCATION": "location_raw", "COMMAND": "command"})
out["year"] = out["date"].dt.year.fillna(out["file_year"]).astype(int)
out.to_csv(os.path.join(OUT, "rtc_lagos_ibadan_clean_2013_2022.csv"), index=False)
log.append(f"FINAL: {len(out)} records; with date {out['date'].notna().sum()}; with coords {out['lat'].notna().sum()}; with hour {out['hour'].notna().sum()}")
open(os.path.join(OUT, "cleaning_log.txt"), "w").write("\n".join(log))
print("\n".join(log))

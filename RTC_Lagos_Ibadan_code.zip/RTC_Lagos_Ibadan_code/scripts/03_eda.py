"""03_eda.py — Seaborn exploratory spatiotemporal figures. Usage: python3 -I 03_eda.py <out_dir>"""
import sys, os, json, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(__file__))
import style; style.setup()
import matplotlib.pyplot as plt, seaborn as sns
from style import CAT, SEQ, INK2

OUT = sys.argv[1]; FIG = os.path.join(OUT, "figures"); os.makedirs(FIG, exist_ok=True)
d = pd.read_csv(os.path.join(OUT, "rtc_lagos_ibadan_clean_2013_2022.csv"), parse_dates=["date"])
c = pd.read_csv(os.path.join(OUT, "centreline_derived.csv"))
S = {}

# ---- Fig 1: annual small multiples (one axis each, no dual axes)
y = d.groupby("year").agg(crashes=("year", "size"), killed=("killed", "sum"), injured=("injured", "sum"), fatal=("fatal", "sum")).reset_index()
y["deaths_per_100"] = 100 * y.killed / y.crashes
S["annual"] = y.round(2).to_dict("records")
fig, axs = plt.subplots(1, 3, figsize=(13, 3.6))
for ax, col, t, colr in zip(axs, ["crashes", "killed", "deaths_per_100"], ["Recorded crashes", "Persons killed", "Deaths per 100 crashes"], [CAT[0], CAT[7], CAT[1]]):
    sns.lineplot(data=y, x="year", y=col, ax=ax, color=colr, marker="o", markersize=7)
    ax.set_title(t); ax.set_xlabel(""); ax.set_ylabel(""); ax.set_xticks(y.year[::3]); ax.set_ylim(0, None)
    for _, r in y.iloc[[0, -1]].iterrows(): ax.annotate(f"{r[col]:.0f}", (r.year, r[col]), textcoords="offset points", xytext=(0, 8), ha="center", fontsize=9, color=INK2)
fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig01_annual_trends.png")); plt.close()

# ---- Fig 2: year × month heatmap
dd = d.dropna(subset=["date"]).copy(); dd["month"] = dd.date.dt.month
ym = dd.pivot_table(index="year", columns="month", values="fatal", aggfunc="size", fill_value=0)
ym.columns = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
fig, ax = plt.subplots(figsize=(10, 4.6))
sns.heatmap(ym, cmap=SEQ, annot=True, fmt="d", linewidths=1.5, linecolor="#fcfcfb", cbar_kws={"label": "Crashes"}, ax=ax, annot_kws={"size": 8})
ax.set_title("Monthly crash counts by year"); ax.set_xlabel(""); ax.set_ylabel("")
fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig02_year_month_heatmap.png")); plt.close()
mon = dd.groupby("month").size(); S["month_share"] = (mon / mon.sum() * 100).round(1).to_dict()
S["peak_months"] = mon.sort_values(ascending=False).head(3).index.tolist()

# ---- Fig 3: hour × weekday heatmap
dd["dow"] = dd.date.dt.day_name().str[:3]
order = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
hw = dd.dropna(subset=["hour"]).pivot_table(index="dow", columns="hour", values="fatal", aggfunc="size", fill_value=0).reindex(order)
fig, ax = plt.subplots(figsize=(12, 3.8))
sns.heatmap(hw, cmap=SEQ, linewidths=1, linecolor="#fcfcfb", cbar_kws={"label": "Crashes"}, ax=ax)
ax.set_title("When crashes happen: hour of day × day of week (2013–2022)"); ax.set_xlabel("Hour of day"); ax.set_ylabel("")
ax.set_xticklabels([int(float(t.get_text())) for t in ax.get_xticklabels()], rotation=0)
fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig03_hour_weekday_heatmap.png")); plt.close()
hr = dd.dropna(subset=["hour"]).groupby("hour").size()
S["hour_peak"] = int(hr.idxmax()); S["share_06_20"] = round(float(hr.loc[6:19].sum() / hr.sum() * 100), 1)
S["dow_counts"] = dd.groupby("dow").size().reindex(order).to_dict()
# night vs day fatality
dd["period"] = np.where(dd.hour.between(6, 18), "Day (06–18h)", "Night (19–05h)")
S["fatal_rate_by_period"] = (dd.dropna(subset=["hour"]).groupby("period").fatal.mean() * 100).round(1).to_dict()

# ---- Fig 4: causes & vehicle (counts + fatal share)
fig, axs = plt.subplots(1, 2, figsize=(13, 4.4))
for ax, col, t in [(axs[0], "cause", "Probable cause"), (axs[1], "vehicle_type", "Vehicle type (first-listed)")]:
    t2 = d.groupby(col).agg(n=("fatal", "size"), fatal_pct=("fatal", "mean")).sort_values("n", ascending=False)
    t2 = t2[t2.n >= 10]; t2["fatal_pct"] *= 100
    sns.barplot(x=t2.n, y=t2.index, ax=ax, color=CAT[0], width=0.6)
    for i, (n, fp) in enumerate(zip(t2.n, t2.fatal_pct)):
        ax.text(n + t2.n.max() * 0.01, i, f"{n:,}  ·  {fp:.0f}% fatal", va="center", fontsize=8.5, color=INK2)
    ax.set_title(t); ax.set_xlabel("Crashes"); ax.set_ylabel(""); ax.set_xlim(0, t2.n.max() * 1.35)
    S[f"{col}_table"] = t2.round(1).reset_index().to_dict("records")
fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig04_cause_vehicle.png")); plt.close()

# ---- Fig 5: KDE hotspot map (corridor records)
p = d[d.on_corridor]
fig, axs = plt.subplots(1, 2, figsize=(11, 8), sharey=True)
for ax, (lab, sub) in zip(axs, [("2013–2017", p[p.year <= 2017]), ("2018–2022", p[p.year >= 2018])]):
    ax.plot(c.lon, c.lat, color="#c3c2b7", lw=3, zorder=1)
    sns.kdeplot(x=sub.lon, y=sub.lat, fill=True, cmap=SEQ, levels=12, thresh=0.04, bw_adjust=0.35, ax=ax, zorder=2, alpha=.9)
    ax.scatter(sub.lon, sub.lat, s=4, color="#0b0b0b", alpha=.25, zorder=3, linewidths=0)
    ax.set_aspect("equal"); ax.set_title(f"Crash density (KDE), {lab}  (n={len(sub):,})"); ax.set_xlabel("Longitude"); ax.set_ylabel("Latitude")
    for nm, la, lo in [("Ojota (Lagos)", 6.5994, 3.3783), ("Iwo Road (Ibadan)", 7.4014, 3.9422)]:
        ax.annotate(nm, (lo, la), xytext=(8, 0), textcoords="offset points", fontsize=8.5, color=INK2, va="center")
fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig05_kde_hotspot_map.png")); plt.close()

# ---- Fig 6: chainage × year space–time heatmap (2-km)
p = p.assign(seg=(p.chainage_km // 2 * 2).astype(int))
st = p.pivot_table(index="seg", columns="year", values="fatal", aggfunc="size", fill_value=0)
st = st.reindex(range(0, int(p.chainage_km.max()) + 2, 2), fill_value=0)
fig, ax = plt.subplots(figsize=(8, 11))
sns.heatmap(st, cmap=SEQ, linewidths=.4, linecolor="#fcfcfb", cbar_kws={"label": "Crashes per 2-km segment"}, ax=ax)
ax.set_title("Space–time crash matrix (km from Ojota, Lagos)"); ax.set_ylabel("Chainage (km), Lagos → Ibadan"); ax.set_xlabel("")
ax.set_yticks(np.arange(0, len(st), 5) + .5); ax.set_yticklabels(st.index[::5])
fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig06_space_time_matrix.png")); plt.close()

# ---- Fig 7: direction & ownership by year (small)
S["direction"] = d.direction.value_counts().to_dict(); S["ownership"] = d.ownership.value_counts().to_dict()
S["totals"] = {"records": int(len(d)), "killed": float(d.killed.sum()), "injured": float(d.injured.sum()),
               "fatal_crashes": int(d.fatal.sum()), "on_corridor": int(d.on_corridor.sum()),
               "with_date": int(d.date.notna().sum()), "with_hour": int(d.hour.notna().sum())}
json.dump(S, open(os.path.join(OUT, "eda_summary.json"), "w"), indent=1, default=str)
print(json.dumps(S, indent=1, default=str)[:3500])

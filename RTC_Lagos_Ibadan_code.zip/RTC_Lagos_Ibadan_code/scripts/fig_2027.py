"""fig_2027.py — Visualise the 2027 crash forecast (corridor total) from the ml_2027.py run.
Usage: python3 -I fig_2027.py <out_dir>"""
import sys, os, json, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(__file__))
import style; style.setup()
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
OUT = sys.argv[1]
INK, INK2, GRID = "#0b0b0b", "#52514e", "#e4e3df"
ENS, GLM, RF, GBM, NAIVE, OBS = "#eb6834", "#c0392b", "#1baf7a", "#6250d6", "#8a8983", "#2a78d6"
A = pd.read_csv(os.path.join(OUT, "forecast_annual_2023_2027.csv"))
M = pd.read_csv(os.path.join(OUT, "forecast_monthly_2023_2027.csv"))
S = json.load(open(os.path.join(OUT, "forecast_2027_summary.json"))); obs = pd.Series({int(k): v for k, v in S["obs"].items()}).sort_index()
d = pd.read_csv(os.path.join(OUT, "rtc_lagos_ibadan_clean_2013_2022.csv"), parse_dates=["date"], low_memory=False)
o22 = d[d.date.dt.year == 2022].groupby(d.date.dt.month).size().reindex(range(1, 13), fill_value=0)
m27 = M[M.month.str.startswith("2027")].reset_index(drop=True); mo = np.arange(1, 13)
r27 = A[A.year == 2027].iloc[0]
cols = {"glm": "Poisson GLM (trend + month)", "rf": "Random Forest (lags)", "gbm": "Gradient Boosting (Poisson, lags)", "naive": "Seasonal naïve"}

fig = plt.figure(figsize=(14, 10.4)); gs = fig.add_gridspec(2, 2, height_ratios=[1, 1.05], hspace=0.55, wspace=0.45)

# (a) 2027 month by month
ax = fig.add_subplot(gs[0, 0])
ax.bar(mo, o22.values, color="#c9c8c1", width=.62, label="Observed 2022 (for reference)", zorder=1)
ax.fill_between(mo, m27.pi90_low, m27.pi90_high, color=ENS, alpha=.16, lw=0, label="90% prediction band", zorder=2)
ax.plot(mo, m27.fc_poisson_glm, color=GLM, lw=1.4, ls="--", zorder=3, label="Poisson GLM (trend)")
ax.plot(mo, m27.fc_random_forest, color=RF, lw=1.4, ls="--", zorder=3, label="Random forest (lags)")
ax.plot(mo, m27.fc_gradient_boosting, color=GBM, lw=1.4, ls=":", zorder=3, label="Gradient boosting (lags)")
ax.plot(mo, m27.forecast_ensemble, color=ENS, lw=2.8, marker="o", ms=5, zorder=4, label="Ensemble (selected model)")
ax.set_xticks(mo); ax.set_xticklabels(["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"]); ax.set_xlim(.4, 12.6)
ax.set_ylim(0, max(m27.pi90_high.max(), m27.fc_poisson_glm.max()) * 1.08); ax.set_ylabel("Recorded crashes per month"); ax.grid(axis="x", visible=False)
pk = m27.forecast_ensemble.idxmax()
ax.annotate(f"Peak: {['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][pk]} ≈ {m27.forecast_ensemble[pk]:.0f}", (pk + 1, m27.forecast_ensemble[pk]),
            xytext=(-60, 28), textcoords="offset points", fontsize=8.5, color=ENS, weight="bold", arrowprops=dict(arrowstyle="-", color=ENS, lw=.8))
ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.1), fontsize=7.8, ncol=3, frameon=False)
ax.set_title("(a) 2027 forecast, month by month")

# (b) 2027 total by model, against recent observations
ax = fig.add_subplot(gs[0, 1])
items = [("Observed 2021 (peak)", obs[2021], OBS, None), ("Observed 2022", obs[2022], OBS, None),
         ("Seasonal naïve", r27[cols["naive"]], NAIVE, None), ("Random forest (plateau)", r27[cols["rf"]], RF, None),
         ("Gradient boosting", r27[cols["gbm"]], GBM, None), ("Ensemble (selected)", r27.ensemble, ENS, (r27.pi90_low, r27.pi90_high)),
         ("Poisson GLM (trend)", r27[cols["glm"]], GLM, None)]
y = np.arange(len(items))[::-1]
ax.axvline(obs[2022], color=OBS, lw=1, ls=":", zorder=0)
for yi, (lab, v, c, ci) in zip(y, items):
    if ci: ax.hlines(yi, ci[0], ci[1], color=c, lw=7, alpha=.25, zorder=1)
    ax.hlines(yi, 0, v, color=c, lw=1.2, alpha=.35, zorder=1)
    ax.scatter(v, yi, s=110 if ci else 70, color=c, edgecolor="#fcfcfb", zorder=3, marker="s" if lab.startswith("Observed") else "o")
    ch = "" if lab.startswith("Observed") else f"  ({100 * (v / obs[2022] - 1):+.0f}% vs 2022)"
    ax.text(v + 30, yi, f"{v:,.0f}{ch}", va="center", fontsize=8.8, color=c if not lab.startswith("Observed") else INK2, weight="bold" if ci else "normal")
ax.text(r27.pi90_low, y[5] - .42, f"90% interval {r27.pi90_low:,.0f}–{r27.pi90_high:,.0f}", fontsize=8, color=ENS, va="top")
ax.set_yticks(y); ax.set_yticklabels([i[0] for i in items]); ax.set_xlim(0, max(r27[cols["glm"]], r27.pi90_high) * 1.33); ax.set_xlabel("Recorded crashes in the year")
ax.grid(axis="y", visible=False); ax.set_title("(b) 2027 total: how the models compare")

# (c) path from observed to 2027
ax = fig.add_subplot(gs[1, :])
ax.bar(obs.index, obs.values, color=OBS, width=.62, label="Observed (dated records)", zorder=2)
for x, v in obs.items():
    if x in (2013, 2021, 2022): ax.text(x - (0.18 if x == 2022 else 0), v + 25, f"{v:,}", ha="center", fontsize=8.5, color=INK2)
fy = A.year.values
ax.fill_between(fy, A.pi90_low, A.pi90_high, color=ENS, alpha=.14, lw=0, label="Ensemble 90% interval")
ax.plot(np.r_[2022, fy], np.r_[obs[2022], A[cols["glm"]]], color=GLM, lw=1.8, ls="--", marker="o", ms=4, label="Scenario: trend continues (Poisson GLM)")
ax.plot(np.r_[2022, fy], np.r_[obs[2022], A[cols["rf"]]], color=RF, lw=1.8, ls="--", marker="o", ms=4, label="Scenario: plateau (random forest)")
ax.plot(np.r_[2022, fy], np.r_[obs[2022], A.ensemble], color=ENS, lw=2.8, marker="o", ms=7, label="Ensemble forecast (selected)", zorder=4)
for x, v in zip(fy, A.ensemble): ax.text(x, v + 70, f"{v:,}", ha="center", fontsize=9, color=ENS, weight="bold")
ax.axvspan(2026.5, 2027.5, color=ENS, alpha=.06, lw=0, zorder=0)
ax.text(2027, ax.get_ylim()[1] if False else A[cols["glm"]].max() * 1.07, "2027", ha="center", fontsize=11, weight="bold", color=ENS)
ax.text(2027.42, A[cols["glm"]].iloc[-1], f"{A[cols['glm']].iloc[-1]:,}", va="center", fontsize=8.5, color=GLM)
ax.text(2027.42, A[cols["rf"]].iloc[-1], f"{A[cols['rf']].iloc[-1]:,}", va="center", fontsize=8.5, color=RF)
ax.axvline(2022.5, color="#a8a79f", lw=1, ls="--"); ax.text(2022.58, A[cols["glm"]].max() * 1.07, "forecast →", fontsize=9, color=INK2, va="center")
ax.set_xticks(range(2013, 2028)); ax.set_xlim(2012.4, 2027.9); ax.set_ylim(0, A[cols["glm"]].max() * 1.13)
ax.set_ylabel("Recorded crashes per year"); ax.grid(axis="x", visible=False)
ax.legend(loc="upper left", fontsize=8.5, frameon=True, facecolor="#fcfcfb", edgecolor=GRID)
ax.set_title("(c) From the 2013–2022 record to 2027: forecast and scenarios")

fig.suptitle("Predicted road traffic crashes on the Lagos–Ibadan Expressway in 2027", x=0.01, ha="left", fontsize=15, weight="bold", y=0.997)
fig.text(0.01, 0.962, f"Ensemble forecast for 2027: {r27.ensemble:,.0f} recorded crashes (90% interval {r27.pi90_low:,.0f}–{r27.pi90_high:,.0f}), {100 * (r27.ensemble / obs[2022] - 1):+.0f}% on 2022. "
         f"The models diverge after 2024, so 2027 is best read as a range between a plateau (~{r27[cols['rf']]:,.0f}) and a continued trend (~{r27[cols['glm']]:,.0f}).", fontsize=9.6, color=INK2)
fig.savefig(os.path.join(OUT, "figures", "fig_forecast_2027.png"), dpi=200, bbox_inches="tight"); plt.close()
print(json.dumps({"ens": int(r27.ensemble), "lo": int(r27.pi90_low), "hi": int(r27.pi90_high), "glm": int(r27[cols["glm"]]), "rf": int(r27[cols["rf"]]), "gbm": int(r27[cols["gbm"]]),
                  "obs22": int(obs[2022]), "peak_month": int(pk + 1), "peak": float(m27.forecast_ensemble[pk])}))

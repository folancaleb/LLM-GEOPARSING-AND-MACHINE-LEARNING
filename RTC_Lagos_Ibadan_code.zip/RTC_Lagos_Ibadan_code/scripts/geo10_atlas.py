"""geo10_atlas.py — Print-ready web atlas (Leaflet + OpenStreetMap basemap) of the geoparsed crash data.
Usage: python3 -I geo10_atlas.py <deliver_dir> <atlas_dir> <out_html>"""
import sys, os, json, base64, numpy as np, pandas as pd
DL, AT, OUT = sys.argv[1:4]
d = pd.read_csv(os.path.join(DL, "RTC_Lagos_Ibadan_2013_2022_geoparsed.csv"), low_memory=False)
p = d[d.LAT.notna() & (d.DUPLICATE != "yes")].copy()
segs = json.load(open(os.path.join(DL, "RTC_segments_2km_hotspots.geojson")))
for f in segs["features"]:
    f["geometry"]["coordinates"] = [[round(x, 5), round(y, 5)] for x, y in f["geometry"]["coordinates"]]
    f["properties"] = {k: f["properties"][k] for k in ["FROM_KM", "TO_KM", "CRASHES", "KILLED", "GI_Z", "GI_CLASS", "GI_CLS_INT", "TREND", "TOP_NAMES"]}
meta = json.load(open(os.path.join(AT, "kde_meta.json")))
img = {k: "data:image/png;base64," + base64.b64encode(open(os.path.join(AT, f"kde_{k}.png"), "rb").read()).decode() for k in ["2013_2017", "2018_2022"]}

def sites(df):
    g = df.groupby(["LAT", "LON"]).agg(n=("YEAR", "size"), k=("KILLED", "sum"), inj=("INJURED", "sum"),
                                      key=("MATCH_KEY", lambda s: s.value_counts().index[0]),
                                      conf=("CONFIDENCE", lambda s: s.value_counts().index[0])).reset_index()
    return [[round(r.LAT, 5), round(r.LON, 5), int(r.n), int(r.k), int(r.inj), str(r.key).title(), r.conf] for r in g.itertuples()]
S_all = sites(p)
S_year = {int(y): sites(p[p.YEAR == y]) for y in sorted(p.YEAR.unique())}
tot_year = {int(y): int((d.YEAR == y).sum()) for y in sorted(d.YEAR.unique())}
conf_n = p.CONFIDENCE.value_counts().to_dict()
data = {"all": S_all, "year": S_year, "tot": tot_year, "segs": segs, "kde": img, "kdeB": meta["bounds"], "kdeN": meta["n"],
        "conf": conf_n, "n": int(len(p)), "killed": int(p.KILLED.sum())}

HTML = r"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Lagos–Ibadan Crash Atlas</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js"></script>
<style>
:root{--bg:#f9f9f7;--card:#fcfcfb;--ink:#0b0b0b;--ink2:#52514e;--line:#e4e3df;--acc:#1f4e79}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){--bg:#0d0d0d;--card:#1a1a19;--ink:#f0efec;--ink2:#c3c2b7;--line:#383835;--acc:#86b6ef}}
:root[data-theme="dark"]{--bg:#0d0d0d;--card:#1a1a19;--ink:#f0efec;--ink2:#c3c2b7;--line:#383835;--acc:#86b6ef}
*{box-sizing:border-box}html,body{margin:0;background:var(--bg);color:var(--ink);font:14px/1.45 system-ui,-apple-system,"Segoe UI",sans-serif}
header{padding:18px 16px 6px;max-width:1180px;margin:auto}header h1{margin:0;font-size:22px;color:var(--acc)}header p{margin:6px 0;color:var(--ink2)}
nav{position:sticky;top:0;z-index:2000;background:var(--bg);border-bottom:1px solid var(--line)}
nav .in{max-width:1180px;margin:auto;padding:8px 16px;display:flex;gap:6px;flex-wrap:wrap}
nav button{font:inherit;border:1px solid var(--line);background:var(--card);color:var(--ink);padding:6px 11px;border-radius:999px;cursor:pointer}
nav button.on{background:var(--acc);color:var(--card);border-color:var(--acc)}
.sheet{max-width:1180px;margin:14px auto 28px;padding:0 16px}
.sheet h2{font-size:17px;margin:0 0 4px}.sheet .sub{color:var(--ink2);margin:0 0 8px;font-size:13px}
.map{height:78vh;min-height:520px;border:1px solid var(--line);border-radius:8px;background:#e9e8e3}
.legend{background:#fff;color:#0b0b0b;padding:8px 10px;border-radius:6px;box-shadow:0 1px 4px rgba(0,0,0,.25);font-size:12px;line-height:1.5;max-width:230px}
.legend b{display:block;margin-bottom:3px}.sw{display:inline-block;width:11px;height:11px;border-radius:50%;margin-right:6px;vertical-align:-1px;border:1px solid #fff}
.ln{display:inline-block;width:22px;height:6px;margin-right:6px;vertical-align:2px}
.north{background:#fff;color:#0b0b0b;border-radius:6px;box-shadow:0 1px 4px rgba(0,0,0,.25);padding:4px 8px;text-align:center;font:700 13px system-ui;line-height:1}
.north svg{display:block;margin:0 auto 1px}
.lbl{background:rgba(255,255,255,.88);border:0;box-shadow:none;color:#0b0b0b;font:600 11px system-ui;padding:1px 4px}
.lbl:before{display:none}
.yrs{display:flex;gap:5px;flex-wrap:wrap;margin:0 0 8px}.yrs button{font:inherit;font-size:12.5px;border:1px solid var(--line);background:var(--card);color:var(--ink);padding:4px 9px;border-radius:6px;cursor:pointer}
.yrs button.on{background:var(--acc);color:var(--card)}
.note{color:var(--ink2);font-size:12px;margin-top:6px}
.tb{float:right;font:inherit;font-size:12px;border:1px solid var(--line);background:var(--card);color:var(--ink);padding:4px 9px;border-radius:6px;cursor:pointer}
@media (max-width:640px){.map{height:70vh;min-height:420px}.legend{max-width:170px;font-size:11px}header h1{font-size:18px}}
@media print{nav,.yrs,.tb,header p.hint{display:none}.sheet{page-break-after:always;max-width:none}.map{height:180mm;border:none}body{background:#fff}}
</style></head><body>
<header><button class="tb" id="theme">Light / dark</button><h1>Road traffic crashes on the Lagos–Ibadan Expressway, 2013–2022</h1>
<p>FRSC crash records geoparsed from location names (LLM-assisted toponym resolution). Basemap © OpenStreetMap contributors.</p>
<p class="hint">Tip: choose a map, zoom/pan to the extent you want, then print (Ctrl/Cmd + P → Save as PDF, landscape) or take a screenshot. Each map prints on its own page.</p></header>
<nav><div class="in" id="tabs"></div></nav>
<div id="sheets"></div>
<script>
const D=__DATA__;
const CONF={High:"#1b8a2a",Medium:"#eda100",Low:"#d03b3b"};
const GI={"Hot 99%":"#d03b3b","Hot 95%":"#ec835a","Hot 90%":"#f4b393"};
const fmt=n=>n.toLocaleString("en-GB");
const SHEETS=[
 {id:"m1",t:"Map 1. Geoparsed crash sites by confidence class",s:`${fmt(D.n)} crashes (duplicates excluded). Symbol area ∝ crashes at site; colour = geoparsing confidence.`},
 {id:"m2",t:"Map 2. Crash sites by year",s:"Select a year. Symbol area ∝ crashes at site."},
 {id:"m3",t:"Map 3. Crash density (kernel density estimate)",s:`High + Medium confidence crashes within 1 km of the expressway. Switch periods below.`},
 {id:"m4",t:"Map 4. Persons killed",s:`${fmt(D.killed)} persons killed at geoparsed sites. Symbol area ∝ persons killed; colour = deaths per crash.`},
 {id:"m5",t:"Map 5. Getis-Ord Gi* hotspot segments (2 km)",s:"Whole-corridor Gi* classes; dashed outline = inter-urban hotspot (≥ 20 km analysis); ▶ = intensifying trend (Mann–Kendall p < 0.05)."}];
const tabs=document.getElementById("tabs"),wrap=document.getElementById("sheets"),maps={};
SHEETS.forEach((s,i)=>{const b=document.createElement("button");b.textContent=s.t.split(".")[0];b.onclick=()=>{document.getElementById(s.id).scrollIntoView({behavior:"smooth"})};tabs.appendChild(b);
 const el=document.createElement("section");el.className="sheet";el.id=s.id;
 el.innerHTML=`<h2>${s.t}</h2><p class="sub">${s.s}</p>${s.id==="m2"?'<div class="yrs" id="yrs"></div>':""}${s.id==="m3"?'<div class="yrs" id="kd"></div>':""}<div class="map" id="map_${s.id}"></div>
 <p class="note">WGS 84 · Points are landmark-level positions derived from FRSC location descriptions, not crash-scene GPS. Basemap © OpenStreetMap contributors.</p>`;wrap.appendChild(el)});
function base(id){const m=L.map("map_"+id,{zoomSnap:.25,preferCanvas:true}).fitBounds([[6.56,3.30],[7.44,3.98]]);
 L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png",{maxZoom:19,attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'}).addTo(m);
 L.control.scale({metric:true,imperial:false,position:"bottomleft",maxWidth:160}).addTo(m);
 const N=L.control({position:"topleft"});N.onAdd=()=>{const e=L.DomUtil.create("div","north");e.innerHTML='<svg width="18" height="22" viewBox="0 0 18 22"><path d="M9 1 L16 21 L9 16 L2 21 Z" fill="#0b0b0b"/><path d="M9 1 L9 16 L2 21 Z" fill="#8a8983"/></svg>N';return e};N.addTo(m);
 maps[id]=m;return m}
function legend(m,html,pos){const c=L.control({position:pos||"bottomright"});c.onAdd=()=>{const e=L.DomUtil.create("div","legend");e.innerHTML=html;return e};c.addTo(m);return c}
const esc=s=>String(s).replace(/[&<>]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;"}[c]));
const rad=n=>2.5+Math.sqrt(n)*1.7;
function sizeLegend(vals,lab,fill){return vals.map(v=>`<div style="display:flex;align-items:center;gap:8px;margin:2px 0"><svg width="${2*rad(v)+2}" height="${2*rad(v)+2}"><circle cx="${rad(v)+1}" cy="${rad(v)+1}" r="${rad(v)}" fill="${fill}" stroke="#52514e" stroke-width=".6"/></svg>${v} ${lab}</div>`).join("")}
function labels(m,S,idx,n,fn){[...S].sort((a,b)=>b[idx]-a[idx]).slice(0,n).forEach((r,i)=>L.tooltip({permanent:true,direction:i%2?"left":"right",offset:[i%2?-rad(r[idx]):rad(r[idx]),0],className:"lbl"}).setLatLng([r[0],r[1]]).setContent(fn(r)).addTo(m))}
function pop(r){return `<b>${esc(r[5])}</b><br>${r[2]} crash(es) · ${r[3]} killed · ${r[4]} injured<br>Confidence: ${r[6]}`}
// ---------- Map 1
(()=>{const m=base("m1");D.all.sort((a,b)=>b[2]-a[2]).forEach(r=>L.circleMarker([r[0],r[1]],{radius:rad(r[2]),color:"#fff",weight:.8,fillColor:CONF[r[6]],fillOpacity:.82}).bindPopup(pop(r)).addTo(m));
 labels(m,D.all,2,10,r=>`${esc(r[5])} (${r[2]})`);
 legend(m,`<b>Geoparsing confidence</b>${["High","Medium","Low"].map(k=>`<div><span class="sw" style="background:${CONF[k]}"></span>${k} (${fmt(D.conf[k]||0)})</div>`).join("")}<b style="margin-top:6px">Crashes at site</b>${sizeLegend([10,50,150],"crashes","#bdbcb5")}`)})();
// ---------- Map 2
(()=>{const m=base("m2");let lay=L.layerGroup().addTo(m),lab=L.layerGroup().addTo(m);const box=document.getElementById("yrs");const yrs=Object.keys(D.year);
 const lg=legend(m,"");function draw(y){lay.clearLayers();lab.clearLayers();const S=D.year[y];
  S.forEach(r=>L.circleMarker([r[0],r[1]],{radius:rad(r[2])*1.25,color:"#fff",weight:.8,fillColor:"#2a78d6",fillOpacity:.75}).bindPopup(pop(r)).addTo(lay));
  [...S].sort((a,b)=>b[2]-a[2]).slice(0,6).forEach((r,i)=>L.tooltip({permanent:true,direction:i%2?"left":"right",offset:[i%2?-8:8,0],className:"lbl"}).setLatLng([r[0],r[1]]).setContent(`${esc(r[5])} (${r[2]})`).addTo(lab));
  const n=S.reduce((a,b)=>a+b[2],0);lg.getContainer().innerHTML=`<b>${y}</b>${fmt(n)} of ${fmt(D.tot[y])} records located<b style="margin-top:6px">Crashes at site</b>${sizeLegend([5,20,60],"crashes","#2a78d6")}`;
  [...box.children].forEach(b=>b.classList.toggle("on",b.textContent==y))}
 yrs.forEach(y=>{const b=document.createElement("button");b.textContent=y;b.onclick=()=>draw(y);box.appendChild(b)});draw(yrs[yrs.length-1])})();
// ---------- Map 3
(()=>{const m=base("m3");let ov=null;const box=document.getElementById("kd");const lg=legend(m,"");
 function draw(k){if(ov)m.removeLayer(ov);ov=L.imageOverlay(D.kde[k],D.kdeB,{opacity:.85}).addTo(m);
  lg.getContainer().innerHTML=`<b>Crash density, ${k.replace("_","–")}</b>n = ${fmt(D.kdeN[k])} crashes<div style="height:10px;width:170px;margin:5px 0 2px;border-radius:2px;background:linear-gradient(90deg,rgba(252,217,77,.55),rgba(237,105,51,.75),rgba(209,59,59,.9),rgba(115,13,26,.95))"></div><div style="display:flex;justify-content:space-between;width:170px"><span>lower</span><span>higher</span></div>`;
  [...box.children].forEach(b=>b.classList.toggle("on",b.dataset.k===k))}
 ["2013_2017","2018_2022"].forEach(k=>{const b=document.createElement("button");b.textContent=k.replace("_","–");b.dataset.k=k;b.onclick=()=>draw(k);box.appendChild(b)});draw("2018_2022")})();
// ---------- Map 4
(()=>{const m=base("m4");const ramp=["#cde2fb","#86b6ef","#3987e5","#1c5cab","#0d366b"];const cbin=v=>v<.2?0:v<.4?1:v<.7?2:v<1?3:4;
 const S=D.all.filter(r=>r[3]>0).sort((a,b)=>b[3]-a[3]);
 S.forEach(r=>L.circleMarker([r[0],r[1]],{radius:rad(r[3]),color:"#52514e",weight:.6,fillColor:ramp[cbin(r[3]/r[2])],fillOpacity:.85}).bindPopup(pop(r)+`<br>Deaths per crash: ${(r[3]/r[2]).toFixed(2)}`).addTo(m));
 labels(m,S,3,10,r=>`${esc(r[5])} (${r[3]})`);
 legend(m,`<b>Deaths per crash</b>${["< 0.2","0.2–0.4","0.4–0.7","0.7–1.0","≥ 1.0"].map((t,i)=>`<div><span class="sw" style="background:${ramp[i]};border-color:#52514e"></span>${t}</div>`).join("")}<b style="margin-top:6px">Persons killed</b>${sizeLegend([5,25,100],"killed","#bdbcb5")}`)})();
// ---------- Map 5
(()=>{const m=base("m5");
 L.geoJSON(D.segs,{style:f=>{const c=GI[f.properties.GI_CLASS];return c?{color:c,weight:10,opacity:.9}:{color:"#6b6a64",weight:4,opacity:.55}},
  onEachFeature:(f,l)=>{const p=f.properties;l.bindPopup(`<b>${p.FROM_KM}–${p.TO_KM} km</b> · ${esc(p.TOP_NAMES)}<br>${p.CRASHES} crashes · ${p.KILLED} killed<br>Gi* z = ${(+p.GI_Z).toFixed(2)} (${p.GI_CLASS})<br>Inter-urban class: ${p.GI_CLS_INT}<br>Trend: ${p.TREND}`)}}).addTo(m);
 L.geoJSON({type:"FeatureCollection",features:D.segs.features.filter(f=>String(f.properties.GI_CLS_INT).startsWith("Hot"))},{style:{color:"#7a1418",weight:16,opacity:.9,fill:false,dashArray:"4 5"}}).addTo(m).bringToBack();
 D.segs.features.filter(f=>f.properties.TREND==="intensifying").forEach(f=>{const c=f.geometry.coordinates[Math.floor(f.geometry.coordinates.length/2)];
  L.marker([c[1],c[0]],{icon:L.divIcon({className:"",html:'<div style="color:#6250d6;font:700 16px system-ui;transform:translate(-22px,-9px)">▶</div>'})}).addTo(m)});
 D.segs.features.filter(f=>(String(f.properties.GI_CLASS).startsWith("Hot")||String(f.properties.GI_CLS_INT).startsWith("Hot"))&&f.properties.CRASHES>=20).forEach((f,i)=>{const c=f.geometry.coordinates[Math.floor(f.geometry.coordinates.length/2)],p=f.properties;
  L.tooltip({permanent:true,direction:i%2?"left":"right",offset:[i%2?-10:10,0],className:"lbl"}).setLatLng([c[1],c[0]]).setContent(`${esc(String(p.TOP_NAMES).split(",")[0])} · ${p.FROM_KM}–${p.TO_KM} km (${p.CRASHES})`).addTo(m)});
 legend(m,`<b>Gi* hotspot (whole corridor)</b>${["Hot 99%","Hot 95%","Hot 90%"].map(k=>`<div><span class="ln" style="background:${GI[k]}"></span>${k}</div>`).join("")}<div><span class="ln" style="background:#6b6a64;height:3px"></span>Not significant</div><div><span class="ln" style="border:2px dashed #7a1418;height:9px;background:none"></span>Inter-urban hotspot (≥ 95%)</div><div><span style="color:#6250d6;font-weight:700;margin-right:6px">▶</span>Intensifying trend</div>`)})();
// theme toggle
document.getElementById("theme").onclick=()=>{const r=document.documentElement;const dark=r.dataset.theme?r.dataset.theme==="dark":matchMedia("(prefers-color-scheme: dark)").matches;r.dataset.theme=dark?"light":"dark"};
// highlight tab of visible sheet
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){const i=SHEETS.findIndex(s=>s.id===e.target.id);[...tabs.children].forEach((b,j)=>b.classList.toggle("on",i===j))}}),{rootMargin:"-40% 0px -55% 0px"});
SHEETS.forEach(s=>io.observe(document.getElementById(s.id)));
</script></body></html>"""
open(OUT, "w").write(HTML.replace("__DATA__", json.dumps(data, separators=(",", ":"))))
print(OUT, os.path.getsize(OUT) // 1024, "KB")

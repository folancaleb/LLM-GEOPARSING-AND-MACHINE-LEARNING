"""ml_2027.py — extend the corridor-level monthly crash forecast to December 2027 using the same models,
back-test and selection rule as 05_ml.py. Usage: python3 -I ml_2027.py <out_dir>"""
import sys, os, json
src = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "05_ml.py")).read()
head = src[:src.index("# Final forecast 2023–2024")]
sys.argv = [sys.argv[0], sys.argv[1]]
ns = {"__file__": os.path.join(os.path.dirname(os.path.abspath(__file__)), "05_ml.py")}
exec(compile(head, "05_ml_head", "exec"), ns)
np, pd, plt = ns["np"], ns["pd"], ns["plt"]; m, fit_predict, MODELS, bt, best, OUT, CAT = ns["m"], ns["fit_predict"], ns["MODELS"], ns["bt"], ns["best"], ns["OUT"], ns["CAT"]
H = 60
fut = pd.date_range("2023-01-01", "2027-12-01", freq="MS")
fc = {k: fit_predict(m, fut, k) for k in MODELS}
rmse = bt[bt.model == best].RMSE.mean()
w = 1.645 * rmse * np.sqrt(1 + np.arange(H) / 24)
lo, hi = np.maximum(fc[best] - w, 0), fc[best] + w
F = pd.DataFrame({"month": fut.strftime("%Y-%m"), "forecast_ensemble": fc[best].round(1), "pi90_low": lo.round(1), "pi90_high": hi.round(1),
                  **{f"fc_{k.split(' (')[0].replace(' ', '_').lower()}": v.round(1) for k, v in fc.items()}})
F.to_csv(os.path.join(OUT, "forecast_monthly_2023_2027.csv"), index=False)
yrs = list(range(2023, 2028)); A = []
for i, y in enumerate(yrs):
    s = slice(12 * i, 12 * i + 12)
    A.append({"year": y, "ensemble": round(fc[best][s].sum()), "pi90_low": round(lo[s].sum()), "pi90_high": round(hi[s].sum()),
              **{k: round(v[s].sum()) for k, v in fc.items()}})
A = pd.DataFrame(A); A.to_csv(os.path.join(OUT, "forecast_annual_2023_2027.csv"), index=False)
obs = m.n.groupby(m.index.year).sum()
json.dump({"best": best, "rmse": round(rmse, 2), "annual": A.to_dict("records"), "obs": {int(k): int(v) for k, v in obs.items()}}, open(os.path.join(OUT, "forecast_2027_summary.json"), "w"), indent=1)
print(A.to_string())

# ---------- figure: monthly series + annual totals ----------
fig, axs = plt.subplots(2, 1, figsize=(13, 8.2), gridspec_kw={"height_ratios": [1.15, 1]})
ax = axs[0]
ax.plot(m.index, m.n, color=CAT[0], lw=1.5, label="Observed (2013–2022)")
ax.plot(m.index, m.n.rolling(12, center=True).mean(), color="#0d366b", lw=2.2, label="12-month moving average")
ax.fill_between(fut, lo, hi, color=CAT[1], alpha=.18, linewidth=0, label="90% prediction band")
ax.plot(fut, fc[best], color=CAT[1], lw=2.2, label=f"Forecast: {best}")
ax.axvline(pd.Timestamp("2023-01-01"), color="#a8a79f", lw=1, ls="--")
ax.set_title("(a) Monthly recorded crashes and machine-learning forecast to December 2027"); ax.set_ylabel("Crashes per month"); ax.set_xlabel("")
ax.legend(loc="upper left", fontsize=9, ncol=2); ax.set_ylim(0, None)
ax = axs[1]
xo = obs.index.values; ax.bar(xo, obs.values, color=CAT[0], width=.65, label="Observed (dated records)")
ax.bar(A.year, A.ensemble, color=CAT[1], width=.65, label="Forecast (ensemble)")
ax.errorbar(A.year, A.ensemble, yerr=[A.ensemble - A.pi90_low, A.pi90_high - A.ensemble], fmt="none", ecolor="#52514e", elinewidth=1.2, capsize=4, label="90% interval")
ax.plot(A.year, A["Poisson GLM (trend + month)"], "^", color="#6250d6", ms=8, label="Scenario: trend continues (Poisson GLM)", zorder=5)
ax.plot(A.year, A["Random Forest (lags)"], "s", color="#1baf7a", ms=7, label="Scenario: plateau (Random Forest)", zorder=5)
for x, v in zip(xo, obs.values): ax.text(x, v + 25, f"{v:,}", ha="center", fontsize=8, color="#52514e")
for x, v in zip(A.year, A.ensemble): ax.text(x, 90, f"{v:,}", ha="center", fontsize=8.5, color="#fcfcfb", weight="bold")
ax.set_xticks(list(xo) + list(A.year)); ax.set_ylabel("Crashes per year"); ax.set_title("(b) Annual totals: observed 2013–2022 and forecast 2023–2027")
ax.legend(loc="upper left", fontsize=8.5, ncol=2); ax.set_ylim(0, max(A.pi90_high.max(), A["Poisson GLM (trend + month)"].max(), obs.max()) * 1.15)
fig.tight_layout(); fig.savefig(os.path.join(OUT, "figures", "fig10_monthly_forecast_2027.png"), dpi=200); plt.close()

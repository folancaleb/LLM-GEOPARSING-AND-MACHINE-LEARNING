"""report_maps_basemap.py — Redraw the report's two maps (Fig 5 KDE, Fig 8 Gi*/DBSCAN) on the Natural Earth basemap.
Same data as the original report (recorded coordinates, out/). Usage: python3 -I report_maps_basemap.py <out_dir> <dest_dir>"""
import sys, os, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(__file__))
import style; style.setup()
import basemap_ne
import matplotlib.pyplot as plt, seaborn as sns
from matplotlib.patches import Patch
from matplotlib.lines import Line2D
from matplotlib.colors import LinearSegmentedColormap
OUT, DEST = sys.argv[1:3]; os.makedirs(DEST, exist_ok=True)
d = pd.read_csv(os.path.join(OUT, "rtc_lagos_ibadan_clean_2013_2022.csv"), low_memory=False)
cl = pd.read_csv(os.path.join(OUT, "centreline_derived.csv"))
t2 = pd.read_csv(os.path.join(OUT, "hotspots_gistar_2km.csv")); tr = pd.read_csv(os.path.join(OUT, "hotspots_gistar_2km_interurban.csv"))
cls = pd.read_csv(os.path.join(OUT, "hotspots_dbscan_clusters.csv"))
XL, YL = (3.20, 4.05), (6.40, 7.50); ASP = 1 / np.cos(np.deg2rad(6.9)); INK2 = "#52514e"
KDECM = LinearSegmentedColormap.from_list("kde", [(1.0, 0.85, 0.30, 0.0), (0.99, 0.80, 0.30, 0.55), (0.93, 0.41, 0.20, 0.8), (0.82, 0.23, 0.23, 0.92), (0.45, 0.05, 0.10, 0.97)])

def furniture(ax, credit):
    ax.set_xlim(*XL); ax.set_ylim(*YL); ax.set_aspect(ASP); ax.set_xlabel("Longitude (°E)"); ax.set_ylabel("Latitude (°N)")
    dlon = 20 / (111.32 * np.cos(np.deg2rad(6.9))); x0, y0 = XL[1] - 0.04 - dlon, YL[0] + 0.06
    ax.plot([x0, x0 + dlon], [y0, y0], color="#0b0b0b", lw=2.5, solid_capstyle="butt", zorder=7); ax.plot([x0, x0 + dlon / 2], [y0, y0], color="#fcfcfb", lw=1.2, solid_capstyle="butt", zorder=7)
    ax.text(x0, y0 + 0.012, "0", fontsize=7, ha="center", zorder=7); ax.text(x0 + dlon, y0 + 0.012, "20 km", fontsize=7, ha="center", zorder=7)
    ax.annotate("N", xy=(XL[0] + 0.05, YL[1] - 0.04), xytext=(XL[0] + 0.05, YL[1] - 0.12), ha="center", fontsize=10, weight="bold", arrowprops=dict(arrowstyle="-|>", color="#0b0b0b", lw=1.5), zorder=7)
    ax.text(XL[1] - 0.01, YL[0] + 0.01, credit + " · " + basemap_ne.CREDIT, fontsize=6.3, color="#3a3936", ha="right", va="bottom",
            bbox=dict(boxstyle="round,pad=0.2", fc="#fcfcfb", ec="none", alpha=.85), zorder=7)

def road(ax):
    ax.plot(cl.lon, cl.lat, color="#fcfcfb", lw=7.5, solid_capstyle="round", zorder=1, alpha=.9)
    ax.plot(cl.lon, cl.lat, color="#8a8983", lw=3.2, solid_capstyle="round", zorder=1.1)

# ---------- Figure 5: KDE (same data/periods as the report) ----------
p = d[d.on_corridor == True]
fig, axs = plt.subplots(1, 2, figsize=(14, 9.6), sharey=True)
for ax, (lab, sub) in zip(axs, [("2013–2017", p[p.year <= 2017]), ("2018–2022", p[p.year >= 2018])]):
    basemap_ne.draw(ax, extent=XL + YL); road(ax)
    sns.kdeplot(x=sub.lon, y=sub.lat, fill=True, cmap=KDECM, levels=14, thresh=0.04, bw_adjust=0.35, ax=ax, zorder=2)
    ax.scatter(sub.lon, sub.lat, s=3, color="#0b0b0b", alpha=.35, zorder=3, linewidths=0)
    ax.set_title(f"Crash density (KDE), {lab}  (n = {len(sub):,})"); furniture(ax, "Recorded FRSC coordinates")
fig.tight_layout(); fig.savefig(os.path.join(DEST, "fig05_kde_hotspot_map_basemap.png"), dpi=200); plt.close()

# ---------- Figure 8: Gi* classes + DBSCAN (same data as the report) ----------
order = ["Hot 99%", "Hot 95%", "Hot 90%", "Not significant", "Cold 95%"]
pal = {"Hot 99%": "#d03b3b", "Hot 95%": "#ec835a", "Hot 90%": "#f4b393", "Not significant": "#c9c8c1", "Cold 95%": "#6da7ec"}
fig, axs = plt.subplots(1, 2, figsize=(14, 9.6), sharey=True)
ax = axs[0]; basemap_ne.draw(ax, extent=XL + YL)
for _, r in t2.iterrows():
    a, b = r.from_km, r.to_km; ts = np.r_[a, cl.chainage_km[(cl.chainage_km > a) & (cl.chainage_km < b)].values, min(b, cl.chainage_km.max())]
    hot = str(r["class"]).startswith("Hot")
    ax.plot(np.interp(ts, cl.chainage_km, cl.lon), np.interp(ts, cl.chainage_km, cl.lat), color=pal.get(r["class"], "#c9c8c1"), lw=9 if hot else 4.5, solid_capstyle="butt", zorder=2)
for _, r in tr[tr.z >= 1.96].iterrows():
    mid = (r.from_km + r.to_km) / 2
    ax.scatter(np.interp(mid, cl.chainage_km, cl.lon), np.interp(mid, cl.chainage_km, cl.lat), s=230, facecolor="none", edgecolor="#7a1418", linewidth=2, zorder=3)
h = [Patch(color=pal[k], label=k) for k in order[:4]] + [Line2D([], [], marker="o", ls="", markerfacecolor="none", markeredgecolor="#7a1418", markeredgewidth=2, markersize=11, label="Inter-urban hotspot (≥ 95%)")]
ax.legend(handles=h, loc="center right", bbox_to_anchor=(0.995, 0.62), fontsize=8.5, frameon=True, facecolor="#fcfcfb", edgecolor="#c9c8c1", framealpha=.95)
ax.set_title("Gi* class per 2-km segment"); furniture(ax, "Recorded FRSC coordinates")
ax = axs[1]; basemap_ne.draw(ax, extent=XL + YL); road(ax)
on = d[d.on_corridor == True]; ax.scatter(on.lon, on.lat, s=3, color="#52514e", alpha=.35, zorder=2, linewidths=0)
top = cls.sort_values("n", ascending=False).head(12)
ax.scatter(top.lon, top.lat, s=top.n * 1.2, color="#2a78d6", alpha=.55, edgecolor="#184f95", zorder=3)
lab = top.head(8).sort_values("lat")
for i, (_, r) in enumerate(lab.iterrows()):
    side = 1 if i % 2 == 0 else -1
    ax.annotate(f"{str(r.names).split(',')[0].title()} ({int(r.n)})", (r.lon, r.lat), xytext=(22 * side, 0), textcoords="offset points", ha="left" if side > 0 else "right", va="center",
                fontsize=7.8, arrowprops=dict(arrowstyle="-", color="#8a8983", lw=.6), bbox=dict(boxstyle="round,pad=0.15", fc="#fcfcfb", ec="none", alpha=.9), zorder=5)
ax.set_title("DBSCAN crash clusters (ε = 400 m, ≥ 25 crashes)"); furniture(ax, "Recorded FRSC coordinates")
fig.tight_layout(); fig.savefig(os.path.join(DEST, "fig08_hotspot_maps_basemap.png"), dpi=200); plt.close()
print("ok")

"""ml_seg_2027.py — Predict which 2-km sections of the Lagos–Ibadan Expressway are likely to be crash hot spots in 2027.
Direct 5-year-ahead model: a section's share of corridor crashes in year t is predicted from information up to t−5.
Back-tested on 2020–2022 against persistence (share in t−5) and the historical mean share; 2027 is predicted from 2022.
Usage: python3 -I ml_seg_2027.py <out_dir>"""
import sys, os, json, numpy as np, pandas as pd
from scipy import stats
from sklearn.ensemble import RandomForestRegressor
OUT = sys.argv[1]; SEED = 42; H = 5; SEG = 2
d = pd.read_csv(os.path.join(OUT, "rtc_lagos_ibadan_clean_2013_2022.csv"), low_memory=False)
p = d[d.on_corridor == True].copy()
L = pd.read_csv(os.path.join(OUT, "centreline_derived.csv")).chainage_km.max(); nseg = int(np.ceil(L / SEG))
p["seg"] = (p.chainage_km // SEG).astype(int).clip(0, nseg - 1)
years = list(range(2013, 2023))
C = p.pivot_table(index="seg", columns="year", values="fatal", aggfunc="size", fill_value=0).reindex(index=range(nseg), columns=years, fill_value=0)
K = p.pivot_table(index="seg", columns="year", values="killed", aggfunc="sum", fill_value=0).reindex(index=range(nseg), columns=years, fill_value=0)
Sh = C / C.sum(0); KS = K / K.sum(0).replace(0, 1)

def feats(t):
    o = t - H; rows = []
    for s in range(nseg):
        lag = lambda k: Sh.loc[s, o - k] if (o - k) in Sh.columns else Sh.loc[s, o]
        hist = Sh.loc[s, [y for y in years if y <= o]]
        nb = [Sh.loc[j, o] for j in (s - 1, s + 1) if 0 <= j < nseg]
        rows.append({"seg": s, "year": t, "sh0": lag(0), "sh1": lag(1), "sh2": lag(2), "hist_mean": hist.mean(), "hist_max": hist.max(),
                     "nb0": np.mean(nb), "ksh0": KS.loc[s, o], "chainage": s * SEG + SEG / 2, "trend": (lag(0) - lag(2)) / 2,
                     "y": Sh.loc[s, t] if t in Sh.columns else np.nan, "n_t": C.loc[s, t] if t in C.columns else np.nan})
    return pd.DataFrame(rows)
FE = ["sh0", "sh1", "sh2", "hist_mean", "hist_max", "nb0", "ksh0", "chainage", "trend"]
panel = pd.concat([feats(t) for t in range(2013 + H, 2023)] + [feats(2027)], ignore_index=True)
rf = lambda: RandomForestRegressor(n_estimators=800, min_samples_leaf=3, random_state=SEED)
K10 = max(1, int(round(.1 * nseg)))
def score(te, pr):
    y = te.y.values; n = te.n_t.values; top = np.argsort(-pr)[:K10]; ttop = set(np.argsort(-y)[:K10])
    return {"Spearman": stats.spearmanr(y, pr)[0], "hit_rate_%": 100 * n[top].sum() / n.sum(), "top10_overlap": len(set(top) & ttop)}

ev, res = [], []
for t in [2020, 2021, 2022]:
    tr = panel[(panel.year < t) & panel.y.notna()]; te = panel[panel.year == t]
    m = rf().fit(tr[FE], tr.y); pr = m.predict(te[FE])
    res.extend((te.y.values - pr) / np.sqrt(pr + 1e-3))
    for name, q in [("Random forest (5-yr ahead)", pr), ("Persistence (share 5 yrs earlier)", te.sh0.values), ("Historical mean share", te.hist_mean.values)]:
        ev.append({"test_year": t, "origin": t - H, "model": name, **score(te, q)})
ev = pd.DataFrame(ev); ev.round(3).to_csv(os.path.join(OUT, "seg2027_backtest.csv"), index=False)
evm = ev.groupby("model")[["Spearman", "hit_rate_%", "top10_overlap"]].mean().round(3)
print(ev.round(3).to_string()); print(evm)

# final model: all target years 2018–2022, predict 2027 from 2022
tr = panel[panel.y.notna()]; f = panel[panel.year == 2027].copy()
m = rf().fit(tr[FE], tr.y); f["share"] = np.clip(m.predict(f[FE]), 0, None); f["share"] /= f.share.sum()
A = pd.read_csv(os.path.join(OUT, "forecast_annual_2023_2027.csv")); r27 = A[A.year == 2027].iloc[0]
oc = C[2022].sum() / d[d.year == 2022].shape[0]                          # share of 2022 records located on the corridor
TOT = {"ensemble": r27.ensemble * oc, "plateau": r27["Random Forest (lags)"] * oc, "trend": r27["Poisson GLM (trend + month)"] * oc}
f["exp_ensemble"] = f.share * TOT["ensemble"]; f["exp_plateau"] = f.share * TOT["plateau"]; f["exp_trend"] = f.share * TOT["trend"]

def gistar(x, band=1):
    x = np.asarray(x, float); n = len(x); xb = x.mean(); s = np.sqrt((x ** 2).mean() - xb ** 2); z = np.zeros(n)
    for i in range(n):
        j = np.arange(max(0, i - band), min(n, i + band + 1)); w = len(j)
        den = s * np.sqrt((n * w - w ** 2) / (n - 1)); z[i] = (x[j].sum() - xb * w) / den if den > 0 else 0
    return z
# Monte-Carlo: model error (back-test residuals, scaled) + Poisson noise, total drawn from the ensemble interval
rng = np.random.default_rng(SEED); NS = 4000; res = np.asarray(res)
sh = np.clip(f.share.values[None] + rng.choice(np.r_[res, -res], size=(NS, nseg)) * np.sqrt(f.share.values + 1e-3)[None], 0, None)
sh /= sh.sum(1, keepdims=True)
tot = np.clip(rng.normal(r27.ensemble, (r27.pi90_high - r27.pi90_low) / (2 * 1.645), NS), 100, None) * oc
sims = rng.poisson(sh * tot[:, None])
thr = np.sort(sims, 1)[:, -K10][:, None]
f["p_top10"] = ((sims >= thr) & (sims > 0)).mean(0)
Z = np.array([gistar(s) for s in sims]); f["p_hot95"] = (Z >= 1.96).mean(0)
f["gistar_z_expected"] = gistar(f.exp_ensemble.values)
f["lo90"], f["hi90"] = np.percentile(sims, 5, 0), np.percentile(sims, 95, 0)
f["from_km"], f["to_km"] = f.seg * SEG, f.seg * SEG + SEG
f["crashes_2022"] = C[2022].values; f["mean_2013_2022"] = C.mean(1).values
hs = pd.read_csv(os.path.join(OUT, "hotspots_gistar_2km.csv"))[["seg", "class", "top_location_names"]]
f = f.merge(hs, on="seg", how="left")
f["tier"] = np.select([f.p_hot95 >= .5, f.p_hot95 >= .2, f.p_top10 >= .2], ["Likely hot spot", "Possible hot spot", "Busy, unlikely hot spot"], "Low")
cols = ["seg", "from_km", "to_km", "top_location_names", "crashes_2022", "mean_2013_2022", "share", "exp_ensemble", "lo90", "hi90", "exp_plateau", "exp_trend", "p_top10", "p_hot95", "gistar_z_expected", "tier", "class"]
out = f[cols].rename(columns={"class": "gistar_class_2013_2022"}).sort_values("p_hot95", ascending=False)
out.round(4).to_csv(os.path.join(OUT, "forecast_segments_2027.csv"), index=False)
S = {"backtest_mean": evm.reset_index().to_dict("records"), "oncorr_share_2022": round(oc, 3), "totals_oncorridor": {k: round(v) for k, v in TOT.items()},
     "n_likely": int((f.tier == "Likely hot spot").sum()), "n_possible": int((f.tier == "Possible hot spot").sum()),
     "top": out.head(12)[["from_km", "to_km", "top_location_names", "crashes_2022", "exp_ensemble", "lo90", "hi90", "p_top10", "p_hot95", "tier"]].round(2).to_dict("records")}
json.dump(S, open(os.path.join(OUT, "seg2027_summary.json"), "w"), indent=1, default=float)
print(json.dumps(S["totals_oncorridor"]), S["n_likely"], S["n_possible"]); print(out.head(15)[["from_km", "top_location_names", "crashes_2022", "exp_ensemble", "lo90", "hi90", "p_top10", "p_hot95", "tier"]].round(2).to_string())

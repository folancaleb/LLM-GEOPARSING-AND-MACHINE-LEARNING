"""gazetteer_verify.py — Build a gazetteer from the location strings of the 2017 FRSC return and verify each entry's
geoparsed position against the 2026 field GPS fixes (screened) collected by FRSC field officers.
Usage: python3 -I gazetteer_verify.py <gazetteer_names.csv> <validation_2017_records.csv> <out_dir>"""
import sys, os, re, json, numpy as np, pandas as pd
NAMES, VAL, OUT = sys.argv[1:4]; os.makedirs(OUT, exist_ok=True)
src = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "geo_01_geocode.py")).read(); lib = {}
exec(compile(src[:src.index("# ---------------- 2. GAZETTEER")].replace("CLEAN, CL, TARGET, TY, OUTCSV = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4]), sys.argv[5]", ""), "n", "exec"), lib)
g = pd.read_csv(NAMES, dtype=str); g.columns = [c.strip() for c in g.columns]
v = pd.read_csv(VAL)
assert len(g) == len(v) and (g.LOCATION.str.strip().values == v.location.str.strip().values).all()
def zone(c):
    c = str(c).replace(",", ".").replace(" ", "")
    if c.startswith("RS11"): return "Oyo"
    if c in ("RS2.1", "RS2.17", "RS2.19", "RS2.11", "RS2.15"): return "Lagos"
    return "Ogun"
v["zone"] = g.COMMAND.map(zone).values
v["name"] = g.LOCATION.map(lambda s: lib["core"](lib["norm"](s))).values
v["km_only"] = g.LOCATION.str.upper().str.replace(r"\s", "", regex=True).str.fullmatch(r"KM\d+(\.\d+)?").values
v.loc[v.name.eq("") | v.name.isna(), "name"] = g.LOCATION.str.strip().str.upper()
v["entry"] = v.name + " | " + v.zone
def hav(a1, o1, a2, o2):
    a1, o1, a2, o2 = map(np.deg2rad, (a1, o1, a2, o2))
    return 2 * 6371 * np.arcsin(np.sqrt(np.sin((a2 - a1) / 2) ** 2 + np.cos(a1) * np.cos(a2) * np.sin((o2 - o1) / 2) ** 2))
rows = []
for e, s in v.groupby("entry"):
    gp = s[s.group == "independent (2017 withheld)"]; fx = s[s.ref_class == "usable"]
    r = dict(entry=s.name.iat[0], zone=s.zone.iat[0], variants=" / ".join(sorted(set(g.LOCATION[s.index].str.strip())))[:120], records=len(s), km_label=bool(s.km_only.all()),
             gaz_lat=gp.geo_lat.median() if len(gp) else np.nan, gaz_lon=gp.geo_lon.median() if len(gp) else np.nan,
             gps_n=len(fx), gps_lat=fx.ref_lat.median() if len(fx) else np.nan, gps_lon=fx.ref_lon.median() if len(fx) else np.nan,
             gps_excluded=int(s.ref_class.ne("usable").sum() - s.ref_class.eq("missing").sum()))
    rows.append(r)
G = pd.DataFrame(rows)
G["error_km"] = hav(G.gaz_lat, G.gaz_lon, G.gps_lat, G.gps_lon)
G["status"] = np.select([G.km_label, G.gaz_lat.isna(), G.gps_lat.isna()], ["KM label only (no landmark)", "no gazetteer position", "no usable GPS fix"], "verified")
G = G.sort_values(["status", "error_km"]); G.round(5).to_csv(os.path.join(OUT, "gazetteer_entries_verified.csv"), index=False)
V = G[G.status == "verified"]; e = V.error_km
def wil(k, n, z=1.96):
    p = k / n; den = 1 + z * z / n; c = (p + z * z / (2 * n)) / den; h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den; return [round(100 * (c - h), 1), round(100 * (c + h), 1)]
w = V.records
S = {"strings": int(g.LOCATION.str.strip().nunique()), "entries": len(G), "status": G.status.value_counts().to_dict(),
     "verified": len(V), "median_km": round(float(e.median()), 2), "mean_km": round(float(e.mean()), 2), "p90_km": round(float(e.quantile(.9)), 1),
     "within_0.5": round(float((e <= .5).mean() * 100), 1), "within_1": round(float((e <= 1).mean() * 100), 1), "within_1_ci": wil(int((e <= 1).sum()), len(e)),
     "within_2": round(float((e <= 2).mean() * 100), 1), "within_5": round(float((e <= 5).mean() * 100), 1),
     "records_in_verified": int(w.sum()), "records_within_1_share": round(float(w[e <= 1].sum() / w.sum() * 100), 1),
     "by_zone": V.groupby("zone").error_km.agg(["size", "median"]).round(2).to_dict("index"),
     "worst": V.sort_values("error_km", ascending=False).head(6)[["entry", "zone", "records", "error_km"]].round(1).values.tolist()}
json.dump(S, open(os.path.join(OUT, "gazetteer_verify_summary.json"), "w"), indent=1, default=float)
print(json.dumps(S, indent=1, default=float)); print(V[["entry", "zone", "records", "gps_n", "error_km"]].round(2).to_string())

"""geo10_pass2.py — second pass for names that occur in only one year: locate each record from OTHER records
with the same normalised name in the same year (leave-one-record-out). Never uses the record's own coordinate.
Usage: python3 -I geo10_pass2.py <combined_raw.csv> <attributes.csv> <centreline.csv> <out.csv>"""
import sys, runpy, numpy as np, pandas as pd
COMB, ATTR, CL, OUTF = sys.argv[1:5]
# import normalisation functions without running the geocoder main body
import os
src = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "geo_01_geocode.py")).read()
head = src[:src.index("# ---------------- 2. GAZETTEER")]
lib = {}; exec(compile(head.replace("CLEAN, CL, TARGET, TY, OUTCSV = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4]), sys.argv[5]", ""), "norm", "exec"), lib)
norm, core, parts = lib["norm"], lib["core"], lib["parts"]
KX, KY = 111.32 * np.cos(np.deg2rad(6.9)), 110.57
cl = pd.read_csv(CL); line = np.c_[cl.lon * KX, cl.lat * KY]; seg = np.diff(line, axis=0); cum = cl.chainage_km.values
def chainage(la, lo):
    P = np.c_[np.asarray(lo) * KX, np.asarray(la) * KY]; A = line[:-1]; L2 = (seg ** 2).sum(1)
    t = np.clip(((P[:, None] - A[None]) * seg[None]).sum(2) / L2, 0, 1)
    D = np.linalg.norm(P[:, None] - (A[None] + t[..., None] * seg[None]), axis=2); k = D.argmin(1)
    return cum[k] + t[np.arange(len(P)), k] * np.linalg.norm(seg, axis=1)[k], D.min(1)

m = pd.read_csv(COMB, low_memory=False)
a = pd.read_csv(ATTR, low_memory=False)
a = a[a.coord_source.astype(str).str.startswith("recorded") & a.lat.notna()].copy()
a["k"] = a.LOCATION.map(lambda s: core(norm(s)))
ck = a.lat.round(4).astype(str) + "," + a.lon.round(4).astype(str)
a["ph"] = ck.map(a.assign(ck=ck).groupby("ck").k.nunique()) >= 5
todo = m.geo_method.str.startswith("unresolved: name")
n_fixed = 0
for i in m.index[todo]:
    y, ro, loc = m.at[i, "file_year"], m.at[i, "row_order"], m.at[i, "LOCATION"]
    k = core(norm(loc)); keys = [k] + parts(norm(loc))
    for kk in keys:
        if not kk: continue
        s = a[(a.file_year == y) & (a.k == kk) & ~((a.row_order == ro))]
        good = s[~s.ph]; s = good if len(good) else s
        if len(s) == 0: continue
        la, lo = s.lat.values, s.lon.values
        D = np.hypot((lo[:, None] - lo[None]) * KX, (la[:, None] - la[None]) * KY)
        c = (D <= 1.0).sum(1).argmax(); inc = D[c] <= 1.0
        cla, clo = np.median(la[inc]), np.median(lo[inc]); share = inc.mean()
        conf = "Medium" if (inc.sum() >= 3 and share >= 0.7 and len(good)) else "Low"
        ch_, dd = chainage([cla], [clo])
        if dd[0] > 5: conf = "Low"
        m.loc[i, ["geo_lat", "geo_lon", "geo_matched_key", "geo_n_support", "geo_n_years", "geo_cluster_share", "geo_support_years", "geo_confidence", "geo_competing_site", "geo_within_command_territory"]] = \
            [cla, clo, kk, int(inc.sum()), 1, round(share, 2), str(y), conf, "", "unknown"]
        m.loc[i, "geo_method"] = "same-year other records (name unique to this year)"
        m.loc[i, "geo_chainage_km"] = round(float(ch_[0]), 2); m.loc[i, "geo_dist_to_expressway_km"] = round(float(dd[0]), 2)
        m.loc[i, "geo_on_expressway"] = dd[0] <= 1.0
        n_fixed += 1; break
m.to_csv(OUTF, index=False); print("pass-2 resolved:", n_fixed, "of", int(todo.sum()))
